from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path


LOGGER_NAME = "lms_gateway"


def setup_logging(base_dir: Path) -> None:
    log_dir = Path(os.environ.get("LMS_GATEWAY_LOG_DIR", base_dir / "logs"))
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "gateway.log"

    formatter = logging.Formatter(
        "%(asctime)s %(levelname)s [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    gateway_logger = logging.getLogger(LOGGER_NAME)
    gateway_logger.setLevel(logging.INFO)
    gateway_logger.propagate = False

    # Remove the legacy handler that older releases attached to AppDaemon's
    # root logger. Match the exact file so other apps remain untouched.
    root_logger = logging.getLogger()
    expected_log_file = os.path.normcase(os.path.abspath(log_file))
    for handler in list(root_logger.handlers):
        handler_file = getattr(handler, "baseFilename", None)
        if handler_file and os.path.normcase(os.path.abspath(handler_file)) == expected_log_file:
            root_logger.removeHandler(handler)
            handler.close()

    # AppDaemon can reload the app without restarting its Python process.
    # Replace only our own handlers and leave the global root logger untouched.
    for handler in list(gateway_logger.handlers):
        if getattr(handler, "_lms_gateway_handler", False):
            gateway_logger.removeHandler(handler)
            handler.close()

    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=1_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler._lms_gateway_handler = True

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler._lms_gateway_handler = True

    gateway_logger.addHandler(file_handler)
    gateway_logger.addHandler(console_handler)
