from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class DeviceContext:
    device: str
    user: str | None = None
    source: str | None = None
    default_room: str | None = None
    last_room: str | None = None
    last_player_id: str | None = None
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class DeviceContextStore:
    def __init__(self, config: dict):
        self._defaults = self._load_defaults(config)
        self._contexts: dict[str, DeviceContext] = {}

    def get(self, device: str | None, user: str | None = None, source: str | None = None) -> DeviceContext | None:
        key = self._key(device, user, source)
        if not key:
            return None
        if key not in self._contexts:
            default_room = self._defaults.get(key) or self._defaults.get(str(device or "").strip())
            self._contexts[key] = DeviceContext(
                device=str(device or "").strip(),
                user=self._clean(user),
                source=self._clean(source),
                default_room=default_room,
            )
        return self._contexts[key]

    def remember_room(
        self,
        device: str | None,
        room: str | None,
        player_id: str | None = None,
        user: str | None = None,
        source: str | None = None,
    ) -> None:
        if not room:
            return
        context = self.get(device, user=user, source=source)
        if not context:
            return
        context.last_room = room
        context.last_player_id = player_id
        context.updated_at = datetime.now(timezone.utc)

    def default_room(self, device: str | None, user: str | None = None, source: str | None = None) -> str | None:
        context = self.get(device, user=user, source=source)
        return context.default_room if context else None

    @staticmethod
    def _load_defaults(config: dict) -> dict[str, str]:
        defaults: dict[str, str] = {}
        for device, data in config.get("devices", {}).items():
            if not isinstance(data, dict):
                continue
            default_room = str(data.get("default_room", "")).strip().lower()
            if default_room:
                defaults[str(device).strip()] = default_room
        return defaults

    @classmethod
    def _key(cls, device: str | None, user: str | None, source: str | None) -> str | None:
        cleaned_device = cls._clean(device)
        if not cleaned_device:
            return None
        cleaned_user = cls._clean(user)
        cleaned_source = cls._clean(source)
        if cleaned_user or cleaned_source:
            return "|".join([cleaned_source or "-", cleaned_user or "-", cleaned_device])
        return cleaned_device

    @staticmethod
    def _clean(value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = str(value).strip()
        return cleaned or None
