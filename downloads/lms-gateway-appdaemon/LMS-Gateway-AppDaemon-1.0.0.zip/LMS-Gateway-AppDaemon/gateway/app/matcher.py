from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from unicodedata import category, normalize


@dataclass(frozen=True)
class Match:
    item: dict
    score: float


def normalize_text(value: str) -> str:
    text = normalize("NFKD", value.casefold())
    text = "".join(char for char in text if category(char) != "Mn")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def score_text(query: str, candidate: str) -> float:
    left = normalize_text(query)
    right = normalize_text(candidate)
    if not left or not right:
        return 0.0
    if left == right:
        return 1.0
    if left in right or right in left:
        shorter = min(len(left), len(right))
        longer = max(len(left), len(right))
        return 0.82 + 0.18 * (shorter / longer)
    return SequenceMatcher(None, left, right).ratio()


def best_matches(query: str, items: list[dict], name_key: str, limit: int = 5) -> list[Match]:
    matches = [Match(item=item, score=score_text(query, str(item.get(name_key, "")))) for item in items]
    matches.sort(key=lambda match: match.score, reverse=True)
    return [match for match in matches[:limit] if match.score > 0]

