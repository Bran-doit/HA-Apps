from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any


@dataclass(frozen=True)
class Player:
    room: str
    id: str
    name: str | None = None
    lms_name: str | None = None
    dynamic: bool = False


class PlayerRegistry:
    def __init__(self, config: dict):
        self._players: dict[str, Player] = {}
        self._aliases: dict[str, str] = {}
        for room, data in config.get("players", {}).items():
            normalized_room = normalize_player_name(room)
            name = str(data.get("name", "")).strip() or None
            self._players[normalized_room] = Player(
                room=normalized_room,
                id=str(data.get("id", "")).strip(),
                name=name,
                lms_name=str(data.get("lms_name", "")).strip() or name,
                dynamic=False,
            )
            self._add_alias(normalized_room, normalized_room)
            name = str(data.get("name", "")).strip()
            if name:
                self._add_alias(name, normalized_room)
            for alias in data.get("aliases", []) or []:
                self._add_alias(str(alias), normalized_room)

    def get(self, room: str | None) -> Player | None:
        if not room:
            return None
        normalized = normalize_player_name(room)
        player_key = self._aliases.get(normalized) or self._aliases.get(compact_player_name(normalized)) or normalized
        return self._players.get(player_key)

    def get_by_id(self, player_id: str | None) -> Player | None:
        if not player_id:
            return None
        normalized = player_id.lower().strip()
        for player in self._players.values():
            if player.id.lower() == normalized:
                return player
        return None

    def refresh_from_lms(self, lms_players: list[dict[str, Any]]) -> None:
        for lms_player in lms_players:
            player_id = str(lms_player.get("playerid", "")).strip()
            if not player_id:
                continue

            name = str(
                lms_player.get("name")
                or lms_player.get("player_name")
                or lms_player.get("playername")
                or ""
            ).strip()
            existing = self.get_by_id(player_id) or self.get_by_lms_name(name)
            room = existing.room if existing else self._aliases.get(normalize_player_name(name)) or normalize_player_name(name or player_id)
            existing_by_name = self._players.get(room)

            self._players[room] = Player(
                room=room,
                id=player_id,
                name=existing_by_name.name if existing_by_name and existing_by_name.name else name or None,
                lms_name=name or None,
                dynamic=(existing is None and not (existing_by_name and not existing_by_name.dynamic)),
            )
            self._add_alias(room, room)
            if name:
                self._add_alias(name, room)

    def known_rooms(self) -> list[str]:
        return sorted(self._players)

    def known_names(self) -> list[str]:
        return sorted(alias for alias in self._aliases if " " in alias or len(alias) > 2)

    def get_by_lms_name(self, name: str | None) -> Player | None:
        if not name:
            return None
        normalized = normalize_player_name(name)
        for player in self._players.values():
            if player.lms_name and normalize_player_name(player.lms_name) == normalized:
                return player
        return None

    def _add_alias(self, value: str, room: str) -> None:
        for alias in player_name_aliases(value):
            if alias:
                self._aliases[alias] = room


def normalize_player_name(value: str | None) -> str:
    normalized = str(value or "").casefold().strip()
    normalized = normalized.replace("ß", "ss")
    normalized = re.sub(r"[^a-z0-9äöü]+", " ", normalized)
    return re.sub(r"\s+", " ", normalized).strip()


def compact_player_name(value: str | None) -> str:
    return normalize_player_name(value).replace(" ", "")


def player_name_aliases(value: str | None) -> set[str]:
    normalized = normalize_player_name(value)
    if not normalized:
        return set()

    aliases = {normalized, compact_player_name(normalized)}
    aliases.add(re.sub(r"\b([a-z0-9äöü]+)\s+s\s+", r"\1s ", normalized))
    aliases.add(re.sub(r"\b([a-z0-9äöü]+)s\s+", r"\1 s ", normalized))
    aliases.add(normalized.replace("weisses", "weiss"))
    aliases.add(normalized.replace("weiss", "weisses"))
    aliases.add(normalized.replace("weisses", "weissen"))
    aliases.add(normalized.replace("weiss", "weissen"))
    aliases.add(normalized.replace("weissen", "weisses"))
    aliases.add(normalized.replace("weissen", "weiss"))
    return {alias for alias in aliases if alias}
