from __future__ import annotations

from dataclasses import dataclass, field
import re
from typing import Any, Callable

from app.sessions import SessionState


def explicit_selection_index(cleaned: str, option_count: int) -> int | None:
    selection_noun = r"(?:album|hoerbuch|hörbuch|hoerspiel|hörspiel|sender|ordner|titel|option)"
    digit_match = re.fullmatch(
        rf"(?:(?:nummer|nr|position|auswahl|vorschlag)\s*)?(\d+)(?:\s+{selection_noun})?",
        cleaned,
    )
    if digit_match:
        index = int(digit_match.group(1)) - 1
        return index if 0 <= index < option_count else None

    number_words = {
        "erste": 1, "erstes": 1, "ersten": 1, "eins": 1,
        "zweite": 2, "zweites": 2, "zweiten": 2, "zwei": 2,
        "dritte": 3, "drittes": 3, "dritten": 3, "drei": 3,
        "vierte": 4, "viertes": 4, "vierten": 4, "vier": 4,
        "fuenfte": 5, "fünfte": 5, "fuenftes": 5, "fünftes": 5,
        "fuenften": 5, "fünften": 5, "fuenf": 5, "fünf": 5,
        "sechste": 6, "sechstes": 6, "sechsten": 6, "sechs": 6,
        "siebte": 7, "siebtes": 7, "siebten": 7, "sieben": 7,
        "achte": 8, "achtes": 8, "achten": 8, "acht": 8,
        "neunte": 9, "neuntes": 9, "neunten": 9, "neun": 9,
        "zehnte": 10, "zehntes": 10, "zehnten": 10, "zehn": 10,
        "elfte": 11, "elftes": 11, "elften": 11, "elf": 11,
        "zwoelfte": 12, "zwölfte": 12, "zwoelftes": 12, "zwölftes": 12,
        "zwoelften": 12, "zwölften": 12, "zwoelf": 12, "zwölf": 12,
    }
    for word, one_based_index in number_words.items():
        if re.fullmatch(rf"{re.escape(word)}(?:\s+{selection_noun})?", cleaned):
            index = one_based_index - 1
            return index if 0 <= index < option_count else None
    return None


@dataclass(frozen=True)
class DialogSpec:
    action: str
    selection_kind: str | None = None
    required_fields: tuple[str, ...] = ()
    response_mode: str = "short"
    prompt_action: str | None = None
    prompt_message: str | None = None
    target_prompt: str = "Auf welchem Player soll ich das spielen?"


@dataclass
class DialogState:
    spec: DialogSpec
    room: str | None = None
    fields: dict[str, Any] = field(default_factory=dict)
    options: list[dict] = field(default_factory=list)
    current_index: int | None = None


def make_session(state: DialogState, status: str | None = None) -> SessionState:
    data = dict(state.fields)
    data["dialog"] = {
        "action": state.spec.action,
        "selection_kind": state.spec.selection_kind,
        "required_fields": list(state.spec.required_fields),
        "response_mode": state.spec.response_mode,
        "prompt_action": state.spec.prompt_action,
        "prompt_message": state.spec.prompt_message,
        "target_prompt": state.spec.target_prompt,
    }
    if state.current_index is not None:
        data["current_index"] = state.current_index
    return SessionState(
        room=state.room,
        status=status or status_for_spec(state.spec),
        options=state.options,
        data=data,
    )


def state_from_session(session: SessionState) -> DialogState:
    dialog = dict(session.data.get("dialog") or {})
    spec = DialogSpec(
        action=str(dialog.get("action") or session.data.get("action") or session.status),
        selection_kind=dialog.get("selection_kind"),
        required_fields=tuple(dialog.get("required_fields") or ()),
        response_mode=str(dialog.get("response_mode") or "short"),
        prompt_action=dialog.get("prompt_action"),
        prompt_message=dialog.get("prompt_message"),
        target_prompt=str(dialog.get("target_prompt") or "Auf welchem Player soll ich das spielen?"),
    )
    fields = {key: value for key, value in session.data.items() if key not in {"dialog", "current_index"}}
    return DialogState(
        spec=spec,
        room=session.room,
        fields=fields,
        options=session.options,
        current_index=session.data.get("current_index"),
    )


def album_dialog_state(room: str | None, artist: str, options: list[dict]) -> DialogState:
    return DialogState(
        spec=DialogSpec(
            action="select_album_option",
            selection_kind="album",
            required_fields=("selection", "target_player"),
            response_mode="detailed",
            prompt_action="select_album",
            prompt_message="Welches Album soll ich spielen?",
            target_prompt="Auf welchem Player soll ich das Album spielen?",
        ),
        room=room,
        fields={"artist": artist},
        options=options,
    )


def radio_dialog_state(room: str | None, options: list[dict]) -> DialogState:
    return DialogState(
        spec=DialogSpec(
            action="select_radio_option",
            selection_kind="radio",
            required_fields=("selection", "target_player"),
            response_mode="detailed",
            prompt_action="select_radio",
            prompt_message="Welchen Radiosender soll ich spielen?",
            target_prompt="Auf welchem Player soll ich den Radiosender spielen?",
        ),
        room=room,
        options=options,
    )


def folder_dialog_state(room: str | None, options: list[dict], category: str | None = None) -> DialogState:
    is_audiobook = category == "audiobook"
    return DialogState(
        spec=DialogSpec(
            action="select_music_folder_option",
            selection_kind="folder",
            required_fields=("selection", "target_player"),
            response_mode="detailed",
            prompt_action="select_folder",
            prompt_message="Welches Hoerbuch soll ich spielen?" if is_audiobook else "Welchen Ordner soll ich spielen?",
            target_prompt="Auf welchem Player soll ich das Hoerbuch spielen?" if is_audiobook else "Auf welchem Player soll ich den Ordner spielen?",
        ),
        room=room,
        fields={"folder_category": category} if category else {},
        options=options,
    )


def target_dialog_state(parsed: dict, options: list[dict] | None = None, prompt: str | None = None) -> DialogState:
    return DialogState(
        spec=DialogSpec(
            action=str(parsed.get("action") or "unknown"),
            required_fields=("target_player",),
            response_mode="short",
            prompt_action="select_room",
            target_prompt=prompt or "Auf welchem Player soll ich das spielen?",
        ),
        room=parsed.get("room"),
        fields={"parsed": parsed},
        options=options or [],
    )


def status_for_spec(spec: DialogSpec) -> str:
    if spec.selection_kind == "album":
        return "waiting_album_selection"
    if spec.selection_kind == "radio":
        return "waiting_radio_selection"
    if spec.selection_kind == "folder":
        return "waiting_folder_selection"
    return "waiting_target"


def find_missing_fields(state: DialogState, has_target: bool, has_selection: bool = False) -> list[str]:
    missing = []
    for field_name in state.spec.required_fields:
        if field_name == "target_player" and not has_target:
            missing.append(field_name)
        elif field_name == "selection" and not has_selection:
            missing.append(field_name)
        elif field_name not in {"target_player", "selection"} and not state.fields.get(field_name):
            missing.append(field_name)
    return missing


def select_option(
    text: str,
    state: DialogState,
    selectors: dict[str, Callable[[str, DialogState], tuple[dict | None, int | None]]],
) -> tuple[dict | None, int | None]:
    if not state.spec.selection_kind:
        return None, None
    selector = selectors.get(state.spec.selection_kind)
    if not selector:
        return None, None
    return selector(text, state)
