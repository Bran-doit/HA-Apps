from __future__ import annotations

import re
from typing import Any


def parse_command(text: str, room: str | None, known_rooms: list[str]) -> dict[str, Any]:
    cleaned = normalize_polite_play_request(normalize_text(text))
    unsync_command = parse_unsync_command(cleaned, known_rooms)
    if unsync_command:
        return unsync_command

    sync_command = parse_sync_command(cleaned, clean_value(room), known_rooms)
    if sync_command:
        return sync_command

    continue_command = parse_continue_command(cleaned, clean_value(room), known_rooms)
    if continue_command:
        return continue_command

    detected_room, command_text = extract_target(cleaned, room, known_rooms)

    alarm_command = parse_alarm_command(command_text)
    if alarm_command:
        return {**alarm_command, "room": detected_room}

    volume_command = parse_volume_command(command_text)
    if volume_command:
        return {**volume_command, "room": detected_room}

    # Mood commands may contain phrases such as "Musik aus Pop" or "von 1990".
    # Parse them before transport and title patterns interpret those words differently.
    metadata_playlist = parse_metadata_playlist(command_text)
    if metadata_playlist:
        return {**metadata_playlist, "room": detected_room}

    transport_command = parse_transport_command(command_text)
    if transport_command:
        return {**transport_command, "room": detected_room}

    album_selection_jump = parse_album_selection_jump(command_text)
    if album_selection_jump:
        return {**album_selection_jump, "room": detected_room}

    current_album_command = parse_current_album_command(command_text)
    if current_album_command:
        return {**current_album_command, "room": detected_room}

    similar_command = parse_similar_command(command_text)
    if similar_command:
        return {**similar_command, "room": detected_room}

    radio_command = parse_radio_command(command_text)
    if radio_command:
        return {**radio_command, "room": detected_room}

    library_query = parse_library_query(command_text)
    if library_query:
        return {**library_query, "room": detected_room}

    audiobook_query = parse_audiobook_library_query(command_text)
    if audiobook_query:
        return {**audiobook_query, "room": detected_room}

    music_folder = parse_music_folder_command(command_text)
    if music_folder:
        return {**music_folder, "room": detected_room}

    title_command = parse_title_command(command_text)
    if title_command:
        return {**title_command, "room": detected_room}

    album_title = parse_album_title(command_text)
    if album_title:
        return {**album_title, "room": detected_room}

    album_dialog = parse_album_dialog(command_text)
    if album_dialog:
        return {**album_dialog, "room": detected_room}

    artist_playlist = parse_artist_playlist(command_text)
    if artist_playlist:
        return {**artist_playlist, "room": detected_room}

    genre_playlist = parse_genre_playlist(command_text)
    if genre_playlist:
        return {**genre_playlist, "room": detected_room}

    return {"action": "unknown", "room": detected_room}


def parse_audiobook_library_query(cleaned: str) -> dict[str, Any] | None:
    command = transliterate_german_umlauts(cleaned.casefold())
    match = re.match(
        r"^(?:welche|was\s+fuer)\s+(?:hoerbuecher|hoerspiele)\s+"
        r"(?:haben\s+wir|findest\s+du|gibt\s+es)\s+(?:in\s+der\s+datenbank\s+)?"
        r"(?:von|vom|zu|ueber)\s+(.+?)\??$",
        command,
    )
    if not match:
        return None
    return {
        "action": "list_audiobooks",
        "folder_category": "audiobook",
        "folder_query": cleanup_music_folder_query(match.group(1)),
        "shuffle": False,
    }


TIME_UNITS = {
    "null": 0,
    "ein": 1,
    "eins": 1,
    "zwei": 2,
    "drei": 3,
    "vier": 4,
    "fuenf": 5,
    "funf": 5,
    "fünf": 5,
    "sechs": 6,
    "sieben": 7,
    "acht": 8,
    "neun": 9,
}
TIME_TEENS = {
    "zehn": 10,
    "elf": 11,
    "zwoelf": 12,
    "zwölf": 12,
    "dreizehn": 13,
    "vierzehn": 14,
    "fuenfzehn": 15,
    "funfzehn": 15,
    "fünfzehn": 15,
    "sechzehn": 16,
    "siebzehn": 17,
    "achtzehn": 18,
    "neunzehn": 19,
}
TIME_TENS = {
    "zwanzig": 20,
    "dreissig": 30,
    "dreißig": 30,
    "vierzig": 40,
    "fuenfzig": 50,
    "funfzig": 50,
    "fünfzig": 50,
}


def parse_time_number(value: str) -> int | None:
    value = value.strip().casefold().replace(" ", "")
    if value.isdigit():
        return int(value)
    if value in TIME_UNITS:
        return TIME_UNITS[value]
    if value in TIME_TEENS:
        return TIME_TEENS[value]
    if value in TIME_TENS:
        return TIME_TENS[value]
    match = re.fullmatch(r"(.+?)und(.+)", value)
    if not match:
        return None
    unit = TIME_UNITS.get(match.group(1))
    tens = TIME_TENS.get(match.group(2))
    return unit + tens if unit is not None and tens is not None else None


def parse_alarm_time(text: str) -> tuple[int, int] | None:
    token = r"(?:\d{1,2}|[a-zäöüß]+)"
    match = re.search(rf"\bum\s+({token})(?:(?::|\s+uhr\s+)({token}))?\s*(?:uhr)?\b", text)
    if not match:
        return None
    hour = parse_time_number(match.group(1))
    minute = parse_time_number(match.group(2)) if match.group(2) else 0
    if minute is None:
        hour_only = re.search(rf"\bum\s+({token})\s+uhr\b", text)
        if hour_only:
            hour = parse_time_number(hour_only.group(1))
            minute = 0
    if hour is None or minute is None or hour > 23 or minute > 59:
        return None
    return hour, minute


def parse_alarm_command(text: str) -> dict[str, Any] | None:
    if re.search(r"\b(?:ich moechte|ich möchte|lass mich) noch(?:(?: ein bisschen| etwas))? schlafen\b", text) or re.search(
        r"\b(?:schlummer(?:e|n)?|snooze)(?: noch einmal| noch|n)?(?: fuer| für)?(?: (\d+|[a-zäöü]+) minuten?)?\b",
        text,
    ):
        minutes_match = re.search(r"(?:fuer|für|noch)\s+(\d+|[a-zäöü]+)\s+minuten?", text)
        return {
            "action": "alarm_snooze",
            "minutes": parse_time_number(minutes_match.group(1)) if minutes_match else None,
        }

    if "alle wecker" not in text and (
        re.search(r"\b(?:beende|stoppe)\b.*\b(?:klingelnden? )?wecker\b", text)
        or re.search(r"\bwecker\b.*\b(?:beenden|stoppen|aus|ab)\b", text)
    ):
        return {"action": "alarm_stop"}

    if re.search(r"\b(?:welche|zeige|liste)\b.*\bwecker\b", text) or re.fullmatch(r"wecker", text):
        return {"action": "alarm_list"}

    if re.search(r"\bdeaktiviere\b.*\balle wecker\b", text) or re.search(r"\bschalt(?:e)?\b.*\balle wecker\b.*\baus\b", text):
        return {"action": "alarm_disable_all"}
    if re.search(r"\baktiviere\b.*\balle wecker\b", text) or re.search(r"\bschalt(?:e)?\b.*\balle wecker\b.*\bein\b", text):
        return {"action": "alarm_enable_all"}
    if re.search(r"\b(?:loesche|lösche|entferne)\b.*\balle wecker\b", text):
        return {"action": "alarm_delete_all"}
    if re.search(r"\b(?:loesche|lösche|entferne)\b.*\b(?:naechsten|nächsten) wecker\b", text):
        return {"action": "alarm_delete_next"}
    if re.search(r"\bdeaktiviere\b.*\b(?:naechsten|nächsten) wecker\b", text):
        return {"action": "alarm_disable_next"}

    if not re.search(r"\bweck(?:e|t)?\b|\bwecker\b", text):
        return None

    relative_match = re.search(r"\bin\s+(\d+|[a-zäöü]+)\s+minuten?\b", text)
    alarm_time = parse_alarm_time(text)
    if relative_match:
        minutes = parse_time_number(relative_match.group(1))
        if minutes is not None and minutes > 0:
            return {"action": "alarm_create", "relative_minutes": minutes, "repeat": False}
    if not alarm_time:
        return None

    hour, minute = alarm_time

    weekdays = bool(re.search(r"\bwerktags\b|\bunter der woche\b|\bmontags? bis freitags?\b", text))
    daily = bool(re.search(r"\b(?:immer|jeden tag|jeden morgen|taeglich|täglich)\b", text))
    tomorrow = bool(re.search(r"\bmorgen\b", text)) and not daily
    return {
        "action": "alarm_create",
        "hour": hour,
        "minute": minute,
        "schedule": "weekdays" if weekdays else "daily" if daily else "tomorrow" if tomorrow else "next",
        "repeat": weekdays or daily,
    }


def normalize_text(text: str) -> str:
    text = text.casefold()
    text = text.replace("ß", "ss")
    text = text.replace("Ã¤", "ä").replace("Ã¶", "ö").replace("Ã¼", "ü")
    text = re.sub(r"\s+", " ", text)
    return text.strip(" .,!?:;")


def normalize_polite_play_request(text: str) -> str:
    """Turn a polite question ending in 'spielen' into the regular play form."""
    match = re.match(
        r"^(?:kannst|koenntest|könntest|wuerdest|würdest)\s+du\s+"
        r"(?:(?:bitte|mir|mal|doch)\s+)*(?P<request>.+?)\s+"
        r"(?:spielen|wiedergeben)$",
        text,
    )
    if not match:
        return text
    return f"spiele {match.group('request').strip()}"


PLAY_PREFIX = r"(?:spiele|spiel|gebe\s+wieder|gib\s+wieder|gebe|gib)"
LEADING_FILLERS = {
    "bitte",
    "mir",
    "mal",
    "doch",
    "gerne",
    "jetzt",
    "etwas",
    "bisschen",
    "bischen",
}
PROTECTED_LEADING_KEYWORDS = {
    "album",
    "alben",
    "platte",
    "platten",
    "radio",
    "internetradio",
    "sender",
    "titel",
    "song",
    "track",
    "tracks",
    "musik",
    "stuecke",
    "stücke",
    "stilrichtung",
    "musikrichtung",
    "genre",
    "aehnliche",
    "ähnliche",
    "vergleichbare",
}


def strip_play_prefix(cleaned: str) -> str | None:
    match = re.match(rf"^\b{PLAY_PREFIX}\b\s*(.*)$", cleaned)
    if not match:
        return None
    return strip_leading_fillers(match.group(1).strip())


def strip_leading_fillers(value: str) -> str:
    words = value.split()
    while words:
        current = words[0]
        if current in {"ein", "eine", "einen", "das", "den", "die", "alle"}:
            if len(words) > 1 and words[1] in PROTECTED_LEADING_KEYWORDS:
                break
        elif current not in LEADING_FILLERS:
            break
        words.pop(0)
    return " ".join(words)


NUMBER_WORDS = {
    "ein": 1,
    "eine": 1,
    "einen": 1,
    "eins": 1,
    "zwei": 2,
    "drei": 3,
    "vier": 4,
    "fuenf": 5,
    "funf": 5,
    "fünf": 5,
    "sechs": 6,
    "sieben": 7,
    "acht": 8,
    "neun": 9,
    "zehn": 10,
}


def parse_count(value: str) -> int:
    value = value.strip().casefold()
    if value.isdigit():
        return max(1, int(value))
    return max(1, NUMBER_WORDS.get(value, 1))


def count_pattern() -> str:
    words = "|".join(sorted(map(re.escape, NUMBER_WORDS), key=len, reverse=True))
    return rf"(?:\d+|{words})"


def extract_target(cleaned: str, room: str | None, known_rooms: list[str]) -> tuple[str | None, str]:
    detected_room = clean_value(room)
    command_text = cleaned
    for known_room in sorted(known_rooms, key=len, reverse=True):
        pattern = room_name_pattern(known_room)
        match = re.search(rf"\b(?:im|in|auf|am|mit)\s+(?:dem|den|das|die)?\s*{pattern}\b", command_text)
        if not match:
            match = re.search(pattern, command_text)
        if match:
            detected_room = known_room
            command_text = (command_text[: match.start()] + " " + command_text[match.end() :]).strip()
            command_text = re.sub(r"\s+", " ", command_text)
            break

    if not detected_room:
        match = re.search(r"\b(?:im|in|auf|am)\s+(?:dem|den|das|die)?\s*([a-z0-9äöü][a-z0-9äöü\s_\-']{1,50})$", command_text)
        if match:
            target = cleanup_query(match.group(1))
            duration_match = re.fullmatch(r"(\d+|[a-zäöüß]+)\s+minuten?", target)
            relative_duration = bool(duration_match and parse_time_number(duration_match.group(1)) is not None)
            if target and not relative_duration and target not in {"the air tonight", "datenbank", "der datenbank", "meiner datenbank"}:
                detected_room = target
                command_text = command_text[: match.start()].strip()

    return detected_room, command_text


def parse_sync_command(cleaned: str, room: str | None, known_rooms: list[str]) -> dict[str, Any] | None:
    if not re.search(r"\bsynchronisier(?:e|en)?\b", cleaned):
        return None
    targets = targets_in_text(cleaned, known_rooms)
    if len(targets) >= 2:
        source = targets[0]
        target = targets[1]
    else:
        source = room
        match = re.search(r"\bmit\s+(?:dem|den|das|die)?\s*(.+)$", cleaned)
        target = cleanup_query(match.group(1)) if match else (targets[0] if targets else None)
    return {
        "action": "sync_players",
        "source_room": source,
        "target_room": target,
        "room": target,
    }


def parse_unsync_command(cleaned: str, known_rooms: list[str]) -> dict[str, Any] | None:
    if re.search(r"\b(?:synchronisierung|synchronisation|synchronisierungen|sync)\b", cleaned) and re.search(
        r"\b(?:abbrechen|beenden|aufheben|loesche|loeschen|lösche|löschen|loese|loesen|löse|lösen|aufloese|aufloesen|auflöse|auflösen|trenne|trennen)\b",
        cleaned,
    ):
        targets = targets_in_text(cleaned, known_rooms)
        if len(targets) >= 2:
            return {
                "action": "unsync_players",
                "source_room": targets[0],
                "target_room": targets[1],
                "room": None,
            }

    if re.search(r"\b(?:synchronisierung|synchronisation|synchronisierungen|sync)\b", cleaned) and re.search(
        r"\b(?:abbrechen|beenden|aufheben|loesche|loeschen|lösche|löschen|loese|loesen|löse|lösen|aufloese|aufloesen|auflöse|auflösen|trenne|trennen)\b",
        cleaned,
    ):
        return {
            "action": "unsync_all",
            "room": None,
        }

    if not re.search(r"\b(?:synchronisierung|synchronisation|synchronisierungen|sync)\b", cleaned):
        return None
    if not re.search(r"\b(?:abbrechen|beenden|aufheben|loeschen|lÃ¶schen|loesen|lÃ¶sen|aufloesen|auflÃ¶sen|trennen)\b", cleaned):
        return None
    return {
        "action": "unsync_all",
        "room": None,
    }


def parse_continue_command(cleaned: str, room: str | None, known_rooms: list[str]) -> dict[str, Any] | None:
    if not re.search(r"\b(?:setze|wiedergabe|playlist)\b", cleaned):
        return None
    if not re.search(r"\b(?:weiter|fortsetzen|fort|verschieben|uebernehmen|übernehmen)\b", cleaned):
        return None
    targets = targets_in_text(cleaned, known_rooms)
    source = targets[0] if len(targets) > 1 else None
    target = targets[-1] if targets else room
    return {
        "action": "continue_playback",
        "source_room": source,
        "target_room": target,
        "room": target,
    }


def parse_volume_command(cleaned: str) -> dict[str, Any] | None:
    music_set_match = re.search(
        r"\b(?:(?:setze|stelle|mach(?:e)?)\s+)?(?:die\s+)?musik\s+(?:auf\s+)?(\d{1,3})\s*(?:%|prozent)?\b",
        cleaned,
    )
    if music_set_match:
        return {"action": "volume", "volume_mode": "set", "volume_value": clamp_percent(music_set_match.group(1))}

    set_match = re.search(r"\b(?:setze\s+die\s+)?lautst(?:ae|ä)rke\s+(?:auf\s+)?(\d{1,3})\s*%?\b", cleaned)
    if not set_match:
        set_match = re.search(r"\bvolume\s+(?:auf\s+)?(\d{1,3})\s*%?\b", cleaned)
    if set_match:
        return {"action": "volume", "volume_mode": "set", "volume_value": clamp_percent(set_match.group(1))}

    up_match = re.search(r"\b(?:erhoehe|erhöhe|steigere)\s+(?:die\s+)?lautst(?:ae|ä)rke\s+um\s+(\d{1,3})\s*%?\b", cleaned)
    if up_match:
        return {"action": "volume", "volume_mode": "change", "volume_value": clamp_percent(up_match.group(1))}

    down_match = re.search(r"\b(?:verringere|reduziere|senke)\s+(?:die\s+)?lautst(?:ae|ä)rke\s+um\s+(\d{1,3})\s*%?\b", cleaned)
    if down_match:
        return {"action": "volume", "volume_mode": "change", "volume_value": -clamp_percent(down_match.group(1))}

    if re.search(r"\b(?:mach(?:e)?\s+die\s+musik\s+lauter|musik\s+etwas\s+lauter|erhoehe\s+die\s+lautst(?:ae|ä)rke|erhöhe\s+die\s+lautst(?:ae|ä)rke|lauter)\b", cleaned):
        return {"action": "volume", "volume_mode": "change", "volume_value": 5}

    if re.search(r"\b(?:mach(?:e)?\s+die\s+musik\s+leiser|musik\s+etwas\s+leiser|verringere\s+die\s+lautst(?:ae|ä)rke|leiser)\b", cleaned):
        return {"action": "volume", "volume_mode": "change", "volume_value": -5}

    return None


def parse_transport_command(cleaned: str) -> dict[str, Any] | None:
    number = count_pattern()
    jump_word_match = re.search(
        rf"\b({number})\s+(?:tracks?|titel)\s+(vor|weiter|vorspringen|zurueck|zurück|zurueckspringen|zurückspringen|zurueckbringen|zurückbringen)\b",
        cleaned,
    )
    if not jump_word_match:
        jump_word_match = re.search(
            rf"\bspring(?:e)?\s+(?:bitte\s+)?({number})\s+(?:tracks?|titel)\s+(vor|weiter|zurueck|zurück)\b",
            cleaned,
        )
    if jump_word_match:
        count = parse_count(jump_word_match.group(1))
        direction = jump_word_match.group(2)
        delta = count if direction.startswith(("vor", "weiter")) else -count
        return {"action": "transport_jump", "transport_command": "jump", "jump_count": delta}

    bring_back_match = re.search(r"\b(\d+)\s+(?:tracks?|titel)\s+(?:zurueckbringen|zurückbringen)\b", cleaned)
    if bring_back_match:
        count = max(1, int(bring_back_match.group(1)))
        return {"action": "transport_jump", "transport_command": "jump", "jump_count": -count}

    if re.search(
        r"\b(?:musik\s+(?:aus|ausmachen|abschalten)|"
        r"(?:das\s+)?radio\s+(?:aus|ausschalten|ausmachen|abschalten|still)|"
        r"(?:schalt(?:e)?|mach(?:e)?)\s+(?:das\s+)?radio(?:\s+(?:aus|still))?$|"
        r"bitte\s+ruhe|stille|stopp|stop|stoppen|anhalten|pause|pausieren)\b",
        cleaned,
    ):
        return {"action": "transport", "transport_command": "stop"}

    if re.search(r"\b(?:musik\s+an|weiterspielen|weiter\s+spielen|fortsetzen|resume)\b", cleaned):
        return {"action": "transport", "transport_command": "play"}

    jump_match = re.search(r"\b(\d+)\s+(?:tracks?|titel)\s+(vor|vorspringen|zurueck|zurück|zurueckspringen|zurückspringen)\b", cleaned)
    if not jump_match:
        jump_match = re.search(r"\bspringe\s+(\d+)\s+(?:tracks?|titel)\s+(vor|zurueck|zurück)", cleaned)
    if jump_match:
        count = max(1, int(jump_match.group(1)))
        direction = jump_match.group(2)
        delta = count if direction.startswith("vor") else -count
        return {"action": "transport_jump", "transport_command": "jump", "jump_count": delta}

    if re.search(r"\b(?:ein(?:en)?\s+)?(?:track|titel)\s+(?:vor|vorspringen)|\bn(?:ae|ä)chster\s+(?:track|titel)|\bspringe\s+ein(?:en)?\s+(?:track|titel)\s+vor\b", cleaned):
        return {"action": "transport_jump", "transport_command": "jump", "jump_count": 1}

    if re.search(r"\b(?:ein(?:en)?\s+)?(?:track|titel)\s+(?:zurueck|zurück|zurueckspringen|zurückspringen)|\b(?:vorhergehender|voriger|vorheriger)\s+(?:track|titel)|\bspringe\s+ein(?:en)?\s+(?:track|titel)\s+zur", cleaned):
        return {"action": "transport_jump", "transport_command": "jump", "jump_count": -1}

    return None


def parse_album_selection_jump(cleaned: str) -> dict[str, Any] | None:
    next_album = (
        r"\b(?:(?:spiel|spiele)\s+)?(?:bitte\s+)?(?:"
        r"(?:das\s+)?"
        r"(?:ein(?:en)?\s+)?album\s+(?:vor|vorspringen)|"
        r"(?:das\s+)?n(?:ae|ä)chste(?:s|n|r)?\s+album"
        r")(?:\s+abspielen)?\b"
    )
    previous_album = (
        r"\b(?:(?:spiel|spiele)\s+)?(?:bitte\s+)?(?:"
        r"(?:das\s+)?"
        r"(?:ein(?:en)?\s+)?album\s+(?:zurueck|zurück|zurueckspringen|zurückspringen)|"
        r"(?:das\s+)?(?:voriges|vorheriges|vorhergehendes|vorhergehende(?:s|n|r)?)\s+album"
        r")(?:\s+abspielen)?\b"
    )
    if re.search(next_album, cleaned):
        return {"action": "album_selection_jump", "album_jump": 1}
    if re.search(previous_album, cleaned):
        return {"action": "album_selection_jump", "album_jump": -1}

    if re.search(r"\b(?:ein(?:en)?\s+)?album\s+(?:vor|vorspringen)|\bn(?:ae|Ã¤)chstes\s+album\b", cleaned):
        return {"action": "album_selection_jump", "album_jump": 1}

    if re.search(r"\b(?:ein(?:en)?\s+)?album\s+(?:zurueck|zurÃ¼ck|zurueckspringen|zurÃ¼ckspringen)|\b(?:voriges|vorheriges|vorhergehendes)\s+album\b", cleaned):
        return {"action": "album_selection_jump", "album_jump": -1}

    return None


def parse_current_album_command(cleaned: str) -> dict[str, Any] | None:
    has_album = re.search(r"\b(?:album|albums)\b", cleaned)
    current_reference = re.search(
        r"\b(?:laufende[nsr]?|laufenden|laufender|laufen)\s+(?:musik|track|titel|wiedergabe)\b"
        r"|\b(?:musik|track|titel|wiedergabe)\s+(?:die\s+)?(?:gerade\s+)?(?:laeuft|läuft|laufende[nsr]?|laufenden)\b",
        cleaned,
    )
    if has_album and current_reference:
        return {"action": "play_current_album", "shuffle": False}
    if re.search(r"\b(?:das\s+)?(?:entsprechende|zugehoerige|zugehörige|ganze)\s+album\s+(?:dazu|zur\s+wiedergabe)?\b", cleaned):
        return {"action": "play_current_album", "shuffle": False}
    if re.search(r"\b(?:das\s+)?album\s+(?:zur|zum|zu\s+der)\s+laufenden\s+(?:musik|track|titel|wiedergabe)\b", cleaned):
        return {"action": "play_current_album", "shuffle": False}
    return None


def parse_similar_command(cleaned: str) -> dict[str, Any] | None:
    match = re.search(r"\b(?:spiele|spiel|gebe|gib)\s+(?:(?:bitte|mir)\s+)*(?:aehnliche|ähnliche|vergleichbare)\s+musik(?:\s+von\s+(.+))?$", cleaned)
    if match:
        return {"action": "play_similar", "artist": cleanup_query(match.group(1) or ""), "shuffle": True}
    if re.search(r"\b(?:mehr\s+davon|etwas\s+aehnliches|etwas\s+ähnliches|aehnliche\s+musik|ähnliche\s+musik)\b", cleaned):
        return {"action": "play_similar", "shuffle": True}
    return None


def parse_radio_command(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    match = re.match(r"^(?:das\s+|den\s+)?(?:radio|internetradio|sender)(?:\s+(.+))?$", command)
    if not match:
        return None
    radio = cleanup_query(strip_leading_fillers(match.group(1) or ""))
    return {"action": "play_radio_dialog" if not radio else "play_radio", "radio": radio, "shuffle": False}


def parse_library_query(cleaned: str) -> dict[str, Any] | None:
    match = re.search(
        r"\bhabe\s+ich\s+(?:musik|stuecke|stücke|tracks?|titel)\s+(?:von|bei)\s+(.+?)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "list_artist_albums", "artist": cleanup_query(match.group(1)), "include_sampler_titles": True}

    match = re.search(
        r"\bfindest\s+du\s+(?:musik|stuecke|stücke|tracks?|titel)\s+(?:von|bei)\s+(.+?)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "list_artist_albums", "artist": cleanup_query(match.group(1)), "include_sampler_titles": True}

    match = re.search(
        r"\bwelche\s+(?:musik|stuecke|stÃ¼cke|tracks?|titel)\s+(?:habe\s+ich|findest\s+du)\s+von\s+(.+?)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "list_artist_albums", "artist": cleanup_query(match.group(1)), "include_sampler_titles": True}

    match = re.search(
        r"\bwelche\s+(?:musik|stuecke|stÃ¼cke|tracks?|titel)\s+von\s+(.+?)\s+(?:habe\s+ich|findest\s+du)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "list_artist_albums", "artist": cleanup_query(match.group(1)), "include_sampler_titles": True}

    match = re.search(
        r"\bwelche\s+(?:alben|album|platten|platte)\s+(?:habe\s+ich|findest\s+du)\s+von\s+(.+?)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "list_artist_albums", "artist": cleanup_query(match.group(1)), "include_sampler_titles": False}

    match = re.search(
        r"\bwelche\s+(?:alben|album|platten|platte)\s+von\s+(.+?)\s+(?:habe\s+ich|findest\s+du)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "list_artist_albums", "artist": cleanup_query(match.group(1)), "include_sampler_titles": False}

    return None


def parse_title_command(cleaned: str) -> dict[str, Any] | None:
    prefix = PLAY_PREFIX
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    polite = r"(?:(?:bitte|mir|mal|doch|gerne|jetzt|etwas)\s+)*"
    title_marker = r"(?:(?:den|das)\s+)?(?:titel|song|track)"

    match = re.search(
        rf"\b{prefix}\s+{polite}{title_marker}\s+(.+?)\s+von\s+(?:von\s+)?(.+?)(?:\s+wieder)?$",
        cleaned,
    )
    if match:
        title = cleanup_query(strip_play_suffix(match.group(1)))
        artist = cleanup_query(strip_play_suffix(match.group(2)))
        if title and artist:
            return {"action": "play_title", "title": title, "artist": artist, "shuffle": False}

    match = re.search(
        rf"\b{prefix}\s+{polite}von\s+(.+?)\s+{title_marker}\s+(.+?)(?:\s+wieder)?$",
        cleaned,
    )
    if match:
        artist = cleanup_query(strip_play_suffix(match.group(1)))
        title = cleanup_query(strip_play_suffix(match.group(2)))
        if title and artist:
            return {"action": "play_title", "title": title, "artist": artist, "shuffle": False}

    command = strip_play_suffix(command)
    if re.search(r"\s+von\s+(?:von\s+)?", command):
        title_part, artist_part = re.split(r"\s+von\s+(?:von\s+)?", command, maxsplit=1)
        title = cleanup_query(strip_play_suffix(title_part))
        artist = cleanup_query(strip_play_suffix(artist_part))
        if title and artist and not looks_like_non_title_request(title):
            return {"action": "play_title", "title": title, "artist": artist, "shuffle": False}

    return None


def strip_play_suffix(value: str) -> str:
    return re.sub(r"\s+wieder$", "", value.strip()).strip()


def looks_like_non_title_request(value: str) -> bool:
    return bool(
        re.match(
            r"^(?:musik|stuecke|stücke|tracks?|titel|alben|album|platten|platte|ein\s+album|eine\s+platte|radio|internetradio|sender|etwas|ein\s+bisschen|aehnliche|ähnliche|vergleichbare)\b",
            value,
        )
    )


def parse_album_title(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    match = re.match(r"^(?:das\s+|die\s+|den\s+)?(?:album|platte)\s+(.+)$", command)
    if not match:
        return None
    album = cleanup_query(strip_play_suffix(match.group(1)))
    if not album or album.startswith(("von ", "vom ")):
        return None
    return {"action": "play_album_title", "album": album, "shuffle": False}


def parse_album_dialog(cleaned: str) -> dict[str, Any] | None:
    match = re.search(
        r"\bwelche\s+(?:alben|album|platten|platte)\s+(?:habe\s+ich|findest\s+du)\s+von\s+(.+?)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "play_album_dialog", "artist": cleanup_query(match.group(1)), "shuffle": False}

    match = re.search(
        r"\bwelche\s+(?:alben|album|platten|platte)\s+von\s+(.+?)\s+(?:habe\s+ich|findest\s+du)(?:\s+(?:in\s+der\s+datenbank|in\s+meiner\s+datenbank|bei\s+mir))?$",
        cleaned,
    )
    if match:
        return {"action": "play_album_dialog", "artist": cleanup_query(match.group(1)), "shuffle": False}

    command = strip_play_prefix(cleaned)
    match = re.match(r"^(?:die\s+|alle\s+|ein\s+|eine\s+)?(?:alben|album|platten|platte)\s+von\s+(.+)$", command or "")
    if match:
        return {"action": "play_album_dialog", "artist": cleanup_query(match.group(1)), "shuffle": False}
    return None


def parse_artist_playlist(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    match = re.match(r"^(?:vom|von\s+dem)\s+(.+)$", command)
    if match:
        return {"action": "play_artist_playlist", "artist": cleanup_query(match.group(1)), "shuffle": True}
    match = re.match(r"^(?:(?:musik|stuecke|stücke|tracks?|titel)\s+)?von\s+(.+)$", command)
    if match:
        return {"action": "play_artist_playlist", "artist": cleanup_query(match.group(1)), "shuffle": True}
    return None


def parse_music_folder_command(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    match = re.match(
        r"^(?:(?:das|die|den|ein|eine|einen)\s+)?"
        r"(?P<kind>hoerbuch|hÃ¶rbuch|hÃƒÂ¶rbuch|hoerspiel|hÃ¶rspiel|hÃƒÂ¶rspiel|comedy|komoedie|komÃ¶die|komÃƒÂ¶die|humor|musikordner|ordner)"
        r"(?:\s+(?P<query>.+))?$",
        command,
    )
    if not match:
        return None
    query = cleanup_query(strip_play_suffix(match.group("query") or ""))
    return {
        "action": "play_music_folder",
        "folder_category": normalize_music_folder_kind(match.group("kind")),
        "folder_query": query,
        "shuffle": False,
    }


def normalize_music_folder_kind(value: str) -> str:
    normalized = value.casefold()
    if normalized in {"hoerbuch", "hÃ¶rbuch", "hÃƒÂ¶rbuch", "hoerspiel", "hÃ¶rspiel", "hÃƒÂ¶rspiel"}:
        return "audiobook"
    if normalized in {"comedy", "komoedie", "komÃ¶die", "komÃƒÂ¶die", "humor"}:
        return "comedy"
    return "folder"


def parse_music_folder_command(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    match = re.match(
        r"^(?:(?:das|die|den|ein|eine|einen)\s+)?"
        r"(?P<kind>hoerbuch|hoerbuecher|hÃƒÂ¶rbuch|hÃƒÂ¶rbuecher|hÃƒÆ’Ã‚Â¶rbuch|hÃƒÆ’Ã‚Â¶rbuecher|hoerspiel|hoerspiele|hÃƒÂ¶rspiel|hÃƒÂ¶rspiele|hÃƒÆ’Ã‚Â¶rspiel|hÃƒÆ’Ã‚Â¶rspiele|comedy|comedian|comedians|komiker|kabarett|kabarettist|kabarettisten|komoedie|komÃƒÂ¶die|komÃƒÆ’Ã‚Â¶die|humor|musikordner|ordner)"
        r"(?:\s+(?P<query>.+))?$",
        command,
    )
    if not match:
        return None
    return {
        "action": "play_music_folder",
        "folder_category": normalize_music_folder_kind(match.group("kind")),
        "folder_query": cleanup_music_folder_query(match.group("query") or ""),
        "shuffle": False,
    }


def normalize_music_folder_kind(value: str) -> str:
    normalized = value.casefold()
    if normalized in {
        "hoerbuch",
        "hoerbuecher",
        "hÃƒÂ¶rbuch",
        "hÃƒÂ¶rbuecher",
        "hÃƒÆ’Ã‚Â¶rbuch",
        "hÃƒÆ’Ã‚Â¶rbuecher",
        "hoerspiel",
        "hoerspiele",
        "hÃƒÂ¶rspiel",
        "hÃƒÂ¶rspiele",
        "hÃƒÆ’Ã‚Â¶rspiel",
        "hÃƒÆ’Ã‚Â¶rspiele",
    }:
        return "audiobook"
    if normalized in {
        "comedy",
        "comedian",
        "comedians",
        "komiker",
        "kabarett",
        "kabarettist",
        "kabarettisten",
        "komoedie",
        "komÃƒÂ¶die",
        "komÃƒÆ’Ã‚Â¶die",
        "humor",
    }:
        return "comedy"
    return "folder"


def cleanup_music_folder_query(value: str) -> str:
    value = cleanup_query(strip_play_suffix(value))
    value = re.sub(r"^(?:von|vom|von\s+dem|von\s+der|ueber|ÃƒÂ¼ber|mit|namens|titel)\s+", "", value)
    value = re.sub(r"^(?:das|die|den|ein|eine|einen)\s+", "", value)
    return cleanup_query(value)


def parse_music_folder_command(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None
    command_key = transliterate_german_umlauts(command)
    match = re.match(
        r"^(?:(?:das|die|den|ein|eine|einen)\s+)?"
        r"(?P<kind>hoerbuch|hoerbuecher|hoerspiel|hoerspiele|comedy|comedian|comedians|komiker|kabarett|kabarettist|kabarettisten|komoedie|humor|musikordner|ordner)"
        r"(?:\s+(?P<query>.+))?$",
        command_key,
    )
    if not match:
        return None
    return {
        "action": "play_music_folder",
        "folder_category": normalize_music_folder_kind(match.group("kind")),
        "folder_query": cleanup_music_folder_query(match.group("query") or ""),
        "shuffle": False,
    }


def normalize_music_folder_kind(value: str) -> str:
    normalized = transliterate_german_umlauts(value.casefold())
    if normalized in {"hoerbuch", "hoerbuecher", "hoerspiel", "hoerspiele"}:
        return "audiobook"
    if normalized in {
        "comedy",
        "comedian",
        "comedians",
        "komiker",
        "kabarett",
        "kabarettist",
        "kabarettisten",
        "komoedie",
        "humor",
    }:
        return "comedy"
    return "folder"


def transliterate_german_umlauts(value: str) -> str:
    return (
        value.replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("Ä", "ae")
        .replace("Ö", "oe")
        .replace("Ü", "ue")
    )


def parse_genre_playlist(cleaned: str) -> dict[str, Any] | None:
    genre = strip_play_prefix(cleaned)
    if genre is None:
        return None
    genre = re.sub(r"^(?:ein\s+bisschen|ein\s+bischen)\s+", "", genre).strip()
    genre = normalize_genre_alias(cleanup_query(genre))
    if re.search(r"\b(?:titel|song|track)\b", genre):
        return None
    if not genre or re.match(r"^(?:musik|stuecke|stücke|tracks?|titel|alben|platten|ein\s+album|eine\s+platte|radio|internetradio|sender)\b", genre):
        return None
    return {"action": "play_genre", "genre": genre, "shuffle": True}


def normalize_genre_alias(value: str) -> str:
    aliases = {
        "rockmusik": "rock",
        "popmusik": "pop",
        "folkmusik": "folk",
        "reggae-musik": "reggae",
        "reggaemusik": "reggae",
        "lateinamerikanische musik": "latin",
        "schlagermusik": "schlager",
    }
    cleaned = cleanup_query(value)
    return aliases.get(cleaned.casefold(), cleaned)


def parse_metadata_playlist(cleaned: str) -> dict[str, Any] | None:
    command = strip_play_prefix(cleaned)
    if command is None:
        return None

    normalized = transliterate_german_umlauts(command)
    traits: list[str] = []
    if re.search(r"\b(?:entspannt\w*|entspannend\w*|entspannen|ruhig\w*|chillig\w*|relaxed)\b", normalized):
        traits.append("relaxed")
    if re.search(r"\b(?:anregend\w*|anregung|energiegeladen\w*|energetisch\w*|aufregend\w*|wild\w*)\b", normalized):
        traits.append("stimulating")
    if re.search(r"\b(?:froehlich\w*|heiter\w*|lustig\w*|gut(?:e|er)?\s+laune)\b", normalized):
        traits.append("happy")
    if re.search(r"\b(?:melancholisch\w*|melancholie|traurig\w*|schwermuetig\w*)\b", normalized):
        traits.append("melancholic")
    if re.search(r"\b(?:tanzbar\w*|dancebar\w*|zum\s+tanzen|tanzmusik)\b", normalized):
        traits.append("danceable")
    if re.search(r"\b(?:instrumental\w*|ohne\s+gesang)\b", normalized):
        traits.append("instrumental")
    if re.search(r"\b(?:hintergrundmusik|musik\s+im\s+hintergrund)\b", normalized):
        traits.append("background")

    if not traits:
        return None

    year_min, year_max, without_year = extract_metadata_year_range(normalized)
    genres = extract_metadata_genres(without_year)
    result: dict[str, Any] = {
        "action": "play_metadata_playlist",
        "metadata_traits": list(dict.fromkeys(traits)),
        "shuffle": True,
    }
    if genres:
        result["genres"] = genres
    if year_min is not None:
        result["year_min"] = year_min
    if year_max is not None:
        result["year_max"] = year_max
    return result


METADATA_MOOD_PATTERNS = (
    r"\b(?:entspannt\w*|entspannend\w*|entspannen|ruhig\w*|chillig\w*|relaxed)\b",
    r"\b(?:anregend\w*|anregung|energiegeladen\w*|energetisch\w*|aufregend\w*|wild\w*)\b",
    r"\b(?:froehlich\w*|heiter\w*|lustig\w*|gut(?:e|er)?\s+laune)\b",
    r"\b(?:melancholisch\w*|melancholie|traurig\w*|schwermuetig\w*)\b",
    r"\b(?:tanzbar\w*|dancebar\w*|zum\s+tanzen|tanzmusik)\b",
    r"\b(?:instrumental\w*|ohne\s+gesang)\b",
    r"\b(?:hintergrundmusik|musik\s+im\s+hintergrund)\b",
)

DECADE_WORDS = {
    "fuenfzig": 1950,
    "sechzig": 1960,
    "siebzig": 1970,
    "achtzig": 1980,
    "neunzig": 1990,
    "nuller": 2000,
    "zweitausender": 2000,
    "zehner": 2010,
    "zwanziger": 2020,
}


def extract_metadata_year_range(value: str) -> tuple[int | None, int | None, str]:
    cleaned = value
    between = re.search(r"\b(?:von\s+)?((?:19|20)\d{2})\s+bis\s+((?:19|20)\d{2})\b", cleaned)
    if between:
        start, end = int(between.group(1)), int(between.group(2))
        cleaned = (cleaned[: between.start()] + " " + cleaned[between.end() :]).strip()
        return min(start, end), max(start, end), cleaned

    numeric_decade = re.search(r"\b(?:aus\s+(?:den\s+)?)?((?:19|20)?\d{2})er(?:n)?\b", cleaned)
    if numeric_decade:
        raw = int(numeric_decade.group(1))
        if raw < 100:
            start = 2000 + raw if raw <= 20 else 1900 + raw
        else:
            start = raw
        start -= start % 10
        cleaned = (cleaned[: numeric_decade.start()] + " " + cleaned[numeric_decade.end() :]).strip()
        return start, start + 9, cleaned

    word_decade = re.search(
        rf"\b(?:aus\s+(?:den\s+)?)?({'|'.join(DECADE_WORDS)})(?:er|ern)?\b",
        cleaned,
    )
    if word_decade:
        start = DECADE_WORDS[word_decade.group(1)]
        cleaned = (cleaned[: word_decade.start()] + " " + cleaned[word_decade.end() :]).strip()
        return start, start + 9, cleaned

    single_year = re.search(r"\b(?:aus\s+dem\s+jahr|aus|von)\s+((?:19|20)\d{2})\b", cleaned)
    if single_year:
        year = int(single_year.group(1))
        cleaned = (cleaned[: single_year.start()] + " " + cleaned[single_year.end() :]).strip()
        return year, year, cleaned
    return None, None, cleaned


def extract_metadata_genres(value: str) -> list[str]:
    residue = value
    for pattern in METADATA_MOOD_PATTERNS:
        residue = re.sub(pattern, " ", residue)
    residue = re.sub(r"\b(?:musik|stuecke|stuecken|titel|tracks?|songs?)\b", " ", residue)
    residue = re.sub(r"\b(?:im|in|aus\s+dem|aus\s+der)\s+(?:genre|bereich|stilrichtung)\b", " ", residue)
    residue = re.sub(r"\b(?:genre|bereich|stilrichtung)\b", " ", residue)
    residue = re.sub(
        r"\b(?:bitte|mir|mal|doch|gerne|jetzt|etwas|eher|moeglichst|moegliche|mach|mache|an|aber|nur|dem|der|den|die|das|ein|eine)\b",
        " ",
        residue,
    )
    residue = re.sub(r"\b(?:aus|von|zum)\b", " ", residue)
    residue = re.sub(r"\s+", " ", residue).strip(" ,.-")
    if not residue:
        return []
    genres = [normalize_genre_alias(item) for item in re.split(r"\s*(?:,|\boder\b|\bund\b)\s*", residue)]
    return list(dict.fromkeys(item for item in genres if item))


def targets_in_text(cleaned: str, known_rooms: list[str]) -> list[str]:
    matches = []
    for known_room in sorted(known_rooms, key=len, reverse=True):
        pattern = room_name_pattern(known_room)
        for match in re.finditer(pattern, cleaned):
            matches.append((match.start(), match.end(), known_room))
    matches.sort(key=lambda item: (item[0], -(item[1] - item[0])))
    targets = []
    occupied_until = -1
    for start, end, target in matches:
        if start < occupied_until:
            continue
        targets.append(target)
        occupied_until = end
    return targets


def room_name_pattern(room: str) -> str:
    tokens = re.findall(r"[a-z0-9äöü]+", normalize_text(room))
    if not tokens:
        return re.escape(normalize_text(room))
    return r"\b" + r"[\s_\-']*".join(room_token_pattern(token) for token in tokens) + r"\b"


def room_token_pattern(token: str) -> str:
    if token in {"weiss", "weisse", "weisser", "weisses", "weissen"}:
        return r"weiss(?:e|er|es|en)?"
    return re.escape(token)


def cleanup_query(value: str | None) -> str:
    value = value or ""
    value = re.sub(r"\bbitte\b", "", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip(" .,!?:;")


def clean_value(value: str | None) -> str | None:
    cleaned = cleanup_query(value)
    return cleaned or None


def clamp_percent(value: str) -> int:
    return max(0, min(100, int(value)))
