from __future__ import annotations

import re

from app.lms_client import LmsClient
from app.matcher import Match, best_matches, score_text


class Library:
    def __init__(self, lms: LmsClient, config: dict):
        self.lms = lms
        matching = config.get("matching", {})
        self.min_score = float(matching.get("min_score", 0.55))
        self.artist_limit = int(matching.get("artist_limit", 100))
        self.album_limit = int(matching.get("album_limit", 100))

    def find_artist(self, query: str) -> Match | None:
        matches = self.find_artists(query, limit=5)
        if not matches:
            return None
        return matches[0]

    def find_artists(self, query: str, limit: int = 10) -> list[Match]:
        artists_by_id: dict[str, dict] = {}
        for search_term in self._artist_search_terms(query):
            for artist in self.lms.artists(search=search_term, limit=self.artist_limit):
                artist_id = str(artist.get("id", artist.get("artist", "")))
                artists_by_id[artist_id] = artist
        matches = [
            Match(item=artist, score=artist_name_score(query, str(artist.get("artist", ""))))
            for artist in artists_by_id.values()
        ]
        matches.sort(key=lambda match: match.score, reverse=True)
        if not matches or matches[0].score < self.min_score:
            return []
        threshold = max(self.min_score, matches[0].score - 0.05)
        return [match for match in matches if match.score >= threshold][:limit]

    def find_genre(self, query: str) -> Match | None:
        genres = self.lms.genres(search=query, limit=50)
        matches = best_matches(query, genres, "genre", limit=5)
        if not matches or matches[0].score < self.min_score:
            return None
        return matches[0]

    def find_album_for_artist(self, artist_id: str, preferred_album: str | None = None) -> dict | None:
        albums = self.albums_for_artist(artist_id)
        if not albums:
            return None

        if preferred_album:
            albums.sort(
                key=lambda album: score_text(preferred_album, str(album.get("album", ""))),
                reverse=True,
            )

        return albums[0]

    def albums_for_artist(self, artist_id: str) -> list[dict]:
        return self._filter_sampler_albums(self.lms.albums_for_artist(artist_id, limit=self.album_limit))

    def albums_matching_artist_name(self, query: str, include_samplers: bool = False) -> list[dict]:
        albums = []
        for search_term in self._artist_search_terms(query):
            albums.extend(self.lms.albums(search=search_term, limit=self.album_limit))
        albums = self._unique_albums(albums)
        if not include_samplers:
            albums = self._filter_sampler_albums(albums)
        return [
            album
            for album in albums
            if self._album_artist_score(query, album) >= self.min_score
        ]

    def titles_matching_artist_name(self, query: str, limit: int = 20) -> list[dict]:
        titles = []
        for search_term in self._artist_search_terms(query):
            titles.extend(self.lms.titles(search=search_term, limit=limit))
        titles = self._unique_titles(titles)
        scored = []
        for title in titles:
            artist_score = max(
                artist_name_score(query, str(title.get("artist", ""))),
                artist_name_score(query, str(title.get("albumartist", ""))),
                artist_name_score(query, str(title.get("contributor", ""))),
            )
            if artist_score >= self.min_score:
                scored.append((artist_score, title))
        scored.sort(key=lambda item: item[0], reverse=True)
        if not scored:
            return []
        threshold = max(self.min_score, scored[0][0] - 0.05)
        return [title for score, title in scored if score >= threshold][:limit]

    def titles_for_matching_artists(self, query: str, limit_per_artist: int = 50) -> list[dict]:
        titles: list[dict] = []
        for match in self.find_artists(query, limit=10):
            artist_id = match.item.get("id")
            if artist_id is None:
                continue
            for title in self.lms.titles_for_artist(str(artist_id), limit=limit_per_artist):
                title.setdefault("matched_artist", match.item.get("artist"))
                titles.append(title)
        return self._unique_titles(titles)

    def artist_inventory(self, query: str) -> dict:
        artist_matches = self.find_artists(query, limit=10)
        artist_match = artist_matches[0] if artist_matches else None
        artist_name = str(artist_match.item.get("artist")) if artist_match else query
        direct_artist_matches = self._direct_album_artist_matches(query, artist_matches)
        direct_albums = []
        for match in direct_artist_matches:
            artist_id = match.item.get("id")
            if artist_id is not None:
                direct_albums.extend(self.albums_for_artist(str(artist_id)))
        exact_direct_albums = [
            album for album in direct_albums if self._album_has_exact_artist(album, query)
        ]
        if exact_direct_albums:
            direct_albums = exact_direct_albums
        search_albums = [] if direct_artist_matches else self.albums_matching_artist_name(query, include_samplers=False)
        artist_titles = self.titles_for_artist_matches(direct_artist_matches or artist_matches)
        direct_title_matches = [] if artist_matches else self.titles_matching_artist_name(query)
        titles = self._unique_titles([*direct_title_matches, *artist_titles])
        albums = self._unique_albums([*direct_albums, *search_albums])
        album_artist_albums = self._filter_sampler_albums(albums)
        sampler_albums = self._sampler_albums_from_titles(titles, album_artist_albums)
        sampler_titles = [title for title in titles if self._looks_like_sampler_title(title)]
        return {
            "artist": artist_name,
            "artist_match": artist_match.item if artist_match else None,
            "artist_matches": [match.item for match in artist_matches],
            "albums": album_artist_albums,
            "sampler_albums": sampler_albums,
            "sampler_titles": sampler_titles,
            "titles": titles,
        }

    def _direct_album_artist_matches(self, query: str, artist_matches: list[Match]) -> list[Match]:
        exact_matches = [
            match
            for match in artist_matches
            if normalized_containment_text(str(match.item.get("artist", "")))
            == normalized_containment_text(query)
        ]
        if exact_matches:
            return exact_matches
        return artist_matches[:1]

    def _album_has_exact_artist(self, album: dict, query: str) -> bool:
        query_key = normalized_containment_text(query)
        if not query_key:
            return False
        for key in ("artist", "albumartist", "contributor"):
            value = str(album.get(key, "")).strip()
            if value and normalized_containment_text(value) == query_key:
                return True
        return False

    def titles_for_artist_matches(self, artist_matches: list[Match], limit_per_artist: int = 50) -> list[dict]:
        titles: list[dict] = []
        for match in artist_matches:
            artist_id = match.item.get("id")
            if artist_id is None:
                continue
            for title in self.lms.titles_for_artist(str(artist_id), limit=limit_per_artist):
                title.setdefault("matched_artist", match.item.get("artist"))
                titles.append(title)
        return self._unique_titles(titles)

    def find_albums_by_title(self, query: str, limit: int = 8) -> list[dict]:
        albums: list[dict] = []
        for search_term in self._album_title_search_terms(query):
            albums.extend(self.lms.albums(search=search_term, limit=self.album_limit))
        albums = self._filter_sampler_albums(self._unique_albums(albums))
        scored = []
        for album in albums:
            album_title = str(album.get("album", ""))
            title_score = max(
                score_text(query, album_title),
                token_overlap_score(query, album_title),
                contained_title_score(query, album_title),
            )
            scored.append((title_score, album))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [album for score, album in scored[:limit] if score >= self.min_score]

    def find_titles_by_title(self, query: str, artist_query: str | None = None, limit: int = 8) -> list[dict]:
        titles = self.lms.titles(search=query, limit=100)
        scored = []
        exact_title_scored = []
        title_only_scored = []
        query_key = normalize_search_key(query)
        for title in titles:
            title_score = max(
                score_text(query, str(title.get("title", ""))),
                token_overlap_score(query, str(title.get("title", ""))),
            )
            artist_score = 1.0
            if artist_query:
                artist_score = max(
                    score_text(artist_query, str(title.get("artist", ""))),
                    score_text(artist_query, str(title.get("albumartist", ""))),
                    score_text(artist_query, str(title.get("contributor", ""))),
                    token_overlap_score(artist_query, str(title.get("artist", ""))),
                    token_overlap_score(artist_query, str(title.get("albumartist", ""))),
                    token_overlap_score(artist_query, str(title.get("contributor", ""))),
                )
            combined = 0.75 * title_score + 0.25 * artist_score
            if title_score >= self.min_score and artist_score >= self.min_score:
                scored.append((combined, title))
            elif artist_query and title_score >= max(0.82, self.min_score):
                if normalize_search_key(str(title.get("title", ""))) == query_key:
                    exact_title_scored.append((title_score, title))
                else:
                    title_only_scored.append((title_score, title))
        scored.sort(key=lambda item: item[0], reverse=True)
        if scored:
            return [title for _, title in scored[:limit]]
        exact_title_scored.sort(key=lambda item: item[0], reverse=True)
        if exact_title_scored:
            return [title for _, title in exact_title_scored[:limit]]
        title_only_scored.sort(key=lambda item: item[0], reverse=True)
        return [title for _, title in title_only_scored[:limit]]

    def _album_artist_score(self, query: str, album: dict) -> float:
        return max(
            artist_name_score(query, str(album.get("artist", ""))),
            artist_name_score(query, str(album.get("albumartist", ""))),
            artist_name_score(query, str(album.get("contributor", ""))),
        )

    def _unique_albums(self, albums: list[dict]) -> list[dict]:
        unique = []
        seen = set()
        for album in albums:
            key = (str(album.get("id", "")), str(album.get("album", "")), str(album.get("artist", "")))
            if key in seen:
                continue
            unique.append(album)
            seen.add(key)
        return unique

    def _unique_titles(self, titles: list[dict]) -> list[dict]:
        unique = []
        seen = set()
        for title in titles:
            key = (
                str(title.get("id", "")),
                str(title.get("title", "")),
                str(title.get("album", "")),
                str(title.get("artist", "")),
            )
            if key in seen:
                continue
            unique.append(title)
            seen.add(key)
        return unique

    def _looks_like_sampler_title(self, title: dict) -> bool:
        album = str(title.get("album", "")).casefold()
        artist = str(title.get("artist", "")).casefold()
        albumartist = str(title.get("albumartist", "")).casefold()
        return (
            "various artists" in artist
            or "various artists" in albumartist
            or "various" == artist
            or "various" == albumartist
            or artist in {"diverse", "diverse interpreten", "verschiedene", "verschiedene interpreten"}
            or albumartist in {"diverse", "diverse interpreten", "verschiedene", "verschiedene interpreten"}
            or "sampler" in album
            or "compilation" in album
            or self._is_truthy_compilation(title)
        )

    def _sampler_albums_from_titles(self, titles: list[dict], known_albums: list[dict]) -> list[dict]:
        known = {str(album.get("album", "")).casefold() for album in known_albums}
        sampler_albums: list[dict] = []
        seen = set()
        for title in titles:
            album_name = str(title.get("album", "")).strip()
            if not album_name or album_name.casefold() in known:
                continue
            if not self._looks_like_sampler_title(title):
                continue
            key = album_name.casefold()
            if key in seen:
                continue
            sampler_albums.append({
                "album": album_name,
                "artist": str(title.get("albumartist", "") or title.get("artist", "")).strip(),
            })
            seen.add(key)
        return sampler_albums

    def _artist_search_terms(self, query: str) -> list[str]:
        terms = []
        seen = set()
        normalized = re.sub(r"\s+", " ", str(query or "")).strip()
        candidates = [normalized]
        tokens = [
            token
            for token in re.sub(r"[^a-z0-9äöüß]+", " ", normalized.casefold()).split()
            if len(token) >= 3
        ]
        candidates.extend(tokens)
        candidates.extend(token[:5] for token in tokens if len(token) >= 5)
        candidates.extend(token[:4] for token in tokens if len(token) >= 4)
        for token in tokens:
            candidates.extend(artist_token_variants(token))
        compact = re.sub(r"[^a-z0-9äöüß]+", "", normalized.casefold())
        if len(compact) >= 7 and " " not in normalized:
            candidates.extend([compact[:5], compact[:6]])
            candidates.extend(compact_artist_variants(compact))
        for term in candidates:
            if len(term) < 3:
                continue
            key = term.casefold()
            if key in seen:
                continue
            terms.append(term)
            seen.add(key)
        return terms or [query]

    def _album_title_search_terms(self, query: str) -> list[str]:
        terms = []
        seen = set()
        for term in [query, *sorted(significant_tokens(query), key=len, reverse=True)]:
            normalized = re.sub(r"\s+", " ", str(term or "")).strip()
            if len(normalized) < 3:
                continue
            key = normalized.casefold()
            if key in seen:
                continue
            terms.append(normalized)
            seen.add(key)
        return terms or [query]

    def _filter_sampler_albums(self, albums: list[dict]) -> list[dict]:
        filtered = []
        for album in albums:
            title = str(album.get("album", ""))
            artist = str(album.get("artist", "") or album.get("albumartist", ""))
            albumartist = str(album.get("albumartist", ""))
            contributor = str(album.get("contributor", ""))
            lower_title = title.casefold()
            lower_artist = artist.casefold()
            lower_albumartist = albumartist.casefold()
            lower_contributor = contributor.casefold()
            artist_values = {lower_artist, lower_albumartist, lower_contributor}
            is_sampler = self._is_truthy_compilation(album) or any(
                marker in lower_title
                for marker in (
                    "sampler",
                    "compilation",
                    "various artists",
                    "various artist",
                    "various",
                    "bravo hits",
                    "the dome",
                    "kuschelrock",
                    "fetenhits",
                    "hit giganten",
                )
            ) or any(
                value in {
                    "various",
                    "various artists",
                    "various artist",
                    "diverse",
                    "diverse interpreten",
                    "verschiedene",
                    "verschiedene interpreten",
                    "va",
                    "v a",
                }
                for value in artist_values
            )
            if not is_sampler:
                filtered.append(album)
        return filtered

    @staticmethod
    def _is_truthy_compilation(item: dict) -> bool:
        for key in ("compilation", "is_compilation", "compilation_id"):
            value = item.get(key)
            if value in {1, "1", True, "true", "True", "yes", "Ja", "ja"}:
                return True
        return False


def token_overlap_score(query: str, candidate: str) -> float:
    query_tokens = significant_tokens(query)
    candidate_tokens = significant_tokens(candidate)
    if not query_tokens or not candidate_tokens:
        return 0.0
    return len(query_tokens & candidate_tokens) / len(query_tokens)


def contained_title_score(query: str, candidate: str) -> float:
    query_key = normalized_containment_text(query)
    candidate_key = normalized_containment_text(candidate)
    if not query_key or not candidate_key:
        return 0.0
    if query_key == candidate_key:
        return 1.0
    if query_key in candidate_key:
        return 0.95
    query_tokens = significant_tokens(query)
    candidate_tokens = significant_tokens(candidate)
    if query_tokens and query_tokens <= candidate_tokens:
        return 0.9
    return 0.0


def artist_name_score(query: str, candidate: str) -> float:
    candidates = artist_name_candidates(candidate)
    if not candidates:
        return 0.0
    return max(score_text(query, value) for value in candidates)


def artist_name_candidates(value: str) -> list[str]:
    raw = str(value or "").strip()
    if not raw:
        return []
    separator_pattern = r"\s*(?:/|,|;|&|\+|\band\b|\bund\b|\bfeat\.?\b|\bfeaturing\b|\(|\))\s*"
    parts = [
        part.strip()
        for part in re.split(separator_pattern, raw, flags=re.IGNORECASE)
        if len(normalized_containment_text(part)) > 2
    ]
    candidates = parts if len(parts) > 1 else [raw]
    return candidates


def artist_token_variants(token: str) -> list[str]:
    variants = []
    if re.match(r"^don+", token):
        variants.append("donna")
    if re.match(r"^(?:sam|som|sum)", token):
        variants.append("summer")
    return variants


def compact_artist_variants(value: str) -> list[str]:
    variants = []
    if value.startswith(("donna", "donner", "doner")):
        variants.append("donna")
    if re.search(r"(?:sam|som|sum)", value):
        variants.append("summer")
    return variants


def normalized_containment_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9äöüß]+", " ", value.casefold())).strip()


def normalize_search_key(value: str) -> str:
    return " ".join(sorted(significant_tokens(value)))


def significant_tokens(value: str) -> set[str]:
    filler = {
        "der",
        "die",
        "das",
        "den",
        "ein",
        "eine",
        "einen",
        "the",
        "a",
        "an",
        "and",
        "und",
        "feat",
        "featuring",
    }
    tokens = re.sub(r"[^a-z0-9äöüß]+", " ", value.casefold()).split()
    return {token for token in tokens if len(token) > 1 and token not in filler}
