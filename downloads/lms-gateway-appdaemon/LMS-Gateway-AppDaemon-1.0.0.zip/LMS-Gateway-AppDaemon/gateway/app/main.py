from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import threading
import time
from datetime import datetime, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from app.config_loader import load_yaml_config, save_yaml_config
from app.context import DeviceContextStore
from app.dialogs import DialogState, album_dialog_state, explicit_selection_index, folder_dialog_state, make_session, radio_dialog_state, select_option, state_from_session, target_dialog_state
from app.genre_metadata_client import GenreMetadataClient
from app.intent import parse_command
from app.library import Library
from app.logging_setup import LOGGER_NAME, setup_logging
from app.lms_client import LmsClient, LmsError, safe_int
from app.matcher import score_text
from app.players import PlayerRegistry
from app.sessions import SessionState, SessionStore


BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = Path(__file__).with_name("config.yaml")
CONFIG_PATH = Path(os.environ.get("LMS_GATEWAY_CONFIG", DEFAULT_CONFIG_PATH)).resolve()
STATE_PATH = Path(os.environ.get("LMS_GATEWAY_STATE", BASE_DIR / "app" / "runtime_state.json")).resolve()
TOOL_ID = "lms_gateway"
TOOL_NAME = "LMS Gateway"
TOOL_VERSION = "0.3.0"
API_VERSION = "v1"
CONFIG_SCHEMA_VERSION = "1.0"

setup_logging(BASE_DIR)
logger = logging.getLogger(f"{LOGGER_NAME}.main")
logging.getLogger("uvicorn.access").addFilter(lambda record: "/admin/api/logs" not in record.getMessage())

RECENT_COMMAND_WINDOW_SECONDS = 2.0
recent_command_lock = threading.Lock()
recent_commands: dict[tuple[str, str, str, str, str], float] = {}
last_radio_lock = threading.Lock()
last_radio_by_target: dict[str, dict[str, Any]] = {}
DEFAULT_METADATA_PROFILES: dict[str, dict[str, float]] = {
    "relaxed": {"relaxed_min": 0.7},
    "stimulating": {"relaxed_max": 0.35},
    "happy": {"happy_min": 0.7},
    "melancholic": {"happy_max": 0.35},
    "danceable": {"danceability_min": 0.7},
    "instrumental": {"instrumental_min": 0.75},
    "background": {"relaxed_min": 0.7, "loudness_range_lu_max": 10.0},
}


def load_last_radio_state() -> dict[str, dict[str, Any]]:
    if not STATE_PATH.exists():
        return {}
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Runtime state could not be loaded: path=%s error=%s", STATE_PATH, exc)
        return {}
    radio_state = data.get("last_radio_by_target") if isinstance(data, dict) else None
    if not isinstance(radio_state, dict):
        return {}
    return {str(key): dict(value) for key, value in radio_state.items() if isinstance(value, dict)}


def save_last_radio_state() -> None:
    with last_radio_lock:
        snapshot = dict(last_radio_by_target)
    try:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(
            json.dumps({"last_radio_by_target": snapshot}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError as exc:
        logger.warning("Runtime state could not be saved: path=%s error=%s", STATE_PATH, exc)


last_radio_by_target.update(load_last_radio_state())


class CommandRequest(BaseModel):
    text: str = Field(min_length=1)
    room: str | None = None
    device: str | None = None
    user: str | None = None
    source: str | None = None
    dry_run: bool = False


class CommandResponse(BaseModel):
    status: Literal["ok", "error", "clarify"]
    message: str
    action: str | None = None
    artist: str | None = None
    album: str | None = None
    room: str | None = None
    volume: int | None = None
    options: list[str] | None = None
    shuffle: bool | None = None
    followup: bool | None = None
    followup_seconds: int | None = None
    selection_source: str | None = None
    fallback_reason: str | None = None
    track_count: int | None = None
    genre: str | None = None


class GatewayConfigUpdate(BaseModel):
    config: dict[str, Any]


class ApiActionPayload(BaseModel):
    payload: dict[str, Any] | None = None


def load_config() -> dict:
    return load_yaml_config(CONFIG_PATH)


def session_ttl_seconds(config_data: dict) -> int:
    dialog = config_data.get("dialog") or {}
    try:
        return max(30, int(dialog.get("session_ttl_seconds", 180)))
    except (TypeError, ValueError):
        return 180


def control_followup_seconds(config_data: dict) -> int:
    dialog = config_data.get("dialog") or {}
    try:
        return max(0, int(dialog.get("control_followup_seconds", 5)))
    except (TypeError, ValueError):
        return 5


def apply_config(new_config: dict[str, Any], save: bool = False) -> None:
    global config, lms, library, players, sessions, device_contexts, genre_metadata
    if save:
        save_yaml_config(CONFIG_PATH, new_config)
    config = load_config() if save else new_config
    lms = LmsClient(config)
    library = Library(lms, config)
    players = PlayerRegistry(config)
    sessions = SessionStore(session_ttl_seconds(config))
    device_contexts = DeviceContextStore(config)
    genre_metadata = GenreMetadataClient(config)


config = load_config()
lms = LmsClient(config)
library = Library(lms, config)
players = PlayerRegistry(config)
sessions = SessionStore(session_ttl_seconds(config))
device_contexts = DeviceContextStore(config)
genre_metadata = GenreMetadataClient(config)


def select_album_dialog_option(text: str, state: DialogState) -> tuple[dict | None, int | None]:
    session = make_session(state)
    return select_album_from_session_command(text, session)


def select_radio_dialog_option(text: str, state: DialogState) -> tuple[dict | None, int | None]:
    selected = select_named_option(text, state.options, "name")
    return selected, index_of_option(state.options, selected)


def select_folder_dialog_option(text: str, state: DialogState) -> tuple[dict | None, int | None]:
    selected = select_named_option(text, state.options, "name")
    return selected, index_of_option(state.options, selected)


DIALOG_SELECTORS = {
    "album": select_album_dialog_option,
    "radio": select_radio_dialog_option,
    "folder": select_folder_dialog_option,
}


def configured_api_token() -> str:
    security = config.get("security") or {}
    return str(security.get("token") or os.environ.get("LMS_GATEWAY_API_TOKEN") or "").strip()


def require_api_token(request: Request) -> None:
    token = configured_api_token()
    if not token:
        return
    auth = request.headers.get("authorization", "")
    bearer = auth.removeprefix("Bearer ").strip() if auth.startswith("Bearer ") else ""
    header_token = request.headers.get("x-api-token", "").strip()
    if bearer == token or header_token == token:
        return
    raise HTTPException(status_code=401, detail="API token required")


def public_config_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "sections": {
            "lms": ["host", "http_port", "cli_port", "timeout_seconds"],
            "gateway": ["host", "port", "public_url"],
            "dialog": ["session_ttl_seconds"],
            "players": "mapping of room names to LMS player settings",
            "devices": "mapping of source devices to default rooms",
            "matching": ["min_score", "artist_limit", "album_limit"],
        },
    }


def status_payload() -> dict[str, Any]:
    try:
        lms_players = lms.players()
        players.refresh_from_lms(lms_players)
        lms_status = "ok"
        lms_error = None
    except LmsError as exc:
        lms_players = []
        lms_status = "error"
        lms_error = str(exc)
    known_rooms = players.known_rooms()
    return {
        "status": "ok" if lms_status == "ok" else "error",
        "tool_id": TOOL_ID,
        "name": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "api_version": API_VERSION,
        "config_schema_version": CONFIG_SCHEMA_VERSION,
        "config_path": str(CONFIG_PATH),
        "gateway": config.get("gateway") or {},
        "lms": {
            "status": lms_status,
            "host": (config.get("lms") or {}).get("host"),
            "http_port": (config.get("lms") or {}).get("http_port"),
            "cli_port": (config.get("lms") or {}).get("cli_port"),
            "error": lms_error,
        },
        "rooms": known_rooms,
        "player_count": len(lms_players),
        "players": [
            {
                "id": player.get("playerid") or player.get("id"),
                "name": player.get("name"),
                "connected": player.get("connected"),
            }
            for player in lms_players
        ],
    }


def read_recent_log_lines(lines: int = 120) -> list[str]:
    log_file = Path(os.environ.get("LMS_GATEWAY_LOG_DIR", BASE_DIR / "logs")) / "gateway.log"
    if not log_file.exists():
        return []
    try:
        content = log_file.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    token = configured_api_token()
    result = content[-max(1, min(lines, 500)) :]
    if token:
        result = [line.replace(token, "***") for line in result]
    return result

app = FastAPI(title="LMS Gateway for Home Assistant")


@app.get("/admin", response_class=HTMLResponse)
def admin_page() -> str:
    return ADMIN_HTML


@app.get("/admin/api/status")
def admin_status() -> dict:
    lms_status: dict[str, Any]
    try:
        lms_player_list = lms.players()
        players.refresh_from_lms(lms_player_list)
        lms_status = {"status": "ok", "players": lms_player_list}
    except LmsError as exc:
        lms_status = {"status": "error", "message": str(exc), "players": []}

    return {
        "status": "ok",
        "config_path": str(CONFIG_PATH),
        "known_targets": players.known_rooms(),
        "lms": lms_status,
    }


@app.get("/admin/api/config")
def admin_get_config() -> dict:
    return {"status": "ok", "config": config, "config_path": str(CONFIG_PATH)}


@app.post("/admin/api/config")
def admin_save_config(update: GatewayConfigUpdate) -> dict:
    try:
        apply_config(update.config, save=True)
    except Exception as exc:
        return {"status": "error", "message": f"Konfiguration konnte nicht gespeichert werden: {exc}"}
    return {"status": "ok", "message": "Konfiguration gespeichert und neu geladen.", "config": config}


@app.get("/admin/api/logs")
def admin_logs(lines: int = 120) -> dict:
    log_file = Path(os.environ.get("LMS_GATEWAY_LOG_DIR", BASE_DIR / "logs")) / "gateway.log"
    safe_lines = max(20, min(500, lines))
    try:
        content = tail_text_file(log_file, safe_lines)
    except OSError as exc:
        return {"status": "error", "message": str(exc), "logs": ""}
    return {"status": "ok", "path": str(log_file), "logs": content}


@app.post("/admin/api/restart")
def admin_restart() -> dict:
    logger.warning("Restart requested from admin page.")
    threading.Timer(1.0, stop_process_for_restart).start()
    return {
        "status": "ok",
        "message": "Neustart wurde ausgeloest. In der Testphase muss der Dienst manuell wieder gestartet werden.",
    }


def stop_process_for_restart() -> None:
    os._exit(0)


@app.post("/admin/api/open-console")
def admin_open_console() -> dict:
    try:
        open_start_console()
    except Exception as exc:
        return {"status": "error", "message": f"PowerShell konnte nicht geoeffnet werden: {exc}"}
    return {"status": "ok", "message": "PowerShell-Fenster wurde geoeffnet."}


def open_start_console() -> None:
    start_command = r'.\.venv\Scripts\python.exe ".\LMS Gateway.py"'
    project_dir = ps_single_quote(str(BASE_DIR))
    command = (
        f"Set-Location -LiteralPath {project_dir}; "
        "Write-Host 'LMS Gateway Projektordner:' -ForegroundColor Cyan; "
        "Get-Location; "
        "Write-Host ''; "
        "Write-Host 'Startbefehl:' -ForegroundColor Cyan; "
        f"Write-Host '{start_command}' -ForegroundColor Yellow; "
        "Write-Host ''; "
        "Write-Host 'Hinweis: Wenn der Dienst bereits laeuft, zuerst das laufende Fenster mit STRG+C beenden.'"
    )
    subprocess.Popen(
        ["powershell.exe", "-NoExit", "-ExecutionPolicy", "Bypass", "-Command", command],
        cwd=str(BASE_DIR),
        creationflags=subprocess.CREATE_NEW_CONSOLE,
    )


def ps_single_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def tail_text_file(path: Path, lines: int) -> str:
    if not path.exists():
        return ""
    with path.open("r", encoding="utf-8", errors="replace") as file:
        return "".join(file.readlines()[-lines:])


ADMIN_HTML = """<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LMS Gateway Admin</title>
  <style>
    :root { color-scheme: light dark; font-family: Segoe UI, Arial, sans-serif; }
    body { margin: 0; background: #f4f6f8; color: #18202a; }
    main { max-width: 1120px; margin: 0 auto; padding: 24px; }
    h1 { font-size: 28px; margin: 0 0 18px; }
    h2 { font-size: 18px; margin: 0 0 12px; }
    section { background: #fff; border: 1px solid #d9e0e7; border-radius: 8px; padding: 18px; margin-bottom: 16px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px; }
    .editor-grid { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 16px; align-items: stretch; }
    .editor-grid section { margin-bottom: 16px; }
    label { display: grid; gap: 6px; font-size: 13px; color: #445160; }
    input, textarea { border: 1px solid #b8c2cc; border-radius: 6px; padding: 9px 10px; font: inherit; background: #fff; color: #18202a; }
    textarea { width: 100%; box-sizing: border-box; min-height: 320px; font-family: Consolas, monospace; resize: vertical; }
    button { border: 0; border-radius: 6px; background: #1f6feb; color: white; padding: 10px 14px; font: inherit; cursor: pointer; }
    button.secondary { background: #4f5b66; }
    button.danger { background: #b42318; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    .status { padding: 10px 12px; border-radius: 6px; background: #eef4ff; border: 1px solid #c8dcff; }
    .error { background: #fff0f0; border-color: #ffc8c8; }
    pre { white-space: pre-wrap; word-break: break-word; background: #f7f9fb; border: 1px solid #d9e0e7; border-radius: 6px; padding: 12px; max-height: 320px; overflow: auto; }
    .log-window { background: #0f1720; color: #d7e2ed; min-height: 360px; max-height: 520px; font-family: Consolas, monospace; font-size: 13px; }
    @media (max-width: 900px) {
      .editor-grid { grid-template-columns: 1fr; }
    }
    @media (prefers-color-scheme: dark) {
      body { background: #101418; color: #e8edf2; }
      section, input, textarea { background: #171d23; color: #e8edf2; border-color: #34414d; }
      label { color: #b9c4cf; }
      pre { background: #11171d; border-color: #34414d; }
      .status { background: #14243d; border-color: #275187; }
      .error { background: #3a1717; border-color: #733333; }
    }
  </style>
</head>
<body>
<main>
  <h1>LMS Gateway Admin</h1>
  <section>
    <h2>Status</h2>
    <div id="status" class="status">Lade Status...</div>
  </section>
  <section>
    <h2>Server und LMS</h2>
    <div class="grid">
      <label>LMS IP oder Host<input id="lmsHost"></label>
      <label>LMS Web-Port<input id="lmsHttpPort" type="number"></label>
      <label>LMS CLI-Port<input id="lmsCliPort" type="number"></label>
      <label>Timeout Sekunden<input id="lmsTimeout" type="number"></label>
      <label>Dialog-Zeitfenster Sekunden<input id="dialogSessionTtl" type="number" min="30"></label>
      <label>Steuerbefehl-Folgefenster Sekunden<input id="controlFollowupSeconds" type="number" min="0"></label>
      <label>Gateway Host<input id="gatewayHost"></label>
      <label>Gateway Port<input id="gatewayPort" type="number"></label>
      <label>Adresse des Pipedienstes<input id="gatewayPublicUrl"></label>
    </div>
  </section>
  <div class="editor-grid">
  <section>
    <h2>Feste Player und Aliase</h2>
    <textarea id="playersJson" spellcheck="false"></textarea>
  </section>
  <section>
    <h2>Eingabegeräte mit optionalem Standardziel</h2>
    <textarea id="devicesJson" spellcheck="false"></textarea>
  </section>
  </div>
  <section>
    <h2>Aktuelle LMS-Player</h2>
    <pre id="players">Noch keine Daten.</pre>
  </section>
  <section>
    <div class="actions">
      <h2 style="margin-right:auto">Live-Log</h2>
      <button class="secondary" onclick="loadLogs()">Aktualisieren</button>
    </div>
    <pre id="logs" class="log-window">Noch keine Logdaten.</pre>
  </section>
  <section>
    <div class="actions">
      <button onclick="saveConfig()">Speichern und neu laden</button>
      <button class="secondary" onclick="loadAll()">Neu einlesen</button>
      <button class="secondary" onclick="openConsole()">PowerShell öffnen</button>
      <button class="danger" onclick="restartService()">Python-Dienst neu starten</button>
    </div>
    <p id="message"></p>
  </section>
</main>
<script>
let currentConfig = {};
let logTimer = null;

async function loadAll() {
  await loadConfig();
  await loadStatus();
  await loadLogs();
}

async function loadConfig() {
  const response = await fetch('/admin/api/config');
  const data = await response.json();
  currentConfig = data.config || {};
  const lms = currentConfig.lms || {};
  const gateway = currentConfig.gateway || {};
  const dialog = currentConfig.dialog || {};
  document.getElementById('lmsHost').value = lms.host || '';
  document.getElementById('lmsHttpPort').value = lms.http_port || 9000;
  document.getElementById('lmsCliPort').value = lms.cli_port || 9090;
  document.getElementById('lmsTimeout').value = lms.timeout_seconds || 8;
  document.getElementById('dialogSessionTtl').value = dialog.session_ttl_seconds || 180;
  document.getElementById('controlFollowupSeconds').value = dialog.control_followup_seconds ?? 5;
  document.getElementById('gatewayHost').value = gateway.host || '0.0.0.0';
  document.getElementById('gatewayPort').value = gateway.port || 8088;
  document.getElementById('gatewayPublicUrl').value = gateway.public_url || '';
  document.getElementById('playersJson').value = JSON.stringify(currentConfig.players || {}, null, 2);
  document.getElementById('devicesJson').value = JSON.stringify(currentConfig.devices || {}, null, 2);
}

async function loadStatus() {
  const response = await fetch('/admin/api/status');
  const data = await response.json();
  const status = document.getElementById('status');
  const lms = data.lms || {};
  status.className = lms.status === 'ok' ? 'status' : 'status error';
  status.textContent = lms.status === 'ok'
    ? `LMS erreichbar. Bekannte Ziele: ${(data.known_targets || data.known_rooms || []).join(', ') || 'keine'}`
    : `LMS nicht erreichbar: ${lms.message || 'unbekannter Fehler'}`;
  document.getElementById('players').textContent = JSON.stringify(lms.players || [], null, 2);
}

async function saveConfig() {
  const message = document.getElementById('message');
  try {
    const nextConfig = structuredClone(currentConfig);
    nextConfig.lms = {
      ...(nextConfig.lms || {}),
      host: document.getElementById('lmsHost').value.trim(),
      http_port: Number(document.getElementById('lmsHttpPort').value),
      cli_port: Number(document.getElementById('lmsCliPort').value),
      timeout_seconds: Number(document.getElementById('lmsTimeout').value),
    };
    nextConfig.gateway = {
      ...(nextConfig.gateway || {}),
      host: document.getElementById('gatewayHost').value.trim(),
      port: Number(document.getElementById('gatewayPort').value),
      public_url: document.getElementById('gatewayPublicUrl').value.trim(),
    };
    nextConfig.dialog = {
      ...(nextConfig.dialog || {}),
      session_ttl_seconds: Number(document.getElementById('dialogSessionTtl').value),
      control_followup_seconds: Number(document.getElementById('controlFollowupSeconds').value),
    };
    nextConfig.players = JSON.parse(document.getElementById('playersJson').value || '{}');
    nextConfig.devices = JSON.parse(document.getElementById('devicesJson').value || '{}');

    const response = await fetch('/admin/api/config', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({config: nextConfig}),
    });
    const data = await response.json();
    if (data.status !== 'ok') throw new Error(data.message || 'Speichern fehlgeschlagen');
    currentConfig = data.config;
    message.textContent = data.message;
    await loadStatus();
  } catch (error) {
    message.textContent = error.message;
  }
}

async function restartService() {
  const message = document.getElementById('message');
  if (!confirm('Python-Dienst wirklich neu starten? In der Testphase muss er danach manuell wieder gestartet werden.')) {
    return;
  }
  try {
    const response = await fetch('/admin/api/restart', {method: 'POST'});
    const data = await response.json();
    message.textContent = data.message || 'Neustart ausgelöst.';
  } catch (error) {
    message.textContent = error.message;
  }
}

async function openConsole() {
  const message = document.getElementById('message');
  try {
    const response = await fetch('/admin/api/open-console', {method: 'POST'});
    const data = await response.json();
    message.textContent = data.message || 'PowerShell geöffnet.';
  } catch (error) {
    message.textContent = error.message;
  }
}

async function loadLogs() {
  const response = await fetch('/admin/api/logs?lines=180');
  const data = await response.json();
  const logs = document.getElementById('logs');
  logs.textContent = data.status === 'ok' ? (data.logs || 'Keine Logdaten.') : data.message;
  logs.scrollTop = logs.scrollHeight;
}

loadAll();
logTimer = setInterval(loadLogs, 2500);
</script>
</body>
</html>"""


@app.get("/api/v1/manifest")
def api_manifest() -> dict:
    return {
        "tool_id": TOOL_ID,
        "name": TOOL_NAME,
        "version": TOOL_VERSION,
        "tool_version": TOOL_VERSION,
        "api_version": API_VERSION,
        "config_schema_version": CONFIG_SCHEMA_VERSION,
        "capabilities": [
            "config_read",
            "config_write",
            "status",
            "logs_recent",
            "reload",
            "restart",
            "lms_command",
            "refresh_players",
        ],
        "config_schema": public_config_schema(),
        "status_fields": ["status", "lms", "rooms", "player_count", "players"],
        "actions": [
            {"id": "test_connection", "title": "Verbindung testen", "critical": False},
            {"id": "refresh_players", "title": "Player aktualisieren", "critical": False},
            {"id": "reload", "title": "Konfiguration neu laden", "critical": False},
            {"id": "restart", "title": "Dienst neu starten", "critical": True},
            {"id": "shutdown", "title": "Dienst beenden", "critical": True},
        ],
    }


@app.get("/api/v1/health")
def api_health() -> dict:
    return health()


@app.get("/api/v1/status")
def api_status() -> dict:
    return status_payload()


@app.get("/api/v1/config")
def api_get_config() -> dict:
    return {"status": "ok", "config": config, "config_schema_version": CONFIG_SCHEMA_VERSION}


@app.put("/api/v1/config")
def api_put_config(update: GatewayConfigUpdate, request: Request) -> dict:
    require_api_token(request)
    try:
        apply_config(update.config, save=True)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"status": "ok", "message": "Konfiguration gespeichert und neu geladen.", "config": config}


@app.post("/api/v1/reload")
def api_reload(request: Request) -> dict:
    require_api_token(request)
    try:
        apply_config(load_config(), save=False)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"status": "ok", "message": "Konfiguration neu geladen."}


@app.post("/api/v1/actions/{action_id}")
def api_action(action_id: str, request: Request, action_payload: ApiActionPayload | None = None) -> dict:
    if action_id in {"reload", "restart", "shutdown"}:
        require_api_token(request)
    if action_id == "test_connection":
        try:
            lms_players = lms.players()
        except LmsError as exc:
            return {"status": "error", "message": str(exc)}
        return {"status": "ok", "message": f"LMS erreichbar, {len(lms_players)} Player gefunden.", "players": lms_players}
    if action_id == "refresh_players":
        try:
            lms_players = refresh_players_from_lms()
        except LmsError as exc:
            return {"status": "error", "message": str(exc)}
        return {
            "status": "ok",
            "message": f"Playerliste aktualisiert, {len(lms_players)} Player gefunden.",
            "rooms": players.known_rooms(),
            "players": lms_players,
        }
    if action_id == "reload":
        return api_reload(request)
    if action_id == "restart":
        logger.warning("Restart requested from API action.")
        threading.Timer(1.0, stop_process_for_restart).start()
        return {"status": "ok", "message": "Neustart wird ausgeloest."}
    if action_id == "shutdown":
        logger.warning("Shutdown requested from API action.")
        threading.Timer(1.0, stop_process_for_restart).start()
        return {"status": "ok", "message": "Dienst wird beendet. Wenn NSSM automatischen Neustart nutzt, startet er erneut."}
    return {"status": "error", "message": f"Unbekannte Aktion: {action_id}"}


@app.get("/api/v1/logs/recent")
def api_logs_recent(lines: int = 120) -> dict:
    return {"status": "ok", "lines": read_recent_log_lines(lines)}


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "service": "lms-gateway",
        "config": str(CONFIG_PATH),
        "rooms": players.known_rooms(),
    }


@app.get("/lms/players")
def lms_players() -> dict:
    lms_player_list = lms.players()
    players.refresh_from_lms(lms_player_list)
    return {"players": lms_player_list, "rooms": players.known_rooms()}


@app.get("/lms/search")
def lms_search(q: str) -> dict:
    try:
        return {
            "query": q,
            "artists": lms.artists(search=q, limit=20),
            "albums": lms.albums(search=q, limit=20),
            "titles": lms.titles(search=q, limit=20),
            "inventory": library.artist_inventory(q),
        }
    except LmsError as exc:
        return {"query": q, "status": "error", "message": str(exc)}


@app.get("/lms/player/{room}/status")
def lms_player_status(room: str) -> dict:
    try:
        player = get_player(room)
    except LmsError as exc:
        return {"status": "error", "message": str(exc)}
    if not player:
        return {"status": "error", "message": f"Ziel {room} ist nicht konfiguriert und wurde auch nicht im LMS gefunden."}
    if not player.id:
        return {"status": "error", "message": f"Fuer {room} ist keine LMS Player-ID bekannt."}
    try:
        result = lms.request(player.id, ["status", "-", 1, "tags:"])
    except LmsError as exc:
        return {"status": "error", "message": str(exc)}
    return {"status": "ok", "room": player.room, "player_id": player.id, "lms": result}


@app.post("/lms/player/{room}/play_album/{album_id}")
def lms_play_album_by_id(room: str, album_id: str) -> dict:
    try:
        player = get_player(room)
    except LmsError as exc:
        return {"status": "error", "message": str(exc)}
    if not player:
        return {"status": "error", "message": f"Ziel {room} ist nicht konfiguriert und wurde auch nicht im LMS gefunden."}
    if not player.id:
        return {"status": "error", "message": f"Fuer {room} ist keine LMS Player-ID bekannt."}
    try:
        logger.info("Direct album playback requested: room=%s album_id=%s", room, album_id)
        responses = lms.play_album(player.id, album_id)
    except LmsError as exc:
        return {"status": "error", "message": str(exc)}
    except Exception as exc:
        return {"status": "error", "message": f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}"}
    return {"status": "ok", "room": player.room, "album_id": album_id, "lms_responses": responses}


@app.post("/lms/command", response_model=CommandResponse)
def lms_command(command: CommandRequest) -> CommandResponse:
    logger.info(
        "Command received: text=%r room=%r device=%r user=%r source=%r dry_run=%s",
        command.text,
        command.room,
        command.device,
        command.user,
        command.source,
        command.dry_run,
    )
    if is_duplicate_assist_command(command):
        response = CommandResponse(status="ok", message="Okay.", action="duplicate_ignored", room=clean_room(command.room))
        log_command_response(response)
        return response

    session_response = handle_pending_session(command)
    if session_response:
        log_command_response(session_response)
        return session_response

    parsed = parse_command(command.text, clean_room(command.room), players.known_names())
    if not parsed.get("room") and should_refresh_rooms_for_text(command):
        try:
            refresh_players_from_lms()
        except LmsError:
            pass
        else:
            parsed = parse_command(command.text, clean_room(command.room), players.known_names())
    if parsed.get("action") == "unknown":
        response = CommandResponse(
            status="error",
            message="Diesen LMS-Befehl habe ich nicht verstanden.",
            action="unknown",
        )
        log_command_response(response)
        return response

    response = execute_parsed_command(command, parsed)
    log_command_response(response)
    return response


def is_duplicate_assist_command(command: CommandRequest) -> bool:
    if command.dry_run:
        return False
    source = clean_text_key(command.source)
    if source not in {"assist", "home_assistant"}:
        return False
    text = normalize_command_fingerprint(command.text)
    if not text:
        return False
    key = (
        source,
        clean_text_key(command.user),
        clean_text_key(command.device),
        clean_text_key(command.room),
        text,
    )
    now = time.monotonic()
    with recent_command_lock:
        expired_before = now - RECENT_COMMAND_WINDOW_SECONDS
        for old_key, seen_at in list(recent_commands.items()):
            if seen_at < expired_before:
                recent_commands.pop(old_key, None)
        previous = recent_commands.get(key)
        recent_commands[key] = now
    if previous is not None and now - previous <= RECENT_COMMAND_WINDOW_SECONDS:
        logger.info("Duplicate assist command ignored: text=%r source=%r device=%r", command.text, command.source, command.device)
        return True
    return False


def normalize_command_fingerprint(text: str | None) -> str:
    return re.sub(r"\s+", " ", str(text or "").casefold()).strip(" .,!?:;")


def clean_text_key(value: str | None) -> str:
    return re.sub(r"\s+", " ", str(value or "").casefold()).strip()


def log_command_response(response: CommandResponse) -> None:
    logger.info(
        "Command response: status=%s action=%s room=%s followup=%s followup_seconds=%s message=%r options=%s",
        response.status,
        response.action,
        response.room,
        response.followup,
        response.followup_seconds,
        response.message,
        response.options,
    )


def execute_parsed_command(command: CommandRequest, parsed: dict) -> CommandResponse:
    action = parsed.get("action")

    if action in {"alarm_snooze", "alarm_stop"} and not parsed.get("room"):
        return handle_active_alarm_command(command, parsed)

    if action == "unsync_players":
        return handle_unsync_players(command, parsed)
    if action == "unsync_all":
        return handle_unsync_all(command)
    if action == "sync_players":
        return handle_sync_players(command, parsed)
    if action == "continue_playback":
        return handle_continue_playback(command, parsed)
    if action == "album_selection_jump":
        return handle_album_selection_jump_without_session(command)
    if action == "list_artist_albums":
        return handle_list_artist_albums(command, parsed)
    if action == "list_audiobooks":
        return handle_list_audiobooks(command, parsed)
    if action in {"transport", "transport_jump", "volume"}:
        player = resolve_transport_player(command, parsed)
        if isinstance(player, CommandResponse):
            return player
        if action == "volume":
            return handle_volume_command(command, parsed, player)
        return handle_transport_command(command, parsed, player)
    if action == "select_album_option":
        player = resolve_action_player(command, parsed)
        if isinstance(player, CommandResponse):
            return player
        return play_selected_album(command, parsed["selected"], player, parsed.get("session") or {})
    if action == "select_music_folder_option":
        player = resolve_action_player(command, parsed)
        if isinstance(player, CommandResponse):
            return player
        return play_selected_music_folder(command, parsed["selected"], player)

    player = resolve_action_player(command, parsed)
    if isinstance(player, CommandResponse):
        return player

    if action == "play_album_dialog":
        return handle_play_album_dialog(command, parsed, player)
    if action == "play_radio_dialog":
        return handle_play_radio_dialog(command, parsed, player)
    if action == "play_radio":
        return handle_play_radio(command, parsed, player)
    if action == "play_music_folder":
        return handle_play_music_folder(command, parsed, player)
    if action == "play_album_title":
        return handle_play_album_title(command, parsed, player)
    if action == "play_title":
        return handle_play_title(command, parsed, player)
    if action == "play_artist_playlist":
        return handle_play_artist_playlist(command, parsed, player)
    if action == "play_metadata_playlist":
        return handle_play_metadata_playlist(command, parsed, player)
    if action == "play_genre":
        radio_response = try_handle_radio_favorite_before_genre(command, parsed, player)
        if radio_response:
            return radio_response
        return handle_play_genre_playlist(command, parsed, player)
    if action == "play_current_album":
        return handle_play_current_album(command, parsed, player)
    if action == "play_similar":
        return handle_play_similar_short(command, parsed, player)
    if action == "alarm_create":
        return handle_alarm_create(command, parsed, player)
    if action == "alarm_list":
        return handle_alarm_list(parsed, player)
    if action == "alarm_snooze":
        return handle_alarm_snooze(command, parsed, player)
    if action == "alarm_stop":
        return handle_alarm_stop(command, player)
    if action in {"alarm_enable_all", "alarm_disable_all"}:
        return handle_alarm_toggle_all(command, player, action == "alarm_enable_all")
    if action in {"alarm_delete_next", "alarm_disable_next"}:
        return handle_alarm_next(command, player, delete=action == "alarm_delete_next")
    if action == "alarm_delete_all":
        return handle_alarm_delete_all(command, player)

    return CommandResponse(status="error", message="Diesen LMS-Befehl habe ich nicht verstanden.", action=action)


def alarm_loop(data: dict[str, Any]) -> list[dict[str, Any]]:
    value = data.get("alarms_loop") or data.get("alarm_loop") or []
    return value if isinstance(value, list) else []


def alarm_days_text(value: Any) -> str:
    names = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"]
    days = [safe_int(item, -1) for item in str(value or "").split(",")]
    days = [day for day in days if 0 <= day <= 6]
    if days == list(range(7)):
        return "täglich"
    if days == [1, 2, 3, 4, 5]:
        return "werktags"
    return ", ".join(names[day] for day in days) or "ohne Wochentag"


def alarm_time_text(seconds: Any) -> str:
    value = max(0, safe_int(seconds, 0))
    return f"{value // 3600:02d}:{(value % 3600) // 60:02d} Uhr"


def alarm_sort_key(alarm: dict[str, Any]) -> tuple[int, int]:
    now = datetime.now()
    current_lms_day = (now.weekday() + 1) % 7
    alarm_days = [safe_int(item, -1) for item in str(alarm.get("dow") or "").split(",")]
    alarm_seconds = safe_int(alarm.get("time"), 0)
    now_seconds = now.hour * 3600 + now.minute * 60 + now.second
    offsets = [((day - current_lms_day) % 7) for day in alarm_days if 0 <= day <= 6]
    candidates = [offset * 86400 + alarm_seconds - now_seconds for offset in offsets]
    future = [candidate for candidate in candidates if candidate >= 0]
    return (min(future) if future else 8 * 86400, alarm_seconds)


def handle_alarm_create(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    now = datetime.now()
    relative_minutes = safe_int(parsed.get("relative_minutes"), 0)
    if relative_minutes:
        due = now + timedelta(minutes=relative_minutes)
        hour, minute = due.hour, due.minute
        days = [(due.weekday() + 1) % 7]
        repeat = False
        date_text = due.strftime("%d.%m.%Y")
    else:
        hour = safe_int(parsed.get("hour"), -1)
        minute = safe_int(parsed.get("minute"), -1)
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            return CommandResponse(status="clarify", message="Um welche Uhrzeit soll ich dich wecken?", action="alarm_create", room=player.room, followup=True, followup_seconds=session_ttl_seconds(config))
        schedule = parsed.get("schedule") or "next"
        repeat = bool(parsed.get("repeat"))
        if schedule == "weekdays":
            days = [1, 2, 3, 4, 5]
            date_text = "werktags"
        elif schedule == "daily":
            days = list(range(7))
            date_text = "täglich"
        else:
            due = now + timedelta(days=1) if schedule == "tomorrow" else now
            if schedule == "next" and (hour, minute) <= (now.hour, now.minute):
                due += timedelta(days=1)
            days = [(due.weekday() + 1) % 7]
            date_text = due.strftime("%d.%m.%Y")

    try:
        if not command.dry_run:
            alarm_defaults = config.get("alarms") or {}
            lms.add_alarm(
                player.id,
                time_seconds=hour * 3600 + minute * 60,
                days=days,
                repeat=repeat,
                volume=safe_int(alarm_defaults.get("volume"), 50),
                url=str(alarm_defaults.get("url") or "CURRENT_PLAYLIST"),
                shuffle=bool(alarm_defaults.get("shuffle", False)),
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_create", room=player.room)
    return CommandResponse(
        status="ok",
        message=f"Der {'wiederkehrende' if repeat else 'einmalige'} Wecker im {player.room} ist für {date_text} um {hour:02d}:{minute:02d} Uhr gestellt.",
        action="alarm_create",
        room=player.room,
    )


def handle_alarm_list(parsed: dict, player) -> CommandResponse:
    try:
        alarms = alarm_loop(lms.alarms(player.id))
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_list", room=player.room)
    if not alarms:
        return CommandResponse(status="ok", message=f"Im {player.room} sind keine Wecker gespeichert.", action="alarm_list", room=player.room)
    descriptions = [
        f"{index}. {alarm_days_text(item.get('dow'))} um {alarm_time_text(item.get('time'))}, {'aktiv' if safe_int(item.get('enabled'), 0) else 'deaktiviert'}"
        for index, item in enumerate(sorted(alarms, key=alarm_sort_key), 1)
    ]
    return CommandResponse(status="ok", message=f"Im {player.room} sind folgende Wecker gespeichert: " + "; ".join(descriptions) + ".", action="alarm_list", room=player.room, options=descriptions, followup=True, followup_seconds=session_ttl_seconds(config))


def active_alarm_players():
    active = []
    for room in players.known_rooms():
        player = get_player(room)
        if not player or not player.id:
            continue
        try:
            status = lms.request(player.id, ["status", "-", 1, "alarmData:1", "tags:"])
        except LmsError:
            continue
        if str(status.get("alarm_state") or "").casefold() in {"active", "snooze"}:
            active.append(player)
    return active


def handle_active_alarm_command(command: CommandRequest, parsed: dict) -> CommandResponse:
    context = device_contexts.get(command.device, user=command.user, source=command.source)
    context_room = (context.last_room or context.default_room) if context else None
    if context_room:
        player = get_player(context_room)
        if player and player.id:
            return handle_alarm_snooze(command, parsed, player) if parsed["action"] == "alarm_snooze" else handle_alarm_stop(command, player)
    active = active_alarm_players()
    if len(active) == 1:
        return handle_alarm_snooze(command, parsed, active[0]) if parsed["action"] == "alarm_snooze" else handle_alarm_stop(command, active[0])
    if not active:
        return CommandResponse(status="error", message="Ich finde gerade keinen aktiven LMS-Wecker.", action=parsed["action"])
    return CommandResponse(status="clarify", message="Welchen klingelnden Wecker meinst du?", action=parsed["action"], options=[item.room for item in active], followup=True, followup_seconds=session_ttl_seconds(config))


def handle_alarm_snooze(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    minutes = parsed.get("minutes")
    try:
        if not command.dry_run:
            lms.snooze_alarm(player.id, minutes)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_snooze", room=player.room)
    duration = f" für {minutes} Minuten" if minutes else ""
    return CommandResponse(status="ok", message=f"Der Wecker im {player.room} schlummert{duration}.", action="alarm_snooze", room=player.room)


def handle_alarm_stop(command: CommandRequest, player) -> CommandResponse:
    try:
        if not command.dry_run:
            lms.stop_alarm(player.id)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_stop", room=player.room)
    return CommandResponse(status="ok", message=f"Der klingelnde Wecker im {player.room} ist beendet.", action="alarm_stop", room=player.room)


def handle_alarm_toggle_all(command: CommandRequest, player, enabled: bool) -> CommandResponse:
    try:
        if not command.dry_run:
            lms.set_all_alarms_enabled(player.id, enabled)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_enable_all" if enabled else "alarm_disable_all", room=player.room)
    state = "aktiviert" if enabled else "deaktiviert"
    return CommandResponse(status="ok", message=f"Alle Wecker im {player.room} sind {state}.", action="alarm_enable_all" if enabled else "alarm_disable_all", room=player.room)


def handle_alarm_next(command: CommandRequest, player, *, delete: bool) -> CommandResponse:
    try:
        alarms = [item for item in alarm_loop(lms.alarms(player.id, enabled_only=True)) if item.get("id")]
        if not alarms:
            return CommandResponse(status="error", message=f"Im {player.room} ist kein aktiver Wecker gespeichert.", action="alarm_delete_next" if delete else "alarm_disable_next", room=player.room)
        selected = min(alarms, key=alarm_sort_key)
        if not command.dry_run:
            if delete:
                lms.delete_alarm(player.id, str(selected["id"]))
            else:
                lms.update_alarm(player.id, str(selected["id"]), enabled=0)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_delete_next" if delete else "alarm_disable_next", room=player.room)
    verb = "gelöscht" if delete else "deaktiviert"
    return CommandResponse(status="ok", message=f"Der nächste Wecker im {player.room}, {alarm_days_text(selected.get('dow'))} um {alarm_time_text(selected.get('time'))}, wurde {verb}.", action="alarm_delete_next" if delete else "alarm_disable_next", room=player.room)


def handle_alarm_delete_all(command: CommandRequest, player) -> CommandResponse:
    try:
        alarms = [item for item in alarm_loop(lms.alarms(player.id)) if item.get("id")]
        if not command.dry_run:
            for item in alarms:
                lms.delete_alarm(player.id, str(item["id"]))
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="alarm_delete_all", room=player.room)
    return CommandResponse(status="ok", message=f"Alle {len(alarms)} Wecker im {player.room} wurden gelöscht.", action="alarm_delete_all", room=player.room)


def resolve_action_player(command: CommandRequest, parsed: dict):
    room = parsed.get("room") or clean_room(command.room)
    if room:
        try:
            player = get_player(room)
        except LmsError as exc:
            return CommandResponse(status="error", message=str(exc), action=parsed.get("action"), room=room)
        if player and player.id:
            remember_command_room(command, player)
            return player
        known = ", ".join(players.known_rooms()) or "keine Ziele bekannt"
        return CommandResponse(
            status="error",
            message=f"Ich kenne das Ziel {room} nicht. Bekannte Ziele: {known}.",
            action=parsed.get("action"),
            room=room,
        )

    context = device_contexts.get(command.device, user=command.user, source=command.source)
    context_room = (context.last_room or context.default_room) if context else None
    if context_room:
        try:
            player = get_player(context_room)
        except LmsError:
            player = None
        if player and player.id:
            return player

    if command.device:
        sessions.set(
            command.device,
            make_session(target_dialog_state(parsed)),
        )
    if str(parsed.get("action") or "").startswith("alarm_"):
        prompt = "Für welchen Raum oder Player soll ich den Wecker einstellen?"
    else:
        prompt = "Auf welchem Player soll ich das spielen?"
    return CommandResponse(
        status="clarify",
        message=prompt,
        action="select_room",
        options=players.known_rooms(),
    )


def handle_pending_session(command: CommandRequest) -> CommandResponse | None:
    session = sessions.get(command.device)
    if not session:
        session = latest_matching_album_session(command)
    if not session:
        return None
    if is_dialog_cancel(command.text):
        logger.info(
            "Dialog cancelled: device=%r status=%r text=%r",
            command.device,
            session.status,
            command.text,
        )
        sessions.clear(command.device)
        return CommandResponse(status="ok", message="Okay, ich breche den Dialog ab.", action="cancel_dialog", room=session.room)
    if is_gateway_prompt_echo(command.text):
        logger.warning(
            "Ignoring likely gateway prompt echo: device=%r status=%r text=%r",
            command.device,
            session.status,
            command.text,
        )
        return CommandResponse(status="ok", message="", action="ignored_echo", room=session.room)

    parsed = parse_command(command.text, clean_room(command.room) or session.room, players.known_names())
    if session.status == "waiting_target":
        if is_explicit_new_primary_command(parsed):
            logger.info(
                "Target selection session replaced by explicit new command: device=%r text=%r action=%r",
                command.device,
                command.text,
                parsed.get("action"),
            )
            sessions.clear(command.device)
            return None
        room = parsed.get("room") or clean_room(command.room)
        if not room and parsed.get("action") == "unknown":
            room = cleanup_room_text(command.text)
        dialog_state = state_from_session(session)
        stored = dict(dialog_state.fields.get("parsed") or session.data.get("parsed") or {})
        if not room:
            return CommandResponse(
                status="clarify",
                message=dialog_state.spec.target_prompt,
                action="select_room",
                options=players.known_rooms(),
            )
        stored["room"] = room
        if stored.get("action") in {"sync_players", "continue_playback"} and not stored.get("target_room"):
            stored["target_room"] = room
        sessions.clear(command.device)
        if stored.get("action") == "select_album_option":
            selected = stored.get("selected")
            options = stored.get("options") or session.options
            session_data = stored.get("session") or {}
            if isinstance(selected, dict) and options:
                try:
                    player = get_player(room)
                except LmsError as exc:
                    return CommandResponse(status="error", message=str(exc), room=room)
                if not player or not player.id:
                    known = ", ".join(players.known_rooms()) or "keine Ziele bekannt"
                    return CommandResponse(
                        status="error",
                        message=f"Ich kenne das Ziel {room} nicht. Bekannte Ziele: {known}.",
                        action="select_room",
                        room=room,
                    )
                album_session = make_session(album_dialog_state(room, str(session_data.get("artist", "")), options))
                album_session.data.update(session_data)
                return play_selected_album_with_session(
                    command,
                    selected,
                    stored.get("selected_index"),
                    player,
                    album_session,
                )
        if stored.get("action") == "select_music_folder_option":
            selected = stored.get("selected")
            if isinstance(selected, dict):
                try:
                    player = get_player(room)
                except LmsError as exc:
                    return CommandResponse(status="error", message=str(exc), room=room)
                if not player or not player.id:
                    known = ", ".join(players.known_rooms()) or "keine Ziele bekannt"
                    return CommandResponse(
                        status="error",
                        message=f"Ich kenne das Ziel {room} nicht. Bekannte Ziele: {known}.",
                        action="select_room",
                        room=room,
                    )
                return play_selected_music_folder(command, selected, player)
        return execute_parsed_command(command, stored)

    if session.status == "waiting_album_selection":
        dialog_state = state_from_session(session)
        selected, selected_index = select_option(command.text, dialog_state, DIALOG_SELECTORS)
        jump_delta = album_selection_jump_delta(command.text)
        if not selected and is_explicit_session_replacing_command(parsed):
            logger.info(
                "Album selection session replaced by explicit new command before selection: device=%r text=%r action=%r",
                command.device,
                command.text,
                parsed.get("action"),
            )
            sessions.clear(command.device)
            return None

        if not selected and is_explicit_new_primary_command(parsed):
            logger.info(
                "Album selection session replaced by explicit new command: device=%r text=%r action=%r",
                command.device,
                command.text,
                parsed.get("action"),
            )
            sessions.clear(command.device)
            return None
        if jump_delta is not None and not selected:
            direction = "weiteres" if jump_delta > 0 else "vorheriges"
            return CommandResponse(
                status="error",
                message=f"In dieser Auswahl gibt es kein {direction} Album.",
                action="album_selection_jump",
                room=session.room,
            )
        if not selected and is_new_primary_command(command.text, parsed):
            logger.info(
                "Album selection session replaced by new command: device=%r text=%r action=%r",
                command.device,
                command.text,
                parsed.get("action"),
            )
            sessions.clear(command.device)
            return None
        if not selected:
            options = album_option_names(session.options, artist_context=session.data.get("artist"))
            return CommandResponse(
                status="error",
                message=f"Ich habe die Auswahl nicht verstanden. Zur Auswahl stehen: {', '.join(options)}.",
                action="select_album",
                room=session.room,
                options=options,
            )
        room = parsed.get("room") or clean_room(command.room) or session.room
        try:
            player = get_player(room)
        except LmsError as exc:
            return CommandResponse(status="error", message=str(exc), room=room)
        if not player or not player.id:
            sessions.set(
                command.device,
                make_session(
                    target_dialog_state(
                        {
                            "action": "select_album_option",
                            "selected": selected,
                            "selected_index": selected_index,
                            "options": session.options,
                            "session": session.data,
                        },
                        options=session.options,
                        prompt="Auf welchem Player soll ich das Album spielen?",
                    )
                ),
            )
            return CommandResponse(
                status="clarify",
                message="Auf welchem Player soll ich das Album spielen?",
                action="select_room",
                options=players.known_rooms(),
            )

        return play_selected_album_with_session(command, selected, selected_index, player, session)

    if session.status == "waiting_radio_selection":
        dialog_state = state_from_session(session)
        selected, selected_index = select_option(command.text, dialog_state, DIALOG_SELECTORS)
        if not selected and is_new_primary_command(command.text, parsed):
            logger.info(
                "Radio selection session replaced by new command: device=%r text=%r action=%r",
                command.device,
                command.text,
                parsed.get("action"),
            )
            sessions.clear(command.device)
            return None
        room = parsed.get("room") or clean_room(command.room) or session.room
        try:
            player = get_player(room)
        except LmsError as exc:
            return CommandResponse(status="error", message=str(exc), room=room)
        if not player or not player.id:
            return CommandResponse(
                status="clarify",
                message="Auf welchem Player soll ich den Radiosender spielen?",
                action="select_room",
                options=players.known_rooms(),
            )
        if not selected:
            options = favorite_option_names(session.options)
            return CommandResponse(
                status="clarify",
                message=f"Ich habe die Auswahl nicht verstanden. Zur Auswahl stehen: {', '.join(options)}.",
                action="select_radio",
                room=player.room,
                options=options,
            )
        return play_selected_radio(command, selected, player)

    if session.status == "waiting_folder_selection":
        dialog_state = state_from_session(session)
        selected, selected_index = select_option(command.text, dialog_state, DIALOG_SELECTORS)
        is_audiobook = dialog_state.fields.get("folder_category") == "audiobook"
        target_prompt = "Auf welchem Player soll ich das Hoerbuch spielen?" if is_audiobook else "Auf welchem Player soll ich den Ordner spielen?"
        if not selected and is_new_primary_command(command.text, parsed):
            logger.info(
                "Folder selection session replaced by new command: device=%r text=%r action=%r",
                command.device,
                command.text,
                parsed.get("action"),
            )
            sessions.clear(command.device)
            return None
        if not selected:
            options = folder_option_names(session.options)
            return CommandResponse(
                status="clarify",
                message=f"Ich habe die Auswahl nicht verstanden. Zur Auswahl stehen: {', '.join(options)}.",
                action="select_folder",
                room=session.room,
                options=options,
            )
        room = parsed.get("room") or clean_room(command.room) or session.room
        try:
            player = get_player(room)
        except LmsError as exc:
            return CommandResponse(status="error", message=str(exc), room=room)
        if not player or not player.id:
            sessions.set(
                command.device,
                make_session(
                    target_dialog_state(
                        {
                            "action": "select_music_folder_option",
                            "selected": selected,
                            "selected_index": selected_index,
                            "options": session.options,
                        },
                        options=session.options,
                        prompt=target_prompt,
                    )
                ),
            )
            return CommandResponse(
                status="clarify",
                message=target_prompt,
                action="select_room",
                options=players.known_rooms(),
            )
        return play_selected_music_folder(command, selected, player)

    return None


def latest_matching_album_session(command: CommandRequest) -> SessionState | None:
    session = sessions.get_latest("waiting_album_selection")
    if not session:
        return None
    state = state_from_session(session)
    selected, _selected_index = select_option(command.text, state, DIALOG_SELECTORS)
    if selected:
        logger.info(
            "Using latest album selection session for command without matching device session: command_device=%r session_room=%r text=%r",
            command.device,
            session.room,
            command.text,
        )
        return session
    if album_selection_jump_delta(command.text) is not None:
        logger.info(
            "Using latest album selection session for album jump without matching device session: command_device=%r session_room=%r text=%r",
            command.device,
            session.room,
            command.text,
        )
        return session
    parsed = parse_command(command.text, clean_room(command.room) or session.room, players.known_names())
    if is_explicit_session_replacing_command(parsed):
        return None
    return None


def play_selected_album(command: CommandRequest, selected: dict, player, session_data: dict) -> CommandResponse:
    album_id = selected.get("id")
    if album_id is None:
        return CommandResponse(status="error", message="LMS hat fuer dieses Album keine Album-ID geliefert.", room=player.room)
    try:
        if not command.dry_run:
            responses = lms.play_album(player.id, str(album_id))
            logger.info("Session album playback started: player=%s album_id=%s responses=%s", player.id, album_id, responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)
    finally:
        sessions.clear(command.device)

    remember_command_room(command, player)
    album_name = str(selected.get("album", ""))
    artist_name = str(selected.get("artist", "") or selected.get("albumartist", "") or session_data.get("artist", ""))
    return CommandResponse(
        status="ok",
        message=f"Ich spiele jetzt {album_name} von {artist_name} {target_phrase(player)}.",
        action="play",
        artist=artist_name or None,
        album=album_name,
        room=player.room,
        shuffle=False,
    )


def play_selected_album_with_session(
    command: CommandRequest,
    selected: dict,
    selected_index: int | None,
    player,
    session: SessionState,
) -> CommandResponse:
    response = play_selected_album(command, selected, player, session.data)
    if response.status == "ok" and command.device:
        index = selected_index
        if index is None:
            index = index_of_option(session.options, selected)
        state = album_dialog_state(
            player.room,
            str(session.data.get("artist", "")),
            session.options,
        )
        state.fields.update(session.data)
        state.current_index = index
        sessions.set(
            command.device,
            make_session(state),
        )
    return response


def select_album_from_session_command(text: str, session: SessionState) -> tuple[dict | None, int | None]:
    delta = album_selection_jump_delta(text)
    if delta is not None:
        current_index = session.data.get("current_index")
        if current_index is None:
            current_index = -1 if delta > 0 else len(session.options)
        next_index = int(current_index) + delta
        if 0 <= next_index < len(session.options):
            return session.options[next_index], next_index
        return None, None

    selected = select_album_option(text, session.options)
    return selected, index_of_option(session.options, selected)


def album_selection_jump_delta(text: str) -> int | None:
    cleaned = text.casefold().strip(" .,!?:;")
    next_album = (
        r"\b(?:(?:spiel|spiele)\s+)?(?:bitte\s+)?(?:"
        r"(?:das\s+)?"
        r"(?:ein(?:en)?\s+)?album\s+(?:vor|vorspringen)|"
        r"(?:das\s+)?n(?:ae|ä)chste(?:s|n|r)?\s+album"
        r")(?:\s+abspielen)?\b"
    )
    previous_album = (
        r"\b(?:(?:spiel|spiele)\s+)?(?:bitte\s+)?(?:"
        r"(?:das\s+)?"
        r"(?:ein(?:en)?\s+)?album\s+(?:zurueck|zurück|zurueckspringen|zurückspringen)|"
        r"(?:das\s+)?(?:voriges|vorheriges|vorhergehendes|vorhergehende(?:s|n|r)?)\s+album"
        r")(?:\s+abspielen)?\b"
    )
    if re.search(next_album, cleaned):
        return 1
    if re.search(previous_album, cleaned):
        return -1

    if re.search(r"\b(?:ein(?:en)?\s+)?album\s+(?:vor|vorspringen)|\bn(?:ae|Ã¤)chstes\s+album\b", cleaned):
        return 1
    if re.search(r"\b(?:ein(?:en)?\s+)?album\s+(?:zurueck|zurÃ¼ck|zurueckspringen|zurÃ¼ckspringen)|\b(?:voriges|vorheriges|vorhergehendes)\s+album\b", cleaned):
        return -1
    return None


def index_of_option(options: list[dict], selected: dict | None) -> int | None:
    if selected is None:
        return None
    selected_id = selected.get("id")
    for index, option in enumerate(options):
        if selected_id is not None and option.get("id") == selected_id:
            return index
        if option is selected:
            return index
    return None


def handle_album_selection_jump_without_session(command: CommandRequest) -> CommandResponse:
    return CommandResponse(
        status="error",
        message="Ich habe keine offene Albumauswahl. Bitte frage zuerst nach Alben eines Kuenstlers.",
        action="select_album",
    )


def play_selected_radio(command: CommandRequest, selected: dict, player) -> CommandResponse:
    favorite_id = selected.get("id")
    if favorite_id is None:
        return CommandResponse(status="error", message="LMS hat fuer diesen Radiosender keine Favoriten-ID geliefert.", room=player.room)
    try:
        if not command.dry_run:
            responses = lms.play_favorite(player.id, str(favorite_id))
            logger.info("Radio favorite playback started: player=%s favorite_id=%s responses=%s", player.id, favorite_id, responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)
    finally:
        sessions.clear(command.device)

    remember_command_room(command, player)
    if not command.dry_run:
        remember_last_radio(player, selected)
    radio_name = str(selected.get("name", ""))
    radio_label = radio_name if radio_name.casefold().startswith("radio ") else f"Radio {radio_name}"
    return CommandResponse(
        status="ok",
        message=f"Ich spiele jetzt {radio_label} {target_phrase(player)}.",
        action="play_radio",
        room=player.room,
        shuffle=False,
    )


def remember_last_radio(player, selected: dict) -> None:
    radio = {
        "id": selected.get("id"),
        "name": selected.get("name"),
    }
    with last_radio_lock:
        for key in radio_history_keys(player):
            if key:
                last_radio_by_target[key] = radio
    save_last_radio_state()


def last_radio_for_player(player) -> dict | None:
    with last_radio_lock:
        for key in radio_history_keys(player):
            selected = last_radio_by_target.get(key)
            if selected:
                return dict(selected)
    return None


def radio_history_keys(player) -> list[str]:
    keys = []
    room = clean_room(getattr(player, "room", None))
    player_id = str(getattr(player, "id", "") or "").strip()
    if room:
        keys.append(f"room:{room}")
    if player_id:
        keys.append(f"player:{player_id}")
    return keys


def handle_play_music_folder(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    query = str(parsed.get("folder_query") or "").strip()
    category = str(parsed.get("folder_category") or "folder")
    try:
        matches = find_music_folders(query, category)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)

    if not matches:
        label = query or music_folder_category_label(category)
        return CommandResponse(status="error", message=f"Ich habe keinen passenden Musikordner zu {label} gefunden.", room=player.room)

    if len(matches) == 1:
        return play_selected_music_folder(command, matches[0], player)

    options = matches[:8]
    if command.device:
        sessions.set(command.device, make_session(folder_dialog_state(player.room, options, category=category)))
        logger.info(
            "Music folder selection session started: device=%r room=%r query=%r category=%r options=%s",
            command.device,
            player.room,
            query,
            category,
            folder_option_names(options),
        )
    names = folder_option_names(options)
    item_label = "Hoerbuecher" if category == "audiobook" else "Ordner"
    prompt = "Welches soll ich spielen?" if category == "audiobook" else "Welchen soll ich spielen?"
    return CommandResponse(
        status="clarify",
        message=f"Ich habe diese {item_label} gefunden: {', '.join(names)}. {prompt}",
        action="select_folder",
        room=player.room,
        options=names,
        followup=True,
        followup_seconds=session_ttl_seconds(config),
    )


def handle_list_audiobooks(command: CommandRequest, parsed: dict) -> CommandResponse:
    query = str(parsed.get("folder_query") or "").strip()
    try:
        matches = find_music_folders(query, "audiobook")[:8]
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="list_audiobooks")
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            action="list_audiobooks",
        )

    if not matches:
        return CommandResponse(
            status="error",
            message=f"Ich habe keine passenden Hoerbuecher zu {query} gefunden.",
            action="list_audiobooks",
        )

    names = folder_option_names(matches)
    return CommandResponse(
        status="ok",
        message="Ich habe diese Hörbücher gefunden: " + "; ".join(names),
        action="list_audiobooks",
        options=names,
        followup=False,
    )


def play_selected_music_folder(command: CommandRequest, selected: dict, player) -> CommandResponse:
    folder_id = selected.get("id")
    if folder_id is None:
        return CommandResponse(status="error", message="LMS hat fuer diesen Ordner keine ID geliefert.", room=player.room)
    try:
        urls = collect_musicfolder_track_urls(folder_id)
        if not urls:
            return CommandResponse(status="error", message=f"Ich habe in {selected.get('name', 'diesem Ordner')} keine abspielbaren Dateien gefunden.", room=player.room)
        if not command.dry_run:
            responses = lms.play_urls(player.id, urls, shuffle=False)
            logger.info(
                "Music folder playback started: player=%s folder_id=%s tracks=%s responses=%s",
                player.id,
                folder_id,
                len(urls),
                responses,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)
    finally:
        sessions.clear(command.device)

    remember_command_room(command, player)
    folder_name = str(selected.get("name") or "den Ordner").strip()
    return CommandResponse(
        status="ok",
        message=f"Ich spiele jetzt {folder_name} {target_phrase(player)}.",
        action="play_music_folder",
        room=player.room,
        album=folder_name,
        shuffle=False,
    )


def find_music_folders(query: str, category: str, limit: int = 8) -> list[dict[str, Any]]:
    roots = musicfolder_category_roots(category)
    if not roots:
        return []
    if not query:
        options = []
        for root in roots:
            for item in lms.musicfolder(root.get("id"), limit=200):
                if is_musicfolder_folder(item):
                    options.append(enrich_musicfolder_item(item, str(root.get("name", ""))))
        return options[:limit]

    return search_musicfolder_tree(query, roots, limit=limit, max_depth=4, max_items=800)


def search_musicfolder_tree(query: str, roots: list[dict[str, Any]], limit: int, max_depth: int, max_items: int) -> list[dict[str, Any]]:
    frontier: list[tuple[dict[str, Any], int, str]] = [(root, 0, str(root.get("name", ""))) for root in roots]
    visited = 0
    fallback_candidates: list[dict[str, Any]] = []
    while frontier and visited < max_items:
        next_frontier: list[tuple[dict[str, Any], int, str]] = []
        level_candidates: list[dict[str, Any]] = []
        immediate_matches: list[dict[str, Any]] = []
        for current, depth, path in frontier:
            if visited >= max_items:
                break
            folder_id = current.get("id")
            if folder_id is None:
                continue
            for child in lms.musicfolder(folder_id, limit=500):
                if not is_musicfolder_folder(child):
                    continue
                visited += 1
                child_name = musicfolder_display_name(child)
                child_path = f"{path}/{child_name}" if child_name else path
                enriched = enrich_musicfolder_item(child, path)
                enriched["path"] = child_path
                level_candidates.append(enriched)
                if is_musicfolder_query_match(query, enriched):
                    immediate_matches.append(enriched)
                if depth + 1 < max_depth:
                    next_frontier.append((enriched, depth + 1, child_path))
            if immediate_matches:
                return filter_ranked_musicfolder_matches(query, immediate_matches, limit)

        matches = filter_ranked_musicfolder_matches(query, level_candidates, limit)
        if matches:
            return matches
        fallback_candidates.extend(level_candidates)
        frontier = next_frontier

    return filter_ranked_musicfolder_matches(query, fallback_candidates, limit)


def filter_ranked_musicfolder_matches(query: str, candidates: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    ranked = sorted(candidates, key=lambda item: musicfolder_match_score(query, item), reverse=True)
    result = []
    seen = set()
    normalized_query = normalize_command_fingerprint(query)
    for item in ranked:
        score = musicfolder_match_score(query, item)
        name = musicfolder_display_name(item)
        path = str(item.get("path", name))
        if not is_musicfolder_query_match(query, item):
            continue
        key = item.get("id") or path
        if key in seen:
            continue
        result.append(item)
        seen.add(key)
        if len(result) >= limit:
            break
    return result


def is_musicfolder_query_match(query: str, item: dict[str, Any]) -> bool:
    name = musicfolder_display_name(item)
    path = str(item.get("path", name))
    normalized_query = normalize_command_fingerprint(query)
    normalized_path = normalize_command_fingerprint(path)
    if normalized_query and normalized_query in normalized_path:
        return True
    query_tokens = [token for token in re.findall(r"[a-z0-9ÃƒÂ¤ÃƒÂ¶ÃƒÂ¼]+", normalized_query) if len(token) >= 5]
    distinctive_tokens = longest_musicfolder_query_tokens(query_tokens)
    if any(token in normalized_path for token in distinctive_tokens):
        return True
    path_tokens = [token for token in re.findall(r"[a-z0-9ÃƒÂ¤ÃƒÂ¶ÃƒÂ¼]+", normalized_path) if len(token) >= 5]
    if any(has_similar_musicfolder_token(token, path_tokens) for token in distinctive_tokens):
        return True
    minimum_score = 0.55 if len(query_tokens) > 1 else 0.38
    return musicfolder_match_score(query, item) >= minimum_score


def longest_musicfolder_query_tokens(tokens: list[str]) -> list[str]:
    if len(tokens) <= 1:
        return tokens
    longest = max(len(token) for token in tokens)
    return [token for token in tokens if len(token) == longest]


def has_similar_musicfolder_token(query_token: str, path_tokens: list[str]) -> bool:
    for path_token in path_tokens:
        if SequenceMatcher(None, query_token, path_token).ratio() >= 0.82:
            return True
    return False


def musicfolder_category_roots(category: str) -> list[dict[str, Any]]:
    top_level = lms.musicfolder(limit=200)
    root_markers = {
        "audiobook": ("hoerbuch", "horbuch"),
        "comedy": ("humor", "comedy", "komoedie", "komodie"),
        "folder": (),
    }
    markers = root_markers.get(category, ())
    roots = []
    for item in top_level:
        if not is_musicfolder_folder(item):
            continue
        normalized = normalize_musicfolder_name(musicfolder_display_name(item))
        if not markers or any(marker in normalized for marker in markers):
            roots.append(enrich_musicfolder_item(item, None))
    return roots


def walk_musicfolder_folders(root: dict[str, Any], max_depth: int, max_items: int) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    stack: list[tuple[dict[str, Any], int, str]] = [(root, 0, str(root.get("name", "")))]
    while stack and len(result) < max_items:
        current, depth, path = stack.pop()
        current = dict(current)
        current["path"] = path
        result.append(current)
        if depth >= max_depth:
            continue
        folder_id = current.get("id")
        if folder_id is None:
            continue
        for child in reversed(lms.musicfolder(folder_id, limit=500)):
            if not is_musicfolder_folder(child):
                continue
            child_name = str(child.get("name", "")).strip()
            child_path = f"{path}/{child_name}" if child_name else path
            stack.append((enrich_musicfolder_item(child, path), depth + 1, child_path))
    return result


def collect_musicfolder_track_urls(folder_id: str | int, max_depth: int = 8) -> list[str]:
    urls: list[str] = []
    stack: list[tuple[str | int, int]] = [(folder_id, 0)]
    while stack:
        current_id, depth = stack.pop()
        items = lms.musicfolder(current_id, limit=1000)
        child_folders = []
        for item in items:
            url = str(item.get("url", "")).strip()
            item_type = str(item.get("type", "")).casefold()
            if item_type == "track" and url:
                urls.append(url)
            elif is_musicfolder_folder(item) and item.get("id") is not None and depth < max_depth:
                child_folders.append(item.get("id"))
        for child_id in reversed(child_folders):
            stack.append((child_id, depth + 1))
    return urls


def is_musicfolder_folder(item: dict[str, Any]) -> bool:
    if str(item.get("type", "")).casefold() == "folder":
        return True
    return item.get("id") is not None and not str(item.get("url", "")).strip().casefold().endswith((".mp3", ".flac", ".m4a", ".ogg", ".wav"))


def enrich_musicfolder_item(item: dict[str, Any], parent_path: str | None) -> dict[str, Any]:
    enriched = dict(item)
    name = musicfolder_display_name(enriched)
    if name and not enriched.get("name"):
        enriched["name"] = name
    if parent_path and not enriched.get("path"):
        enriched["path"] = f"{parent_path}/{name}" if name else parent_path
    elif not enriched.get("path"):
        enriched["path"] = name
    return enriched


def musicfolder_match_score(query: str, item: dict[str, Any]) -> float:
    name = musicfolder_display_name(item)
    path = str(item.get("path", name))
    normalized_query = normalize_command_fingerprint(query)
    normalized_path = normalize_command_fingerprint(path)
    contains_bonus = 0.3 if normalized_query and normalized_query in normalized_path else 0.0
    return max(
        score_text(query, name),
        score_text(query, path),
        token_overlap_score(query, name),
        token_overlap_score(query, path),
    ) + contains_bonus


def musicfolder_display_name(item: dict[str, Any]) -> str:
    return str(item.get("name") or item.get("filename") or item.get("title") or "").strip()


def normalize_musicfolder_name(value: str) -> str:
    normalized = normalize_command_fingerprint(value)
    normalized = normalized.replace("[", " ").replace("]", " ")
    normalized = normalized.replace("oe", "o").replace("ue", "u").replace("ae", "a")
    normalized = normalized.replace("Ã¶", "o").replace("Ã¼", "u").replace("Ã¤", "a")
    return re.sub(r"\s+", " ", normalized).strip()


def music_folder_category_label(category: str) -> str:
    if category == "audiobook":
        return "Hoerbuch"
    if category == "comedy":
        return "Comedy oder Humor"
    return "Musikordner"


def handle_play_album_dialog(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    artist_query = parsed.get("artist")
    if not artist_query:
        return CommandResponse(status="error", message="Ich habe keinen Kuenstler erkannt.", room=player.room)
    try:
        inventory = library.artist_inventory(artist_query)
        artist_name = str(inventory["artist"])
        albums = inventory["albums"][:8]
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    if not albums:
        return CommandResponse(status="error", message=f"Ich habe keine Alben von {artist_query} gefunden.", room=player.room)
    if len(albums) == 1:
        logger.info(
            "Single album match selected directly: player=%s artist=%r album=%s",
            player.id,
            artist_name,
            album_option_label(albums[0]),
        )
        return play_selected_album(command, albums[0], player, {"artist": artist_name})
    if command.device:
        sessions.set(
            command.device,
            make_session(album_dialog_state(player.room, artist_name, albums)),
        )
        logger.info(
            "Album selection session started: device=%r room=%r artist=%r options=%s",
            command.device,
            player.room,
            artist_name,
            album_option_names(albums, artist_context=artist_name),
        )
    options = album_option_names(albums, artist_context=artist_name)
    return CommandResponse(
        status="clarify",
        message=f"Ich habe diese Alben gefunden: {', '.join(options)}. Welches soll ich spielen?",
        action="select_album",
        artist=artist_name,
        room=player.room,
        options=options,
        followup=True,
        followup_seconds=session_ttl_seconds(config),
    )


def handle_play_radio_dialog(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    remembered = last_radio_for_player(player)
    if remembered:
        logger.info(
            "Using last radio favorite: player=%s room=%s favorite_id=%s favorite=%r",
            player.id,
            player.room,
            remembered.get("id"),
            remembered.get("name"),
        )
        return play_selected_radio(command, remembered, player)

    try:
        favorites = flatten_favorites(lms.favorites())[:12]
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    if not favorites:
        return CommandResponse(status="error", message="Ich habe keine Radiofavoriten gefunden.", room=player.room)
    if len(favorites) == 1:
        logger.info(
            "Single radio favorite selected directly: player=%s favorite=%s",
            player.id,
            favorites[0].get("name"),
        )
        return play_selected_radio(command, favorites[0], player)
    if command.device:
        sessions.set(
            command.device,
            make_session(radio_dialog_state(player.room, favorites)),
        )
        logger.info(
            "Radio selection session started: device=%r room=%r options=%s",
            command.device,
            player.room,
            favorite_option_names(favorites),
        )
    options = favorite_option_names(favorites)
    return CommandResponse(
        status="clarify",
        message=f"Ich habe diese Radiosender gefunden: {', '.join(options)}. Welchen soll ich spielen?",
        action="select_radio",
        room=player.room,
        options=options,
    )


def handle_play_artist_playlist(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    artist_query = parsed.get("artist")
    if not artist_query:
        return CommandResponse(status="error", message="Ich habe keinen Kuenstler erkannt.", room=player.room)
    try:
        artist_match = library.find_artist(artist_query)
        if not artist_match:
            return CommandResponse(status="error", message=f"Ich habe keinen passenden Kuenstler zu {artist_query} gefunden.", room=player.room)
        artist = artist_match.item
        if not command.dry_run:
            responses = lms.play_artist(player.id, str(artist.get("id")), shuffle=True)
            logger.info("Artist playlist started: player=%s artist_id=%s responses=%s", player.id, artist.get("id"), responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)
    remember_command_room(command, player)
    return short_ok("play_artist_playlist", player.room, artist=str(artist.get("artist")), shuffle=True)


def handle_play_metadata_playlist(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    if not genre_metadata.configured:
        return CommandResponse(
            status="error",
            message="Die Genre-Metadatenquelle ist nicht aktiviert.",
            action="play_metadata_playlist",
            room=player.room,
        )

    selection = config.get("metadata_selection") or {}
    profiles = selection.get("profiles") or {}
    traits = [str(value) for value in parsed.get("metadata_traits") or []]
    filters: dict[str, Any] = {"selection": "random"}
    for trait in traits:
        profile = profiles.get(trait) or DEFAULT_METADATA_PROFILES.get(trait) or {}
        if not isinstance(profile, dict):
            continue
        for key, value in profile.items():
            if value is not None:
                filters[key] = value
    genres = [str(value).strip() for value in parsed.get("genres") or [] if str(value).strip()]
    if genres:
        filters["genres"] = genres
    if parsed.get("year_min") is not None:
        filters["year_min"] = int(parsed["year_min"])
    if parsed.get("year_max") is not None:
        filters["year_max"] = int(parsed["year_max"])

    try:
        result = genre_metadata.search_tracks(filters, retry_attempts=1)
    except Exception as exc:
        logger.warning("Genre metadata search failed: traits=%s filters=%s error=%s", traits, filters, exc)
        fallback = play_metadata_genre_fallback(command, player, genres, str(exc))
        if fallback is not None:
            return fallback
        return CommandResponse(
            status="error",
            message=f"Die Genre-Metadatensuche ist fehlgeschlagen: {exc}",
            action="play_metadata_playlist",
            room=player.room,
        )

    tracks = result.get("tracks") or []
    urls, fallback_paths = metadata_track_urls(tracks)

    if not urls:
        fallback = play_metadata_genre_fallback(
            command,
            player,
            genres,
            "Der Genre-Scanner hat keine abspielbaren Treffer geliefert.",
        )
        if fallback is not None:
            return fallback
        return CommandResponse(
            status="error",
            message="Ich habe keine passenden abspielbaren Titel gefunden.",
            action="play_metadata_playlist",
            room=player.room,
        )

    try:
        if not command.dry_run:
            responses = lms.play_urls(player.id, urls, shuffle=True)
            logger.info(
                "Metadata playlist started: player=%s traits=%s tracks=%s fallback_paths=%s responses=%s",
                player.id,
                traits,
                len(urls),
                fallback_paths,
                responses,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="play_metadata_playlist", room=player.room)

    remember_command_room(command, player)
    return short_ok(
        "play_metadata_playlist",
        player.room,
        shuffle=True,
        selection_source="genre_scanner",
        track_count=len(urls),
    )


def play_metadata_genre_fallback(
    command: CommandRequest,
    player,
    genres: list[str],
    reason: str,
) -> CommandResponse | None:
    """Fall back to an LMS genre when a combined mood/genre search fails."""
    for genre_query in genres:
        try:
            genre_match = library.find_genre(genre_query)
            if not genre_match:
                continue
            genre = genre_match.item
            if not command.dry_run:
                responses = lms.play_genre(player.id, str(genre.get("id")), shuffle=True)
                logger.info(
                    "Metadata playlist fallback to LMS genre: player=%s genre=%r reason=%s responses=%s",
                    player.id,
                    genre_query,
                    reason,
                    responses,
                )
            remember_command_room(command, player)
            return short_ok(
                "play_metadata_playlist",
                player.room,
                shuffle=True,
                genre=genre_query,
                selection_source="lms",
                fallback_reason=f"Mood-Filter nicht angewendet: {reason}",
            )
        except LmsError as exc:
            logger.warning("LMS genre fallback failed: genre=%r error=%s", genre_query, exc)
            return None
    return None


def metadata_track_urls(tracks: list[Any]) -> tuple[list[str], int]:
    urls: list[str] = []
    fallback_paths = 0
    for track in tracks:
        if not isinstance(track, dict):
            continue
        path = genre_metadata.playable_path(track)
        if path and not str(track.get("lms_path") or "").strip():
            fallback_paths += 1
        if path and path not in urls:
            urls.append(path)
    return urls, fallback_paths


def handle_play_genre_playlist(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    genre_query = parsed.get("genre")
    if not genre_query:
        return CommandResponse(status="error", message="Ich habe keine Stilrichtung erkannt.", room=player.room)
    selection = config.get("metadata_selection") or {}
    genre_source = str(selection.get("genre_source") or "lms").strip().casefold()
    fallback_reason: str | None = None
    if genre_source == "scanner_with_lms_fallback":
        if not genre_metadata.configured:
            fallback_reason = "Genre-Scanner ist nicht konfiguriert."
        else:
            try:
                result = genre_metadata.search_tracks(
                    {"selection": "random", "genres": [str(genre_query)]},
                    retry_attempts=1,
                )
                urls, fallback_paths = metadata_track_urls(result.get("tracks") or [])
                if urls:
                    if not command.dry_run:
                        responses = lms.play_urls(player.id, urls, shuffle=True)
                        logger.info(
                            "Genre playlist started from scanner: player=%s genre=%r tracks=%s fallback_paths=%s responses=%s",
                            player.id,
                            genre_query,
                            len(urls),
                            fallback_paths,
                            responses,
                        )
                    remember_command_room(command, player)
                    return short_ok(
                        "play_genre",
                        player.room,
                        shuffle=True,
                        genre=str(genre_query),
                        selection_source="genre_scanner",
                        track_count=len(urls),
                    )
                fallback_reason = "Der Genre-Scanner hat keine abspielbaren Treffer geliefert."
            except Exception as exc:
                fallback_reason = f"Genre-Scanner-Fehler: {exc}"
            logger.warning("Genre scanner fallback to LMS: genre=%r reason=%s", genre_query, fallback_reason)
    try:
        genre_match = library.find_genre(genre_query)
        if not genre_match:
            return CommandResponse(
                status="error",
                message=f"Ich habe keine passende Stilrichtung zu {genre_query} gefunden.",
                action="play_genre",
                room=player.room,
                genre=str(genre_query),
                selection_source="lms",
                fallback_reason=fallback_reason,
            )
        genre = genre_match.item
        if not command.dry_run:
            responses = lms.play_genre(player.id, str(genre.get("id")), shuffle=True)
            logger.info("Genre playlist started: player=%s genre_id=%s responses=%s", player.id, genre.get("id"), responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)
    remember_command_room(command, player)
    return short_ok(
        "play_genre",
        player.room,
        shuffle=True,
        genre=str(genre_query),
        selection_source="lms",
        fallback_reason=fallback_reason,
    )


def try_handle_radio_favorite_before_genre(command: CommandRequest, parsed: dict, player) -> CommandResponse | None:
    query = str(parsed.get("genre") or "").strip()
    if not query:
        return None
    try:
        favorite = find_radio_favorite(query)
    except LmsError:
        return None
    if not favorite:
        return None
    favorite_name = str(favorite.get("name", ""))
    score = max(score_text(query, favorite_name), token_overlap_score(query, favorite_name))
    query_tokens = set(significant_album_tokens(query))
    favorite_tokens = set(significant_album_tokens(favorite_name))
    token_subset = bool(query_tokens) and query_tokens.issubset(favorite_tokens)
    overlap = len(query_tokens & favorite_tokens) / max(1, len(query_tokens))
    name_contains_query = query.casefold() in favorite_name.casefold()
    lowered_query = query.casefold()
    single_generic_token = len(query_tokens) == 1 and not any(marker in lowered_query for marker in ("radio", "sender", "internetradio"))
    if single_generic_token:
        logger.info("Radio favorite precheck ignored for generic single token before genre: query=%r favorite=%r score=%.3f", query, favorite_name, score)
        return None
    if score < 0.82 and not token_subset and not name_contains_query and overlap < 0.66:
        logger.info("Radio favorite precheck ignored before genre: query=%r favorite=%r score=%.3f", query, favorite_name, score)
        return None
    logger.info("Radio favorite matched before genre fallback: query=%r favorite=%r score=%.3f", query, favorite_name, score)
    return play_selected_radio(command, favorite, player)


def handle_play_current_album(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    try:
        status = lms.status(player.id)
        album_id, album_name, artist_name, title_name = current_album_details_from_status(status)
        if not album_id and album_name:
            albums = library.find_albums_by_title(album_name, limit=5)
            if artist_name:
                albums.sort(
                    key=lambda album: max(
                        score_text(artist_name, str(album.get("artist", ""))),
                        score_text(artist_name, str(album.get("albumartist", ""))),
                    ),
                    reverse=True,
                )
            if albums:
                selected = albums[0]
                album_id = selected.get("id")
                album_name = str(selected.get("album", album_name))
                artist_name = str(selected.get("artist", artist_name) or selected.get("albumartist", artist_name))
        if not album_id and title_name:
            titles = library.find_titles_by_title(title_name, artist_query=artist_name or None, limit=5)
            if titles:
                selected_title = titles[0]
                album_id = selected_title.get("album_id") or selected_title.get("albumid")
                album_name = str(selected_title.get("album", album_name)).strip()
                artist_name = str(
                    selected_title.get("artist", artist_name) or selected_title.get("albumartist", artist_name)
                ).strip()
                if not album_id and album_name:
                    albums = library.find_albums_by_title(album_name, limit=5)
                    if artist_name:
                        albums.sort(
                            key=lambda album: max(
                                score_text(artist_name, str(album.get("artist", ""))),
                                score_text(artist_name, str(album.get("albumartist", ""))),
                            ),
                            reverse=True,
                        )
                    if albums:
                        selected_album = albums[0]
                        album_id = selected_album.get("id")
                        album_name = str(selected_album.get("album", album_name))
                        artist_name = str(
                            selected_album.get("artist", artist_name) or selected_album.get("albumartist", artist_name)
                        )
        if not album_id:
            logger.info(
                "Current album not found: player=%s status_keys=%s album=%r artist=%r title=%r playlist=%r",
                player.id,
                sorted(status.keys()),
                album_name,
                artist_name,
                title_name,
                status.get("playlist_loop"),
            )
            return CommandResponse(status="error", message="Ich finde zum laufenden Titel kein Album.", room=player.room)
        if not command.dry_run:
            responses = lms.play_album(player.id, str(album_id))
            logger.info("Current album playback started: player=%s album_id=%s responses=%s", player.id, album_id, responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(status="error", message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}", room=player.room)
    remember_command_room(command, player)
    artist_part = f" von {artist_name}" if artist_name else ""
    return CommandResponse(
        status="ok",
        message=f"Ich spiele jetzt {album_name or 'das Album'}{artist_part} {target_phrase(player)}.",
        action="play_current_album",
        artist=artist_name or None,
        album=album_name or None,
        room=player.room,
        shuffle=False,
    )


def handle_play_similar_short(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    response = handle_play_similar(command, parsed, player)
    if response.status == "ok":
        response.message = "Okay."
    return response


def handle_sync_players(command: CommandRequest, parsed: dict) -> CommandResponse:
    source = resolve_named_or_current_player(command, parsed.get("source_room"))
    if isinstance(source, CommandResponse):
        return source
    target = resolve_named_player(parsed.get("target_room"))
    if isinstance(target, CommandResponse):
        if command.device:
            sessions.set(command.device, make_session(target_dialog_state(parsed, prompt="Mit welchem Player soll ich synchronisieren?")))
        return CommandResponse(status="clarify", message="Mit welchem Player soll ich synchronisieren?", action="select_room", options=players.known_rooms())
    try:
        if not command.dry_run:
            response = lms.sync_players(source.id, target.id)
            logger.info("Players synchronized: source=%s target=%s response=%s", source.id, target.id, response)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="sync_players", room=target.room)
    remember_command_room(command, target)
    return short_ok("sync_players", target.room)


def handle_unsync_all(command: CommandRequest) -> CommandResponse:
    try:
        if not command.dry_run:
            responses = lms.unsync_all()
            logger.info("All LMS synchronizations cancelled: responses=%s", responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="unsync_all")
    return short_ok("unsync_all")


def handle_unsync_players(command: CommandRequest, parsed: dict) -> CommandResponse:
    source = resolve_named_player(parsed.get("source_room"))
    if isinstance(source, CommandResponse):
        return source
    target = resolve_named_player(parsed.get("target_room"))
    if isinstance(target, CommandResponse):
        return target
    try:
        if not command.dry_run:
            responses = [lms.unsync_player(source.id), lms.unsync_player(target.id)]
            logger.info(
                "LMS synchronization cancelled between players: source=%s target=%s responses=%s",
                source.id,
                target.id,
                responses,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="unsync_players")
    return short_ok("unsync_players")


def handle_continue_playback(command: CommandRequest, parsed: dict) -> CommandResponse:
    source = resolve_named_or_current_player(command, parsed.get("source_room"))
    if isinstance(source, CommandResponse):
        return source
    target = resolve_named_player(parsed.get("target_room") or parsed.get("room"))
    if isinstance(target, CommandResponse):
        if command.device:
            sessions.set(command.device, make_session(target_dialog_state(parsed, prompt="In welchem Player soll ich die Wiedergabe fortsetzen?")))
        return CommandResponse(status="clarify", message="In welchem Player soll ich die Wiedergabe fortsetzen?", action="select_room", options=players.known_rooms())
    parsed_transfer = {"source_room": source.room, "target_room": target.room, "room": target.room, "action": "continue_playback"}
    result = handle_transfer_playback(command, parsed_transfer)
    if result.status == "ok":
        result.message = "Okay."
        result.action = "continue_playback"
    return result


def resolve_named_player(room: str | None):
    if not room:
        return CommandResponse(status="clarify", message="Auf welchem Player?", action="select_room", options=players.known_rooms())
    try:
        player = get_player(room)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=room)
    if not player or not player.id:
        return CommandResponse(status="error", message=f"Ich kenne das Ziel {room} nicht.", room=room)
    return player


def resolve_named_or_current_player(command: CommandRequest, room: str | None):
    if room:
        return resolve_named_player(room)
    context = device_contexts.get(command.device, user=command.user, source=command.source)
    if context and context.last_room:
        return resolve_named_player(context.last_room)
    try:
        playing = currently_playing_configured_players()
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc))
    if len(playing) == 1:
        return playing[0]
    return CommandResponse(status="clarify", message="Von welchem Player soll ich ausgehen?", action="select_room", options=players.known_rooms())


def short_ok(action: str, room: str | None = None, **extra) -> CommandResponse:
    return CommandResponse(status="ok", message="Okay.", action=action, room=room, **extra)


def cleanup_room_text(text: str) -> str | None:
    cleaned = re.sub(r"\b(?:im|in|auf|am|dem|den|das|die|bitte|player|raum)\b", " ", text.casefold())
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" .,!?:;")
    return cleaned or None


def is_gateway_prompt_echo(text: str) -> bool:
    cleaned = re.sub(r"\s+", " ", text.casefold()).strip(" .,!?:;")
    if not cleaned:
        return False
    prompt_patterns = (
        r"^ich habe (?:diese|von) .*(?:gefunden|abendessen)",
        r"^ich habe .*\b(?:alben|album|titel|radiosender|sender|eigent|eigen)\b.*\bgefunden\b",
        r"^ich habe .*\b(?:gefunden|eigent|eigen)\b",
        r"\bwelche(?:s|n)? soll ich spielen\b",
        r"\bwelches album soll ich spielen\b",
        r"\bwelchen radiosender soll ich spielen\b",
        r"\bauf welchem player\b",
        r"\bin welchem player\b",
        r"\bmit welchem player\b",
        r"\bzur auswahl stehen\b",
        r"\bich habe die auswahl nicht verstanden\b",
    )
    return any(re.search(pattern, cleaned) for pattern in prompt_patterns)


def is_dialog_cancel(text: str) -> bool:
    cleaned = re.sub(r"\s+", " ", text.casefold()).strip(" .,!?:;")
    if not cleaned:
        return False
    cancel_patterns = (
        r"\b(?:abbruch|abbrechen|bruch ab|dialog abbrechen)\b",
        r"\bdas war'?s\b",
        r"\bdas wars\b",
        r"\bes hat sich erledigt\b",
        r"\bhat sich erledigt\b",
        r"\bvergiss es\b",
        r"\bvergessen\b",
        r"\bdoch nicht\b",
        r"\blass es\b",
        r"\bende\b",
        r"\bstopp(?:e)? den dialog\b",
    )
    return any(re.search(pattern, cleaned) for pattern in cancel_patterns)


def handle_list_artist_albums(command: CommandRequest, parsed: dict) -> CommandResponse:
    artist_query = parsed.get("artist")
    if not artist_query:
        return CommandResponse(status="error", message="Ich habe keinen Kuenstler erkannt.", room=parsed.get("room"))

    try:
        inventory = library.artist_inventory(artist_query)
        artist_name = str(inventory["artist"])
        albums = inventory["albums"]
        include_sampler = parsed.get("include_sampler_titles", True)
        sampler_albums = inventory["sampler_albums"] if include_sampler else []
        sampler_titles = inventory["sampler_titles"] if include_sampler else []
        found_titles = inventory["titles"] if include_sampler else []
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=parsed.get("room"))

    if not albums and not sampler_albums and not sampler_titles and not found_titles:
        return CommandResponse(
            status="error",
            message=f"Ich habe keine Musik von {artist_query} gefunden.",
            artist=str(artist_query),
            room=parsed.get("room"),
        )

    options = albums[:8]
    if command.device and options:
        sessions.set(
            command.device,
            make_session(album_dialog_state(parsed.get("room"), artist_name, options)),
        )

    option_names = album_option_names(options, artist_context=artist_name)
    message_parts = []
    if option_names:
        message_parts.append(f"Ich habe von {artist_name} diese Alben gefunden: {', '.join(option_names)}.")
    if sampler_albums:
        message_parts.append(f"Ausserdem habe ich Titel in diesen Samplern oder Compilations gefunden: {', '.join(sampler_album_labels(sampler_albums[:6]))}.")
    if sampler_titles:
        message_parts.append(f"Ausserdem habe ich diese Titel in Samplern oder Compilations gefunden: {', '.join(sampler_title_labels(sampler_titles[:6]))}.")
    loose_titles = non_duplicate_titles(found_titles, sampler_titles)[:6]
    if loose_titles:
        message_parts.append(f"Ausserdem habe ich diese Einzeltitel gefunden: {', '.join(sampler_title_labels(loose_titles))}.")
    if option_names:
        message_parts.append("Welches Album soll ich spielen?")
    message = " ".join(message_parts)
    if not option_names:
        return CommandResponse(
            status="ok",
            message=message,
            action="list_artist_music",
            artist=artist_name,
            room=parsed.get("room"),
        )
    return CommandResponse(
        status="clarify",
        message=message,
        action="select_album",
        artist=artist_name,
        room=parsed.get("room"),
        options=option_names,
        followup=True,
        followup_seconds=session_ttl_seconds(config),
    )


def sampler_title_labels(titles: list[dict]) -> list[str]:
    labels = []
    seen = set()
    for title in titles:
        name = str(title.get("title", "")).strip()
        album = str(title.get("album", "")).strip()
        if not name:
            continue
        label = f"{name} auf {album}" if album else name
        if label in seen:
            continue
        labels.append(label)
        seen.add(label)
    return labels


def non_duplicate_titles(titles: list[dict], existing: list[dict]) -> list[dict]:
    existing_keys = {
        (
            normalize_command_fingerprint(str(title.get("title", ""))),
            normalize_command_fingerprint(str(title.get("album", ""))),
        )
        for title in existing
    }
    unique = []
    seen = set(existing_keys)
    for title in titles:
        key = (
            normalize_command_fingerprint(str(title.get("title", ""))),
            normalize_command_fingerprint(str(title.get("album", ""))),
        )
        if not key[0] or key in seen:
            continue
        unique.append(title)
        seen.add(key)
    return unique


def sampler_album_labels(albums: list[dict]) -> list[str]:
    labels = []
    seen = set()
    for album in albums:
        name = str(album.get("album", "")).strip()
        if not name or name in seen:
            continue
        labels.append(name)
        seen.add(name)
    return labels


def handle_play_artist(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    artist_query = parsed.get("artist")
    if not artist_query:
        return CommandResponse(status="error", message="Ich habe keinen Kuenstler erkannt.", room=player.room)

    try:
        artist_match = library.find_artist(artist_query)
        if not artist_match:
            return CommandResponse(
                status="error",
                message=f"Ich habe keinen passenden Kuenstler zu {artist_query} gefunden.",
                room=player.room,
            )
        artist = artist_match.item
        if not command.dry_run:
            shuffle = bool(parsed.get("shuffle", True))
            responses = lms.play_artist(player.id, str(artist.get("id")), shuffle=shuffle)
            logger.info(
                "Artist playback started: player=%s artist_id=%s shuffle=%s responses=%s",
                player.id,
                artist.get("id"),
                shuffle,
                responses,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            room=player.room,
        )

    artist_name = str(artist.get("artist"))
    shuffle = bool(parsed.get("shuffle", True))
    order = " in zufaelliger Reihenfolge" if shuffle else ""
    return CommandResponse(
        status="ok",
        message=f"Ich spiele Musik von {artist_name}{order} {target_phrase(player)}.",
        action="play_artist",
        artist=artist_name,
        room=player.room,
        shuffle=shuffle,
    )


def handle_play_genre(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    genre_query = parsed.get("genre")
    if not genre_query:
        return CommandResponse(status="error", message="Ich habe keine Stilrichtung erkannt.", room=player.room)

    try:
        genre_match = library.find_genre(genre_query)
        if not genre_match:
            return handle_ambiguous_music_query(command, genre_query, player)
        genre = genre_match.item
        if not command.dry_run:
            shuffle = bool(parsed.get("shuffle", True))
            responses = lms.play_genre(player.id, str(genre.get("id")), shuffle=shuffle)
            logger.info(
                "Genre playback started: player=%s genre_id=%s shuffle=%s responses=%s",
                player.id,
                genre.get("id"),
                shuffle,
                responses,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            room=player.room,
        )

    genre_name = str(genre.get("genre"))
    shuffle = bool(parsed.get("shuffle", True))
    order = " in zufaelliger Reihenfolge" if shuffle else ""
    return CommandResponse(
        status="ok",
        message=f"Ich spiele Musik der Stilrichtung {genre_name}{order} {target_phrase(player)}.",
        action="play_genre",
        room=player.room,
        shuffle=shuffle,
    )


def handle_ambiguous_music_query(command: CommandRequest, query: str, player) -> CommandResponse:
    try:
        title_albums = library.find_albums_by_title(query, limit=4)
        inventory = library.artist_inventory(query)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)

    artist_name = str(inventory.get("artist") or query)
    artist_albums = list(inventory.get("albums") or [])[:4]
    sampler_albums = list(inventory.get("sampler_albums") or [])[:4]
    sampler_titles = list(inventory.get("sampler_titles") or [])[:4]
    playable_albums = unique_album_options([*title_albums, *artist_albums])[:8]

    message_parts = []
    if title_albums:
        message_parts.append(f"Als Albumtitel habe ich gefunden: {', '.join(album_option_names(title_albums))}.")
    if artist_albums:
        message_parts.append(f"Als Interpret habe ich {artist_name} gefunden. Alben: {', '.join(album_option_names(artist_albums, artist_context=artist_name))}.")
    if sampler_albums:
        message_parts.append(f"Ausserdem habe ich passende Titel in diesen Samplern oder Compilations gefunden: {', '.join(sampler_album_labels(sampler_albums))}.")
    if sampler_titles:
        message_parts.append(f"Ausserdem habe ich diese passenden Titel in Samplern oder Compilations gefunden: {', '.join(sampler_title_labels(sampler_titles))}.")

    if playable_albums and command.device:
        album_session = make_session(album_dialog_state(player.room, artist_name, playable_albums))
        album_session.data["ambiguous_query"] = query
        sessions.set(command.device, album_session)

    if playable_albums:
        option_names = album_option_names(playable_albums)
        message_parts.append("Welches Album soll ich spielen?")
        return CommandResponse(
            status="clarify",
            message=" ".join(message_parts),
            action="select_album",
            room=player.room,
            options=option_names,
            followup=True,
            followup_seconds=session_ttl_seconds(config),
        )

    if message_parts:
        return CommandResponse(
            status="ok",
            message=" ".join(message_parts),
            action="ambiguous_music_lookup",
            room=player.room,
        )

    return CommandResponse(
        status="error",
        message=f"Ich habe keine passende Stilrichtung, kein Album und keinen Interpreten zu {query} gefunden.",
        room=player.room,
    )


def unique_album_options(albums: list[dict]) -> list[dict]:
    unique = []
    seen = set()
    for album in albums:
        key = (
            str(album.get("id", "")),
            normalize_command_fingerprint(str(album.get("album", ""))),
            normalize_command_fingerprint(str(album.get("artist", "") or album.get("albumartist", ""))),
        )
        if key in seen:
            continue
        unique.append(album)
        seen.add(key)
    return unique


def handle_play_radio(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    radio_query = parsed.get("radio")
    if not radio_query:
        return CommandResponse(status="error", message="Ich habe keinen Radiosender erkannt.", room=player.room)

    try:
        favorite = find_radio_favorite(radio_query)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)

    if not favorite:
        return CommandResponse(
            status="error",
            message=f"Ich habe keinen Radiofavoriten zu {radio_query} gefunden.",
            room=player.room,
        )

    favorite_id = favorite.get("id")
    if favorite_id is None:
        return CommandResponse(
            status="error",
            message=f"LMS hat fuer {favorite.get('name', radio_query)} keine Favoriten-ID geliefert.",
            room=player.room,
        )

    try:
        if not command.dry_run:
            responses = lms.play_favorite(player.id, str(favorite_id))
            logger.info("Radio favorite playback started: player=%s favorite_id=%s responses=%s", player.id, favorite_id, responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            room=player.room,
        )

    radio_name = str(favorite.get("name", radio_query))
    radio_label = radio_name if radio_name.casefold().startswith("radio ") else f"Radio {radio_name}"
    remember_command_room(command, player)
    return CommandResponse(
        status="ok",
        message=f"Ich spiele {radio_label} {target_phrase(player)}.",
        action="play_radio",
        room=player.room,
        shuffle=False,
    )


def handle_play_similar(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    try:
        status = lms.status(player.id)
        genre_query = current_genre_from_status(status)
        if not genre_query:
            return CommandResponse(
                status="error",
                message=f"Ich finde zum aktuellen Titel {target_phrase(player)} keine Stilrichtung.",
                action="play_similar",
                room=player.room,
            )
        genre_match = library.find_genre(genre_query)
        if not genre_match:
            return CommandResponse(
                status="error",
                message=f"Ich habe keine passende Stilrichtung zu {genre_query} gefunden.",
                action="play_similar",
                room=player.room,
            )
        genre = genre_match.item
        if not command.dry_run:
            responses = lms.play_genre(player.id, str(genre.get("id")), shuffle=True)
            logger.info(
                "Similar music playback started: player=%s genre=%s genre_id=%s responses=%s",
                player.id,
                genre_query,
                genre.get("id"),
                responses,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="play_similar", room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            action="play_similar",
            room=player.room,
        )

    genre_name = str(genre.get("genre", genre_query))
    remember_command_room(command, player)
    return CommandResponse(
        status="ok",
        message=f"Ich spiele aehnliche Musik der Stilrichtung {genre_name} {target_phrase(player)}.",
        action="play_similar",
        room=player.room,
        shuffle=True,
    )


def handle_transfer_playback(command: CommandRequest, parsed: dict) -> CommandResponse:
    source_name = parsed.get("source_room")
    target_name = parsed.get("target_room")
    if not source_name or not target_name:
        return CommandResponse(
            status="clarify",
            message="Von welchem Player auf welchen Player soll ich die Wiedergabe fortsetzen?",
            action="transfer_playback",
            options=players.known_rooms(),
        )

    try:
        source = get_player(source_name)
        target = get_player(target_name)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="transfer_playback")

    if not source or not source.id:
        return CommandResponse(
            status="error",
            message=f"Ich kenne den Quellplayer {source_name} nicht oder er ist nicht verbunden.",
            action="transfer_playback",
            room=source_name,
        )
    if not target or not target.id:
        return CommandResponse(
            status="error",
            message=f"Ich kenne den Zielplayer {target_name} nicht oder er ist nicht verbunden.",
            action="transfer_playback",
            room=target_name,
        )
    if source.id == target.id:
        return CommandResponse(
            status="error",
            message="Quelle und Ziel sind derselbe Player.",
            action="transfer_playback",
            room=target.room,
        )

    try:
        result = {"track_count": 0}
        if not command.dry_run:
            result = lms.transfer_playback(source.id, target.id)
            logger.info(
                "Playback transferred: source=%s target=%s result=%s",
                source.id,
                target.id,
                result,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="transfer_playback", room=target.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            action="transfer_playback",
            room=target.room,
        )

    remember_command_room(command, target)
    count = result.get("track_count", 0)
    detail = f" mit {count} Titeln" if count else ""
    return CommandResponse(
        status="ok",
        message=f"Ich setze die Wiedergabe von {target_label(source)} auf {target_label(target)} fort{detail}.",
        action="transfer_playback",
        room=target.room,
    )


def current_genre_from_status(status: dict) -> str | None:
    direct_fields = [
        status.get("genre"),
        status.get("genres"),
        status.get("genre_name"),
        status.get("current_title", {}).get("genre") if isinstance(status.get("current_title"), dict) else None,
    ]
    for value in direct_fields:
        genre = normalize_status_genre(value)
        if genre:
            return genre

    playlist = status.get("playlist_loop")
    if isinstance(playlist, list) and playlist:
        for key in ("genre", "genres", "genre_name"):
            genre = normalize_status_genre(playlist[0].get(key))
            if genre:
                return genre
    return None


def current_album_details_from_status(status: dict) -> tuple[Any | None, str, str, str]:
    sources: list[dict] = [status]
    current_title = status.get("current_title")
    if isinstance(current_title, dict):
        sources.append(current_title)
    playlist = status.get("playlist_loop")
    if isinstance(playlist, list) and playlist:
        index = safe_int(status.get("playlist_cur_index"), 0)
        if 0 <= index < len(playlist) and isinstance(playlist[index], dict):
            sources.append(playlist[index])
        if isinstance(playlist[0], dict):
            sources.append(playlist[0])

    album_id = first_status_value(sources, "album_id", "albumid", "album_id_0", "albumid_0")
    album_name = str(first_status_value(sources, "album", "album_name") or "").strip()
    artist_name = str(first_status_value(sources, "artist", "albumartist", "contributor") or "").strip()
    title_name = str(first_status_value(sources, "title", "track", "song") or "").strip()
    return album_id, album_name, artist_name, title_name


def first_status_value(sources: list[dict], *keys: str) -> Any | None:
    for source in sources:
        for key in keys:
            value = source.get(key)
            if value not in (None, ""):
                return value
    return None


def normalize_status_genre(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, list):
        value = value[0] if value else None
    text = str(value or "").strip()
    if not text:
        return None
    return re.split(r"\s*[,;/]\s*", text)[0].strip() or None


def find_radio_favorite(query: str) -> dict | None:
    favorites = flatten_favorites(lms.favorites())
    if not favorites:
        return None
    ranked = sorted(
        favorites,
        key=lambda favorite: max(
            score_text(query, str(favorite.get("name", ""))),
            token_overlap_score(query, str(favorite.get("name", ""))),
        ),
        reverse=True,
    )
    best = ranked[0]
    score = max(
        score_text(query, str(best.get("name", ""))),
        token_overlap_score(query, str(best.get("name", ""))),
    )
    return best if score >= 0.45 else None


def flatten_favorites(items: list[dict]) -> list[dict]:
    favorites = []
    for item in items:
        if item.get("id") is not None and item.get("name"):
            favorites.append(item)
        children = item.get("items") or item.get("children") or []
        if isinstance(children, list):
            favorites.extend(flatten_favorites(children))
    return favorites


def try_handle_genre_fallback(command: CommandRequest, genre_query: str, player) -> CommandResponse | None:
    try:
        genre_match = library.find_genre(genre_query)
    except LmsError:
        return None
    if not genre_match:
        return None
    parsed = {
        "action": "play_genre",
        "genre": genre_query,
        "room": player.room,
        "shuffle": True,
    }
    return handle_play_genre(command, parsed, player)


def handle_play_album_title(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    album_query = parsed.get("album")
    if not album_query:
        return CommandResponse(status="error", message="Ich habe keinen Albumnamen erkannt.", room=player.room)

    try:
        albums = library.find_albums_by_title(album_query)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)

    if not albums:
        return CommandResponse(
            status="error",
            message=f"Ich habe kein Album mit dem Titel {album_query} gefunden.",
            album=str(album_query),
            room=player.room,
        )

    if len(albums) == 1:
        selected = albums[0]
        try:
            if not command.dry_run:
                responses = lms.play_album(player.id, str(selected["id"]))
                logger.info("Album title playback started: player=%s album_id=%s responses=%s", player.id, selected["id"], responses)
        except LmsError as exc:
            return CommandResponse(status="error", message=str(exc), room=player.room)
        except Exception as exc:
            return CommandResponse(
                status="error",
                message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
                room=player.room,
            )

        album_name = str(selected.get("album"))
        artist_name = str(selected.get("artist", ""))
        by_artist = f" von {artist_name}" if artist_name else ""
        return CommandResponse(
            status="ok",
            message=f"Ich spiele {album_name}{by_artist} {target_phrase(player)}.",
            action="play",
            artist=artist_name or None,
            album=album_name,
            room=player.room,
            shuffle=False,
        )

    if command.device:
        album_session = make_session(album_dialog_state(player.room, "", albums))
        album_session.data["album_query"] = album_query
        sessions.set(command.device, album_session)

    option_names = album_option_names(albums)
    return CommandResponse(
        status="clarify",
        message=f"Ich habe mehrere Alben mit diesem Titel gefunden: {', '.join(option_names)}. Welches soll ich spielen?",
        action="select_album",
        album=str(album_query),
        room=player.room,
        options=option_names,
        followup=True,
        followup_seconds=session_ttl_seconds(config),
    )


def handle_play_title(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    title_query = parsed.get("title")
    artist_query = parsed.get("artist")
    if not title_query:
        return CommandResponse(status="error", message="Ich habe keinen Titelnamen erkannt.", room=player.room)

    try:
        titles = library.find_titles_by_title(title_query, artist_query=artist_query)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)

    if not titles:
        artist_part = f" von {artist_query}" if artist_query else ""
        return CommandResponse(
            status="error",
            message=f"Ich habe keinen Titel {title_query}{artist_part} gefunden.",
            room=player.room,
        )

    if len(titles) > 1:
        options = title_option_names(titles)
        return CommandResponse(
            status="clarify",
            message=f"Ich habe mehrere passende Titel gefunden: {', '.join(options)}. Bitte nenne den Titel genauer.",
            action="select_title",
            room=player.room,
            options=options,
        )

    selected = titles[0]
    title_id = selected.get("id")
    if title_id is None:
        return CommandResponse(
            status="error",
            message=f"LMS hat fuer {selected.get('title', title_query)} keine Titel-ID geliefert.",
            room=player.room,
        )

    try:
        if not command.dry_run:
            responses = lms.play_title(player.id, str(title_id))
            logger.info("Title playback started: player=%s title_id=%s responses=%s", player.id, title_id, responses)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            room=player.room,
        )

    title_name = str(selected.get("title", title_query))
    artist_name = str(selected.get("artist", "") or selected.get("albumartist", "")).strip()
    artist_part = f" von {artist_name}" if artist_name else ""
    remember_command_room(command, player)
    return CommandResponse(
        status="ok",
        message=f"Ich spiele {title_name}{artist_part} {target_phrase(player)}.",
        action="play_title",
        artist=artist_name or None,
        room=player.room,
        shuffle=False,
    )


def title_option_names(titles: list[dict]) -> list[str]:
    names = []
    seen = set()
    for title in titles:
        title_name = str(title.get("title", "")).strip()
        if not title_name:
            continue
        artist = str(title.get("artist", "") or title.get("albumartist", "")).strip()
        album = str(title.get("album", "")).strip()
        label = title_name
        if artist:
            label += f" von {artist}"
        if album:
            label += f" auf {album}"
        if label not in seen:
            names.append(label)
            seen.add(label)
    return names


def find_album_for_artist_name_fallback(artist_query: str, preferred_album: str | None = None) -> dict | None:
    albums = library.albums_matching_artist_name(artist_query)
    if not albums:
        return None
    if preferred_album:
        albums.sort(
            key=lambda album: max(
                score_text(preferred_album, str(album.get("album", ""))),
                score_text(artist_query, str(album.get("artist", "") or album.get("albumartist", ""))),
            ),
            reverse=True,
        )
    return albums[0]


def album_option_names(options: list[dict], artist_context: str | None = None) -> list[str]:
    names = []
    seen = set()
    numbered = len(options) > 3
    for index, option in enumerate(options, start=1):
        album = str(option.get("album", "")).strip()
        if not album:
            continue
        artist = str(option.get("artist", "") or option.get("albumartist", "")).strip()
        if artist and not same_artist_for_list(artist, artist_context):
            label = f"{album} von {artist}"
        else:
            label = album
        if numbered:
            label = f"{index}. {label}"
        if label not in seen:
            names.append(label)
            seen.add(label)
    return names


def same_artist_for_list(artist: str, artist_context: str | None) -> bool:
    if not artist or not artist_context:
        return False
    return normalize_command_fingerprint(artist) == normalize_command_fingerprint(artist_context)


def favorite_option_names(options: list[dict]) -> list[str]:
    names = []
    seen = set()
    for option in options:
        name = str(option.get("name", "")).strip()
        if name and name not in seen:
            names.append(name)
            seen.add(name)
    return names


def folder_option_names(options: list[dict]) -> list[str]:
    names = []
    seen = set()
    numbered = len(options) > 3
    for index, option in enumerate(options, start=1):
        name = str(option.get("name", "")).strip()
        if not name:
            continue
        label = f"{index}. {name}" if numbered else name
        if label not in seen:
            names.append(label)
            seen.add(label)
    return names


def select_album_option(text: str, options: list[dict]) -> dict | None:
    cleaned = normalize_album_selection_text(text)
    index = selection_index(cleaned, len(options))
    if index is not None:
        return options[index]

    direct = select_by_contained_text(cleaned, options, album_selection_candidates)
    if direct:
        return direct

    number_words = {
        "letzte": len(options),
        "letztes": len(options),
        "letzten": len(options),
        "erste": 1,
        "erstes": 1,
        "ersten": 1,
        "eins": 1,
        "zweite": 2,
        "zweites": 2,
        "zweiten": 2,
        "zwei": 2,
        "dritte": 3,
        "drittes": 3,
        "dritten": 3,
        "drei": 3,
        "vierte": 4,
        "viertes": 4,
        "vierten": 4,
        "vier": 4,
        "fuenfte": 5,
        "fünfte": 5,
        "fuenftes": 5,
        "fünftes": 5,
        "fuenften": 5,
        "fünften": 5,
        "fuenf": 5,
        "fünf": 5,
        "sechste": 6,
        "sechstes": 6,
        "sechsten": 6,
        "sechs": 6,
        "siebte": 7,
        "siebtes": 7,
        "siebten": 7,
        "sieben": 7,
        "achte": 8,
        "achtes": 8,
        "achten": 8,
        "acht": 8,
        "neunte": 9,
        "neuntes": 9,
        "neunten": 9,
        "neun": 9,
        "zehnte": 10,
        "zehntes": 10,
        "zehnten": 10,
        "zehn": 10,
        "elfte": 11,
        "elftes": 11,
        "elften": 11,
        "elf": 11,
        "zwoelfte": 12,
        "zwölfte": 12,
        "zwoelftes": 12,
        "zwölftes": 12,
        "zwoelften": 12,
        "zwölften": 12,
        "zwoelf": 12,
        "zwölf": 12,
    }
    digit_match = re.search(r"\b(\d+)\b", cleaned)
    if digit_match:
        index = int(digit_match.group(1))
        if 1 <= index <= len(options):
            return options[index - 1]

    for word, index in number_words.items():
        if word in cleaned and 1 <= index <= len(options):
            return options[index - 1]

    ranked = sorted(
        options,
        key=lambda option: album_selection_score(cleaned, option),
        reverse=True,
    )
    if ranked and album_selection_score(cleaned, ranked[0]) >= 0.45:
        return ranked[0]
    return None


def select_named_option(text: str, options: list[dict], field: str) -> dict | None:
    cleaned = normalize_album_selection_text(text)
    index = selection_index(cleaned, len(options))
    if index is not None:
        return options[index]

    direct = select_by_contained_text(
        cleaned,
        options,
        lambda option: [str(option.get(field, ""))],
    )
    if direct:
        return direct

    ranked = sorted(
        options,
        key=lambda option: max(
            score_text(cleaned, str(option.get(field, ""))),
            token_overlap_score(cleaned, str(option.get(field, ""))),
        ),
        reverse=True,
    )
    if not ranked:
        return None
    best_score = max(
        score_text(cleaned, str(ranked[0].get(field, ""))),
        token_overlap_score(cleaned, str(ranked[0].get(field, ""))),
    )
    return ranked[0] if best_score >= 0.45 else None


def normalize_album_selection_text(text: str) -> str:
    cleaned = text.casefold().strip()
    cleaned = re.sub(r"^\s*(?:spiel|spiele)\s+bitte\s+", "", cleaned)
    cleaned = re.sub(r"^\s*(?:spiel|spiele|nimm|waehle|wähle)\s+", "", cleaned)
    cleaned = re.sub(r"^\s*bitte\s+", "", cleaned)
    cleaned = re.sub(r"^\s*(?:das|die|den)\s+", "", cleaned)
    cleaned = re.sub(r"^\s*(?:ein|eine|einen)\s+", "", cleaned)
    cleaned = re.sub(r"^\s*(?:album|platte)\s+", "", cleaned)
    cleaned = re.sub(r"^\s*(?:ein|eine|einen)\s+", "", cleaned)
    cleaned = re.sub(r"^\s*(?:album|platte)\s+", "", cleaned)
    cleaned = re.sub(r"\s+(?:bitte)$", "", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned


def selection_index(cleaned: str, option_count: int) -> int | None:
    return explicit_selection_index(cleaned, option_count)

def select_by_contained_text(cleaned: str, options: list[dict], candidate_getter) -> dict | None:
    query = cleanup_selection_query(cleaned)
    if not query:
        return None

    query_tokens = significant_album_tokens(query)
    matches: list[tuple[int, dict]] = []
    for option in options:
        best_rank = 0
        for candidate in candidate_getter(option):
            normalized = cleanup_selection_query(candidate)
            if not normalized:
                continue
            candidate_tokens = significant_album_tokens(normalized)
            if query == normalized:
                best_rank = max(best_rank, 4)
            elif query in normalized:
                best_rank = max(best_rank, 3)
            elif query_tokens and query_tokens <= candidate_tokens:
                best_rank = max(best_rank, 2)
        if best_rank:
            matches.append((best_rank, option))

    if not matches:
        return None
    matches.sort(key=lambda item: item[0], reverse=True)
    if len(matches) == 1 or matches[0][0] > matches[1][0]:
        return matches[0][1]
    return None


def album_selection_candidates(option: dict) -> list[str]:
    return [
        str(option.get("album", "")),
        str(option.get("artist", "") or option.get("albumartist", "")),
        album_option_label(option),
    ]


def cleanup_selection_query(value: str) -> str:
    cleaned = value.casefold()
    cleaned = re.sub(r"[^a-z0-9Ã¤Ã¶Ã¼ÃŸäöüß]+", " ", cleaned)
    filler = {
        "spiel",
        "spiele",
        "nimm",
        "nehme",
        "waehle",
        "wähle",
        "album",
        "platte",
        "radio",
        "sender",
        "radiosender",
        "internetradio",
        "auswahl",
        "vorschlag",
        "position",
        "nummer",
        "nr",
        "bitte",
        "das",
        "die",
        "den",
        "der",
    }
    tokens = [token for token in cleaned.split() if token not in filler]
    return " ".join(tokens)


def is_new_primary_command(text: str, parsed: dict) -> bool:
    action = parsed.get("action")
    if action in {
        "list_artist_albums",
        "play_artist",
        "play_artist_playlist",
        "play_album_dialog",
        "play_radio_dialog",
        "play_genre",
        "play_radio",
        "play_similar",
        "play_current_album",
        "unsync_all",
        "unsync_players",
        "sync_players",
        "continue_playback",
        "transfer_playback",
        "play_album_title",
        "play_title",
        "transport",
        "transport_jump",
        "shuffle",
        "volume",
    }:
        return True

    if action != "play_album":
        return False

    cleaned = normalize_album_selection_text(text)
    selection_starts = (
        "erste",
        "erstes",
        "ersten",
        "eins",
        "zweite",
        "zweites",
        "zweiten",
        "zwei",
        "dritte",
        "drittes",
        "dritten",
        "drei",
        "vierte",
        "vier",
        "fuenfte",
        "fünfte",
        "fuenf",
        "fünf",
        "nummer",
        "nr",
    )
    if re.search(r"\b\d+\b", cleaned):
        return False
    if cleaned.startswith(selection_starts):
        return False

    return bool(re.search(r"\b(?:spiele|spiel)\s+(?:ein\s+)?album\s+von\b", text.casefold()))


def is_explicit_new_primary_command(parsed: dict) -> bool:
    return parsed.get("action") in {
        "list_artist_albums",
        "play_album_dialog",
        "play_artist_playlist",
        "play_radio_dialog",
        "play_radio",
        "play_genre",
        "play_current_album",
        "play_similar",
        "unsync_all",
        "unsync_players",
        "sync_players",
        "continue_playback",
        "transport",
        "transport_jump",
        "shuffle",
        "volume",
    }


def is_explicit_session_replacing_command(parsed: dict) -> bool:
    return parsed.get("action") in {
        "list_artist_albums",
        "play_album_dialog",
        "play_artist_playlist",
        "play_radio_dialog",
        "play_radio",
        "play_current_album",
        "play_similar",
        "unsync_all",
        "unsync_players",
        "sync_players",
        "continue_playback",
        "transport",
        "transport_jump",
        "shuffle",
        "volume",
    }


def album_selection_score(query: str, option: dict) -> float:
    album = str(option.get("album", ""))
    label = album_option_label(option)
    query_tokens = significant_album_tokens(query)
    album_tokens = significant_album_tokens(album)
    has_album_token = bool(query_tokens and album_tokens and query_tokens & album_tokens)
    album_score = max(
        score_text(query, album),
        token_overlap_score(query, album),
    )
    if not has_album_token:
        return album_score
    return max(
        album_score,
        score_text(query, label),
        token_overlap_score(query, label),
    )


def token_overlap_score(query: str, candidate: str) -> float:
    query_tokens = significant_album_tokens(query)
    candidate_tokens = significant_album_tokens(candidate)
    if not query_tokens or not candidate_tokens:
        return 0.0
    overlap = query_tokens & candidate_tokens
    if not overlap:
        return 0.0
    query_coverage = len(overlap) / len(query_tokens)
    candidate_coverage = len(overlap) / len(candidate_tokens)
    return 0.75 * query_coverage + 0.25 * candidate_coverage


def significant_album_tokens(value: str) -> set[str]:
    normalized = re.sub(r"[^a-z0-9äöüß]+", " ", value.casefold())
    tokens = set(normalized.split())
    stop_words = {
        "album",
        "platte",
        "das",
        "die",
        "der",
        "den",
        "ein",
        "eine",
        "einen",
        "von",
        "vom",
        "im",
        "im",
        "the",
        "a",
        "an",
    }
    return {token for token in tokens if token and token not in stop_words}


def album_option_label(option: dict) -> str:
    album = str(option.get("album", "")).strip()
    artist = str(option.get("artist", "") or option.get("albumartist", "")).strip()
    return f"{album} von {artist}" if artist else album


def target_label(player) -> str:
    if getattr(player, "name", None):
        return player.name
    return player.room


def target_phrase(player) -> str:
    preposition = "auf" if getattr(player, "name", None) else "im"
    return f"{preposition} {target_label(player)}"


def clean_room(room: str | None) -> str | None:
    if room is None:
        return None
    room = room.strip()
    return room or None


def refresh_players_from_lms() -> list[dict[str, Any]]:
    lms_player_list = lms.players()
    players.refresh_from_lms(lms_player_list)
    logger.info(
        "LMS players refreshed: names=%s known_targets=%s",
        [player.get("name") or player.get("player_name") or player.get("playername") for player in lms_player_list],
        players.known_rooms(),
    )
    return lms_player_list


def should_refresh_rooms_for_text(command: CommandRequest) -> bool:
    if clean_room(command.room):
        return True
    return bool(re.search(r"\b(?:im|in|auf|am)\s+\w+", command.text.casefold()))


def get_player(room: str | None):
    player = players.get(room)
    if player and player.id:
        return player
    if room:
        refresh_players_from_lms()
        return players.get(room)
    return player


def remember_command_room(command: CommandRequest, player) -> None:
    device_contexts.remember_room(
        command.device,
        player.room,
        player_id=player.id,
        user=command.user,
        source=command.source,
    )


def resolve_transport_player(command: CommandRequest, parsed: dict):
    room = parsed.get("room") or clean_room(command.room)
    if room:
        try:
            player = get_player(room)
        except LmsError as exc:
            return CommandResponse(status="error", message=str(exc), action=parsed.get("action"), room=room)
        if player and player.id:
            return player
        return CommandResponse(
            status="error",
            message=f"Ich kenne das Ziel {room} nicht.",
            action=parsed.get("action"),
            room=room,
        )

    # A stop without an explicit target is local to the input device. This
    # keeps "Stille" from stopping a remote room controlled earlier.
    default_room = device_contexts.default_room(command.device, user=command.user, source=command.source)
    if parsed.get("transport_command") == "stop" and default_room:
        try:
            player = get_player(default_room)
        except LmsError:
            player = None
        if player and player.id:
            return player

    context = device_contexts.get(command.device, user=command.user, source=command.source)
    if context and context.last_room:
        try:
            player = get_player(context.last_room)
        except LmsError:
            player = None
        if player and player.id:
            return player

    if default_room:
        try:
            player = get_player(default_room)
        except LmsError:
            player = None
        if player and player.id:
            return player

    try:
        playing = currently_playing_configured_players()
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action=parsed.get("action"))

    if len(playing) == 1:
        return playing[0]

    if len(playing) > 1:
        rooms = ", ".join(target_label(player) for player in playing)
        return CommandResponse(
            status="clarify",
            message=f"Auf welchem Player? Es spielen gerade: {rooms}.",
            action=parsed.get("action"),
            options=[player.room for player in playing],
        )

    return CommandResponse(
        status="clarify",
        message="Auf welchem Player?",
        action=parsed.get("action"),
        options=players.known_rooms(),
    )


def currently_playing_configured_players():
    configured = []
    lms_player_list = lms.players()
    players.refresh_from_lms(lms_player_list)
    for lms_player in lms_player_list:
        if str(lms_player.get("isplaying", "0")) != "1":
            continue
        if str(lms_player.get("connected", "0")) == "0":
            continue
        player = players.get_by_id(str(lms_player.get("playerid", "")))
        if player:
            configured.append(player)
    return configured


def handle_transport_command(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    transport_command = parsed.get("transport_command")
    labels = {
        "next": "Nächster Titel",
        "previous": "Vorheriger Titel",
        "pause": "Pause",
        "play": "Weiter",
        "stop": "Stopp",
    }
    try:
        if not command.dry_run:
            if transport_command == "next":
                response = lms.next_track(player.id)
            elif transport_command == "previous":
                response = lms.previous_track(player.id)
            elif transport_command == "pause":
                response = lms.pause(player.id)
            elif transport_command == "play":
                response = lms.resume(player.id)
            elif transport_command == "stop":
                response = lms.stop(player.id)
            else:
                return CommandResponse(
                    status="error",
                    message="Diesen Steuerbefehl kenne ich noch nicht.",
                    action="transport",
                    room=player.room,
                )
            logger.info(
                "Transport requested: command=%s jump_count=%s player=%s response=%s",
                transport_command,
                parsed.get("jump_count"),
                player.id,
                response,
            )
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="transport", room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            action="transport",
            room=player.room,
        )

    remember_command_room(command, player)
    return CommandResponse(
        status="ok",
        message=f"{labels.get(transport_command, 'Erledigt')} {target_phrase(player)}.",
        action="transport",
        room=player.room,
    )


def handle_shuffle_command(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    enabled = bool(parsed.get("shuffle"))
    try:
        if not command.dry_run:
            response = lms.set_shuffle(player.id, enabled)
            logger.info("Shuffle set: player=%s enabled=%s response=%s", player.id, enabled, response)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            room=player.room,
        )

    state = "ein" if enabled else "aus"
    return CommandResponse(
        status="ok",
        message=f"Ich schalte Zufallswiedergabe {target_phrase(player)} {state}.",
        action="shuffle",
        room=player.room,
        shuffle=enabled,
    )


def handle_volume_command(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    mode = parsed.get("volume_mode")
    value = int(parsed.get("volume_value", 0))

    try:
        if not command.dry_run:
            if mode == "set":
                response = lms.set_volume(player.id, value)
                logger.info("Volume set: player=%s volume=%s response=%s", player.id, value, response)
            else:
                response = lms.change_volume(player.id, value)
                logger.info("Volume changed: player=%s delta=%s response=%s", player.id, value, response)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            room=player.room,
        )

    if mode == "set":
        return CommandResponse(
            status="ok",
            message=f"Ich stelle die Lautstaerke {target_phrase(player)} auf {value}.",
            action="volume",
            room=player.room,
            volume=value,
        )

    direction = "lauter" if value > 0 else "leiser"
    return CommandResponse(
        status="ok",
        message=f"Ich mache {target_phrase(player)} {direction}.",
        action="volume",
        room=player.room,
    )


def handle_transport_command(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    transport_command = parsed.get("transport_command")
    try:
        if not command.dry_run:
            if transport_command == "jump":
                response = lms.jump_tracks(player.id, int(parsed.get("jump_count", 1)))
            elif transport_command == "next":
                response = lms.jump_tracks(player.id, 1)
            elif transport_command == "previous":
                response = lms.jump_tracks(player.id, -1)
            elif transport_command == "pause":
                response = lms.pause(player.id)
            elif transport_command == "play":
                response = lms.resume(player.id)
            elif transport_command == "stop":
                response = lms.stop(player.id)
            else:
                return CommandResponse(
                    status="error",
                    message="Diesen Steuerbefehl kenne ich noch nicht.",
                    action=parsed.get("action", "transport"),
                    room=player.room,
                )
            logger.info("Transport requested: command=%s player=%s response=%s", transport_command, player.id, response)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action=parsed.get("action", "transport"), room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            action=parsed.get("action", "transport"),
            room=player.room,
        )

    remember_command_room(command, player)
    followup_seconds = control_followup_seconds(config)
    return CommandResponse(
        status="ok",
        message="Okay.",
        action=parsed.get("action", "transport"),
        room=player.room,
        followup=followup_seconds > 0,
        followup_seconds=followup_seconds or None,
    )


def handle_volume_command(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    mode = parsed.get("volume_mode")
    value = int(parsed.get("volume_value", 0))
    try:
        if not command.dry_run:
            if mode == "set":
                response = lms.set_volume(player.id, value)
                logger.info("Volume set: player=%s volume=%s response=%s", player.id, value, response)
            else:
                response = lms.change_volume(player.id, value)
                logger.info("Volume changed: player=%s delta=%s response=%s", player.id, value, response)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), action="volume", room=player.room)
    except Exception as exc:
        return CommandResponse(
            status="error",
            message=f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            action="volume",
            room=player.room,
        )

    remember_command_room(command, player)
    followup_seconds = control_followup_seconds(config)
    if mode == "set":
        return CommandResponse(
            status="ok",
            message=f"Ich stelle die Lautstaerke {target_phrase(player)} auf {value}.",
            action="volume",
            room=player.room,
            volume=value,
            followup=followup_seconds > 0,
            followup_seconds=followup_seconds or None,
        )

    direction = "lauter" if value > 0 else "leiser"
    return CommandResponse(
        status="ok",
        message=f"Ich mache {target_phrase(player)} {direction}.",
        action="volume",
        room=player.room,
        followup=followup_seconds > 0,
        followup_seconds=followup_seconds or None,
    )


def handle_play_radio(command: CommandRequest, parsed: dict, player) -> CommandResponse:
    radio_query = parsed.get("radio")
    if not radio_query:
        return handle_play_radio_dialog(command, parsed, player)
    try:
        favorite = find_radio_favorite(radio_query)
    except LmsError as exc:
        return CommandResponse(status="error", message=str(exc), room=player.room)
    if not favorite:
        return CommandResponse(status="error", message=f"Ich habe keinen Radiofavoriten zu {radio_query} gefunden.", room=player.room)
    return play_selected_radio(command, favorite, player)

