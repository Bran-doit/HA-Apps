from __future__ import annotations

import json
import ssl
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen


class GenreMetadataError(RuntimeError):
    pass


class GenreMetadataClient:
    """Read-only client for the optional Genre Scanner metadata API."""

    def __init__(self, config: dict[str, Any]) -> None:
        api = config.get("genre_metadata_api") or {}
        self.enabled = bool(api.get("enabled", False))
        self.base_url = str(api.get("base_url") or "").strip().rstrip("/")
        self.token = str(api.get("api_token") or "").strip()
        self.timeout = max(1.0, float(api.get("timeout_seconds", 10)))
        self.search_timeout = max(1.0, float(api.get("search_timeout_seconds", 12)))
        self.retry_attempts = max(1, min(10, int(api.get("retry_attempts", 3))))
        self.retry_delay_seconds = max(0.0, min(30.0, float(api.get("retry_delay_seconds", 1.5))))
        self.verify_tls = bool(api.get("verify_tls", True))
        self.default_result_limit = max(1, min(500, int(api.get("default_result_limit", 100))))
        mappings = api.get("path_mappings") or []
        self.path_mappings = [mapping for mapping in mappings if isinstance(mapping, dict)]

    @property
    def configured(self) -> bool:
        return self.enabled and bool(self.base_url)

    def health(self) -> dict[str, Any]:
        return self._request("GET", "/api/v1/health")

    def schema(self) -> dict[str, Any]:
        return self._request("GET", "/api/v1/schema")

    def stats(self) -> dict[str, Any]:
        return self._request("GET", "/api/v1/stats")

    def search_tracks(self, filters: dict[str, Any], retry_attempts: int | None = None) -> dict[str, Any]:
        payload = dict(filters)
        payload.setdefault("limit", self.default_result_limit)
        return self._request(
            "POST",
            "/api/v1/tracks/search",
            payload,
            retry_attempts=retry_attempts,
            timeout_seconds=self.search_timeout,
        )

    def playable_path(self, track: dict[str, Any]) -> str:
        lms_path = str(track.get("lms_path") or "").strip()
        if lms_path:
            return lms_path

        file_path = str(track.get("file_path") or "").strip()
        folded_path = file_path.casefold()
        for mapping in self.path_mappings:
            source = str(mapping.get("from") or "").strip()
            target = str(mapping.get("to") or "").strip()
            if source and target and folded_path.startswith(source.casefold()):
                return target + file_path[len(source) :]
        return file_path

    def connection_test(self) -> dict[str, Any]:
        if not self.enabled:
            return {"status": "disabled", "message": "Genre-Scanner-API ist deaktiviert."}
        if not self.base_url:
            raise GenreMetadataError("Keine Basis-URL fuer die Genre-Scanner-API konfiguriert.")
        health = self.health()
        schema = self.schema()
        return {
            "status": "ok",
            "base_url": self.base_url,
            "health": health,
            "schema": schema,
        }

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        retry_attempts: int | None = None,
        timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        if not self.configured:
            raise GenreMetadataError("Genre-Scanner-API ist nicht aktiviert oder nicht vollstaendig konfiguriert.")

        relative_path = path.lstrip("/")
        if self.base_url.casefold().endswith("/api/v1") and relative_path.casefold().startswith("api/v1/"):
            relative_path = relative_path[len("api/v1/") :]
        url = urljoin(f"{self.base_url}/", relative_path)
        headers = {"Accept": "application/json"}
        body = None
        if payload is not None:
            headers["Content-Type"] = "application/json; charset=utf-8"
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        request = Request(url, data=body, headers=headers, method=method)
        context = None
        if url.lower().startswith("https://") and not self.verify_tls:
            context = ssl._create_unverified_context()

        raw = ""
        last_error: Exception | None = None
        attempts = self.retry_attempts if retry_attempts is None else max(1, min(10, int(retry_attempts)))
        request_timeout = self.timeout if timeout_seconds is None else max(1.0, float(timeout_seconds))
        for attempt in range(1, attempts + 1):
            try:
                with urlopen(request, timeout=request_timeout, context=context) as response:
                    raw = response.read().decode("utf-8")
                last_error = None
                break
            except HTTPError as exc:
                detail = exc.read().decode("utf-8", errors="replace")
                raise GenreMetadataError(f"Genre-Scanner-API antwortet mit HTTP {exc.code}: {detail}") from exc
            except (URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt < attempts and self.retry_delay_seconds:
                    time.sleep(self.retry_delay_seconds)

        if last_error is not None:
            raise GenreMetadataError(
                f"Genre-Scanner-API ist nach {attempts} Versuchen nicht erreichbar: {last_error}"
            ) from last_error

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise GenreMetadataError("Genre-Scanner-API hat kein gueltiges JSON geliefert.") from exc
        if not isinstance(data, dict):
            raise GenreMetadataError("Genre-Scanner-API hat kein JSON-Objekt geliefert.")
        if data.get("status") == "error":
            error = data.get("error") or {}
            message = error.get("message") if isinstance(error, dict) else None
            raise GenreMetadataError(str(message or "Genre-Scanner-API meldet einen Fehler."))
        return data
