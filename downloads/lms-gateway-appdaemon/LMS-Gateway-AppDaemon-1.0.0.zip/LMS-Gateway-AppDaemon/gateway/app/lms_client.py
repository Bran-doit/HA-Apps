from __future__ import annotations

import json
import logging
import socket
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from itertools import count
from typing import Any


logger = logging.getLogger("lms_gateway.lms_client")


class LmsError(RuntimeError):
    pass


@dataclass(frozen=True)
class LmsConfig:
    host: str
    http_port: int = 9000
    cli_port: int = 9090
    timeout_seconds: int = 8

    @property
    def json_rpc_url(self) -> str:
        return f"http://{self.host}:{self.http_port}/jsonrpc.js"


class LmsClient:
    def __init__(self, config: dict):
        lms = config.get("lms", {})
        self.config = LmsConfig(
            host=str(lms.get("host", "127.0.0.1")),
            http_port=int(lms.get("http_port", 9000)),
            cli_port=int(lms.get("cli_port", 9090)),
            timeout_seconds=int(lms.get("timeout_seconds", 8)),
        )
        self._ids = count(1)

    def request(self, player_id: str, command: list[Any]) -> dict[str, Any]:
        payload = {
            "id": next(self._ids),
            "method": "slim.request",
            "params": [player_id, command],
        }
        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            self.config.json_rpc_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            logger.info("LMS JSON request: player=%r command=%s", player_id, command)
            with urllib.request.urlopen(
                request,
                timeout=self.config.timeout_seconds,
            ) as response:
                body = response.read().decode("utf-8")
        except urllib.error.URLError as exc:
            raise LmsError(f"LMS ist nicht erreichbar: {exc}") from exc

        try:
            result = json.loads(body)
        except json.JSONDecodeError as exc:
            raise LmsError(f"LMS hat keine gueltige JSON-Antwort geliefert: {body[:200]}") from exc

        if result.get("error"):
            raise LmsError(str(result["error"]))
        return result.get("result", {})

    def artists(self, search: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        command: list[Any] = ["artists", 0, limit, "tags:s"]
        if search:
            command.append(f"search:{search}")
        result = self.request("", command)
        return result.get("artists_loop", [])

    def albums_for_artist(self, artist_id: str, limit: int = 100) -> list[dict[str, Any]]:
        result = self.request(
            "",
            ["albums", 0, limit, f"artist_id:{artist_id}", "tags:alyj", "compilation:0"],
        )
        return result.get("albums_loop", [])

    def albums(self, search: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        command: list[Any] = ["albums", 0, limit, "tags:alyj", "compilation:0"]
        if search:
            command.append(f"search:{search}")
        result = self.request("", command)
        return result.get("albums_loop", [])

    def titles(self, search: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        command: list[Any] = ["titles", 0, limit, "tags:al"]
        if search:
            command.append(f"search:{search}")
        result = self.request("", command)
        return result.get("titles_loop", [])

    def titles_for_artist(self, artist_id: str, limit: int = 100) -> list[dict[str, Any]]:
        result = self.request(
            "",
            ["titles", 0, limit, f"artist_id:{artist_id}", "tags:al"],
        )
        return result.get("titles_loop", [])

    def genres(self, search: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        command: list[Any] = ["genres", 0, limit]
        if search:
            command.append(f"search:{search}")
        result = self.request("", command)
        return result.get("genres_loop", [])

    def favorites(self, limit: int = 200) -> list[dict[str, Any]]:
        result = self.request("", ["favorites", "items", 0, limit])
        return result.get("loop_loop", [])

    def status(self, player_id: str) -> dict[str, Any]:
        return self.request(player_id, ["status", "-", 1, "tags:aglediy"])

    def alarms(self, player_id: str, enabled_only: bool = False) -> dict[str, Any]:
        command: list[Any] = ["alarms", 0, 100, f"filter:{'enabled' if enabled_only else 'all'}"]
        return self.request(player_id, command)

    def alarm_sounds(self, player_id: str = "") -> list[dict[str, Any]]:
        result = self.request("", ["alarm", "playlists", 0, 200])
        sounds = (
            result.get("playlists_loop")
            or result.get("playlist_loop")
            or result.get("item_loop")
            or result.get("loop_loop")
            or []
        )
        return sounds if isinstance(sounds, list) else []

    def add_alarm(
        self,
        player_id: str,
        *,
        time_seconds: int,
        days: list[int],
        repeat: bool,
        volume: int | None = None,
        url: str | None = None,
        shuffle: bool | None = None,
    ) -> dict[str, Any]:
        command: list[Any] = [
            "alarm", "add", f"time:{time_seconds}", f"dow:{','.join(str(day) for day in days)}",
            "enabled:1", f"repeat:{1 if repeat else 0}",
        ]
        if volume is not None:
            command.append(f"volume:{max(0, min(100, int(volume)))}")
        if url:
            command.append(f"url:{url}")
        if shuffle is not None:
            command.append(f"shufflemode:{1 if shuffle else 0}")
        return self.request(player_id, command)

    def update_alarm(self, player_id: str, alarm_id: str, **values: Any) -> dict[str, Any]:
        command: list[Any] = ["alarm", "update", f"id:{alarm_id}"]
        command.extend(f"{key}:{value}" for key, value in values.items())
        return self.request(player_id, command)

    def delete_alarm(self, player_id: str, alarm_id: str) -> dict[str, Any]:
        return self.request(player_id, ["alarm", "delete", f"id:{alarm_id}"])

    def set_all_alarms_enabled(self, player_id: str, enabled: bool) -> dict[str, Any]:
        return self.request(player_id, ["alarm", "enableall" if enabled else "disableall"])

    def snooze_alarm(self, player_id: str, minutes: int | None = None) -> list[str]:
        responses = []
        if minutes is not None:
            responses.append(self.cli_command(player_id, ["playerpref", "alarmSnoozeSeconds", str(max(1, minutes) * 60)]))
        responses.append(self.cli_command(player_id, ["button", "snooze.single"]))
        return responses

    def stop_alarm(self, player_id: str) -> str:
        return self.cli_command(player_id, ["button", "power"])

    def playlist_status(self, player_id: str, limit: int = 500) -> dict[str, Any]:
        return self.request(player_id, ["status", "-", limit, "tags:u"])

    def musicfolder(self, folder_id: str | int | None = None, start: int = 0, limit: int = 500) -> list[dict[str, Any]]:
        command: list[Any] = ["musicfolder", start, limit, "tags:u"]
        if folder_id is not None:
            command.append(f"folder_id:{folder_id}")
        result = self.request("", command)
        return result.get("folder_loop", [])

    def cli_command(self, player_id: str, command: list[str]) -> str:
        line = self._cli_line(player_id, command)

        try:
            logger.info("LMS CLI request: player=%r command=%s", player_id, command)
            with socket.create_connection(
                (self.config.host, self.config.cli_port),
                timeout=self.config.timeout_seconds,
            ) as sock:
                sock.settimeout(self.config.timeout_seconds)
                sock.sendall(line.encode("utf-8"))
                response = sock.recv(8192).decode("utf-8", errors="replace").strip()
        except OSError as exc:
            raise LmsError(f"LMS CLI ist nicht erreichbar: {exc}") from exc

        if not response:
            raise LmsError("LMS CLI hat keine Antwort geliefert.")
        logger.info("LMS CLI response: %s", response)
        return response

    def cli_commands(self, player_id: str, commands: list[list[str]]) -> list[str]:
        """Run several CLI commands over one persistent LMS connection."""
        if not commands:
            return []

        responses: list[str] = []
        try:
            with socket.create_connection(
                (self.config.host, self.config.cli_port),
                timeout=self.config.timeout_seconds,
            ) as sock:
                sock.settimeout(self.config.timeout_seconds)
                stream = sock.makefile("rwb")
                for command in commands:
                    logger.info("LMS CLI batch request: player=%r command=%s", player_id, command)
                    stream.write(self._cli_line(player_id, command).encode("utf-8"))
                    stream.flush()
                    response = stream.readline().decode("utf-8", errors="replace").strip()
                    if not response:
                        raise LmsError("LMS CLI hat keine Antwort geliefert.")
                    logger.info("LMS CLI batch response: %s", response)
                    responses.append(response)
        except LmsError:
            raise
        except OSError as exc:
            raise LmsError(f"LMS CLI ist nicht erreichbar: {exc}") from exc
        return responses

    @staticmethod
    def _cli_line(player_id: str, command: list[str]) -> str:
        encoded_player = urllib.parse.quote(player_id, safe="")
        encoded_command = " ".join(urllib.parse.quote(part, safe="") for part in command)
        return f"{encoded_player} {encoded_command}\n"

    def set_shuffle(self, player_id: str, enabled: bool) -> str:
        return self.cli_command(player_id, ["playlist", "shuffle", "1" if enabled else "0"])

    def play_album(self, player_id: str, album_id: str) -> list[str]:
        responses = [
            self.set_shuffle(player_id, False),
            self.cli_command(player_id, ["playlistcontrol", "cmd:load", f"album_id:{album_id}"]),
            self.cli_command(player_id, ["play"]),
        ]
        return responses

    def play_artist(self, player_id: str, artist_id: str, shuffle: bool = True) -> list[str]:
        responses = [
            self.set_shuffle(player_id, shuffle),
            self.cli_command(player_id, ["playlistcontrol", "cmd:load", f"artist_id:{artist_id}"]),
            self.cli_command(player_id, ["play"]),
        ]
        return responses

    def play_genre(self, player_id: str, genre_id: str, shuffle: bool = True) -> list[str]:
        responses = [
            self.set_shuffle(player_id, shuffle),
            self.cli_command(player_id, ["playlistcontrol", "cmd:load", f"genre_id:{genre_id}"]),
            self.cli_command(player_id, ["play"]),
        ]
        return responses

    def play_title(self, player_id: str, title_id: str) -> list[str]:
        responses = [
            self.set_shuffle(player_id, False),
            self.cli_command(player_id, ["playlistcontrol", "cmd:load", f"track_id:{title_id}"]),
            self.cli_command(player_id, ["play"]),
        ]
        return responses

    def play_favorite(self, player_id: str, favorite_id: str) -> list[str]:
        responses = [
            self.set_shuffle(player_id, False),
            self.cli_command(player_id, ["favorites", "playlist", "play", f"item_id:{favorite_id}"]),
            self.cli_command(player_id, ["play"]),
        ]
        return responses

    def play_urls(self, player_id: str, urls: list[str], shuffle: bool = False) -> list[str]:
        if not urls:
            raise LmsError("Es wurden keine abspielbaren Dateien gefunden.")
        commands = [
            ["playlist", "shuffle", "1" if shuffle else "0"],
            ["playlist", "clear"],
            ["playlist", "play", urls[0]],
        ]
        for url in urls[1:]:
            commands.append(["playlist", "add", url])
        commands.append(["play"])
        return self.cli_commands(player_id, commands)

    def transfer_playback(self, source_player_id: str, target_player_id: str) -> dict[str, Any]:
        status = self.playlist_status(source_player_id)
        tracks = playlist_urls_from_status(status)
        if not tracks:
            raise LmsError("Auf dem Quellplayer ist keine uebertragbare Playlist vorhanden.")

        current_index = safe_int(status.get("playlist_cur_index"), 0)
        current_time = safe_float(status.get("time"), 0.0)

        responses = [
            self.cli_command(target_player_id, ["playlist", "clear"]),
            self.cli_command(target_player_id, ["playlist", "play", tracks[0]]),
        ]
        for url in tracks[1:]:
            responses.append(self.cli_command(target_player_id, ["playlist", "add", url]))

        if current_index > 0:
            responses.append(self.cli_command(target_player_id, ["playlist", "index", str(current_index)]))
        if current_time > 3:
            responses.append(self.cli_command(target_player_id, ["time", str(int(current_time))]))
        responses.append(self.cli_command(target_player_id, ["play"]))
        responses.append(self.stop(source_player_id))

        return {
            "responses": responses,
            "track_count": len(tracks),
            "current_index": current_index,
            "current_time": current_time,
        }

    def next_track(self, player_id: str) -> str:
        return self.cli_command(player_id, ["playlist", "index", "+1"])

    def previous_track(self, player_id: str) -> str:
        return self.cli_command(player_id, ["playlist", "index", "-1"])

    def jump_tracks(self, player_id: str, count: int) -> list[str]:
        step = "+1" if count >= 0 else "-1"
        steps = max(1, abs(int(count)))
        responses = []
        for _ in range(steps):
            responses.append(self.cli_command(player_id, ["playlist", "index", step]))
        return responses

    def pause(self, player_id: str) -> str:
        return self.cli_command(player_id, ["pause", "1"])

    def resume(self, player_id: str) -> str:
        return self.cli_command(player_id, ["play"])

    def stop(self, player_id: str) -> str:
        return self.cli_command(player_id, ["stop"])

    def sync_players(self, source_player_id: str, target_player_id: str) -> str:
        return self.cli_command(source_player_id, ["sync", target_player_id])

    def unsync_player(self, player_id: str) -> str:
        return self.cli_command(player_id, ["sync", "-"])

    def unsync_all(self) -> list[str]:
        responses = []
        for player in self.players():
            player_id = str(player.get("playerid", "")).strip()
            if player_id:
                responses.append(self.unsync_player(player_id))
        return responses

    def set_volume(self, player_id: str, volume: int) -> str:
        safe_volume = max(0, min(100, volume))
        return self.cli_command(player_id, ["mixer", "volume", str(safe_volume)])

    def change_volume(self, player_id: str, delta: int) -> str:
        sign = "+" if delta >= 0 else ""
        return self.cli_command(player_id, ["mixer", "volume", f"{sign}{delta}"])

    def players(self) -> list[dict[str, Any]]:
        result = self.request("", ["players", 0, 100])
        return result.get("players_loop", [])


def playlist_urls_from_status(status: dict[str, Any]) -> list[str]:
    playlist = status.get("playlist_loop")
    if not isinstance(playlist, list):
        return []
    urls = []
    for item in playlist:
        url = str(item.get("url", "")).strip()
        if url:
            urls.append(url)
    return urls


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default
