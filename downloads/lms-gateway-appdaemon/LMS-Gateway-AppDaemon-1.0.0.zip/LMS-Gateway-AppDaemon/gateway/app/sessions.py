from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone


@dataclass
class SessionState:
    room: str | None
    status: str
    options: list[dict] = field(default_factory=list)
    data: dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class SessionStore:
    def __init__(self, ttl_seconds: int = 180):
        self.ttl = timedelta(seconds=ttl_seconds)
        self._sessions: dict[str, SessionState] = {}
        self._latest: dict[str, SessionState] = {}

    def get(self, device: str | None) -> SessionState | None:
        if not device:
            return None
        session = self._sessions.get(device)
        if not session:
            return None
        if datetime.now(timezone.utc) - session.created_at > self.ttl:
            self._sessions.pop(device, None)
            return None
        return session

    def set(self, device: str, session: SessionState) -> None:
        session.created_at = datetime.now(timezone.utc)
        self._sessions[device] = session
        self._latest[session.status] = session

    def get_latest(self, status: str) -> SessionState | None:
        session = self._latest.get(status)
        if not session:
            return None
        if datetime.now(timezone.utc) - session.created_at > self.ttl:
            self._latest.pop(status, None)
            return None
        return session

    def clear(self, device: str | None) -> None:
        if device:
            self._sessions.pop(device, None)
