from __future__ import annotations

import json
import logging
import os
import sys
import time
import types
import importlib
from datetime import datetime
from pathlib import Path
from typing import Any

import appdaemon.plugins.hass.hassapi as hass

from . import lms_gateway_admin_ui

lms_gateway_admin_ui = importlib.reload(lms_gateway_admin_ui)
APPDAEMON_ADMIN_HTML = lms_gateway_admin_ui.ADMIN_HTML


APP_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = APP_DIR / "gateway"
CONFIG_PATH = APP_DIR / "config.yaml"
LOG_DIR = APP_DIR / "logs"
GATEWAY_LOG = LOG_DIR / "gateway.log"
STARTUP_ERROR_LOG = LOG_DIR / "startup_error.log"
HIDDEN_LOG_MARKERS = (
    "[aiohttp.access]",
    "API Call to lms_gateway_admin_logs",
    "POST /api/appdaemon/lms_gateway_admin_logs",
)
LMS_LOG_MARKERS = (
    "[lms_gateway.",
    "[lms_gateway]",
    "[app.main]",
    "[app.lms_client]",
)
APP_REVISION = "2026-09-30-command-history"


FEATURES: dict[str, dict[str, Any]] = {
    "play_artist_playlist": {"label": "Kuenstler-Playlist", "actions": {"play_artist_playlist", "play_artist"}},
    "play_album_dialog": {"label": "Albumdialog", "actions": {"play_album_dialog", "list_artist_albums"}},
    "play_album_title": {"label": "Album per Titel", "actions": {"play_album_title", "play_album"}},
    "play_title": {"label": "Einzeltitel", "actions": {"play_title"}},
    "play_radio": {"label": "Radio mit Name", "actions": {"play_radio"}},
    "play_radio_dialog": {"label": "Radioauswahl", "actions": {"play_radio_dialog"}},
    "play_genre": {"label": "Genre-Playlist", "actions": {"play_genre"}},
    "play_metadata_playlist": {"label": "Moods und Mood-/Genre-Kombinationen", "actions": {"play_metadata_playlist"}},
    "play_music_folder": {"label": "Musikordner", "actions": {"play_music_folder"}},
    "play_current_album": {"label": "Album zur laufenden Musik", "actions": {"play_current_album"}},
    "play_similar": {"label": "Aehnliche Musik", "actions": {"play_similar"}},
    "sync_players": {"label": "Player synchronisieren", "actions": {"sync_players"}},
    "unsync_all": {"label": "Synchronisierung komplett loesen", "actions": {"unsync_all"}},
    "unsync_players": {"label": "Synchronisierung gezielt loesen", "actions": {"unsync_players"}},
    "continue_playback": {"label": "Wiedergabe fortsetzen/uebertragen", "actions": {"continue_playback", "transfer_playback"}},
    "transport": {"label": "Transport: Play/Pause/Stop/Vor/Zurueck", "actions": {"transport", "transport_jump"}},
    "volume": {"label": "Lautstaerke", "actions": {"volume"}},
    "shuffle": {"label": "Zufallswiedergabe", "actions": {"shuffle"}},
    "alarms": {"label": "Wecker", "actions": {"alarm_create", "alarm_list", "alarm_snooze", "alarm_stop", "alarm_enable_all", "alarm_disable_all", "alarm_delete_next", "alarm_disable_next", "alarm_delete_all"}},
}

ACTION_TO_FEATURE: dict[str, str] = {
    action: feature_id
    for feature_id, data in FEATURES.items()
    for action in data["actions"]
}


def install_compat_modules() -> None:
    """Provide tiny FastAPI/Pydantic shims so the existing gateway core imports."""

    if "pydantic" not in sys.modules:
        pydantic = types.ModuleType("pydantic")

        class BaseModel:
            def __init__(self, **data: Any) -> None:
                for key, value in data.items():
                    setattr(self, key, value)

            def dict(self) -> dict[str, Any]:
                return dict(self.__dict__)

            def model_dump(self) -> dict[str, Any]:
                return dict(self.__dict__)

        def Field(default: Any = None, **_: Any) -> Any:
            return default

        pydantic.BaseModel = BaseModel
        pydantic.Field = Field
        sys.modules["pydantic"] = pydantic

    if "fastapi" not in sys.modules:
        fastapi = types.ModuleType("fastapi")

        class HTTPException(Exception):
            def __init__(self, status_code: int, detail: str | None = None) -> None:
                super().__init__(detail or f"HTTP {status_code}")
                self.status_code = status_code
                self.detail = detail

        class Request:
            headers: dict[str, str] = {}

        class FastAPI:
            def __init__(self, *_: Any, **__: Any) -> None:
                pass

            def get(self, *_: Any, **__: Any):
                return lambda func: func

            def post(self, *_: Any, **__: Any):
                return lambda func: func

            def put(self, *_: Any, **__: Any):
                return lambda func: func

            def patch(self, *_: Any, **__: Any):
                return lambda func: func

            def delete(self, *_: Any, **__: Any):
                return lambda func: func

        fastapi.FastAPI = FastAPI
        fastapi.HTTPException = HTTPException
        fastapi.Request = Request
        sys.modules["fastapi"] = fastapi

        responses = types.ModuleType("fastapi.responses")

        class HTMLResponse(str):
            pass

        responses.HTMLResponse = HTMLResponse
        sys.modules["fastapi.responses"] = responses


def response_to_dict(response: Any) -> dict[str, Any]:
    if hasattr(response, "model_dump"):
        data = response.model_dump()
    elif hasattr(response, "dict"):
        data = response.dict()
    elif hasattr(response, "__dict__"):
        data = dict(response.__dict__)
    else:
        data = {"status": "error", "message": str(response)}
    return {key: value for key, value in data.items() if value is not None}


class LmsGatewayApp(hass.Hass):
    def initialize(self) -> None:
        try:
            self._initialize()
        except Exception as exc:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            STARTUP_ERROR_LOG.write_text(
                f"{datetime.now().isoformat()} {type(exc).__name__}: {exc}\n",
                encoding="utf-8",
            )
            raise

    def _initialize(self) -> None:
        self.gateway = None
        self.last_command: dict[str, Any] | None = None
        self.last_successful_command: dict[str, Any] | None = None
        self.command_history: list[dict[str, Any]] = []
        self.endpoint_handle = None
        self.admin_route_handle = None
        self.admin_route_handles = []
        self.admin_endpoint_handles = []

        LOG_DIR.mkdir(parents=True, exist_ok=True)
        os.environ["LMS_GATEWAY_CONFIG"] = str(CONFIG_PATH)
        os.environ["LMS_GATEWAY_LOG_DIR"] = str(LOG_DIR)

        package_path = str(PACKAGE_DIR)
        sys.path = [path for path in sys.path if path != package_path]
        sys.path.insert(0, package_path)

        install_compat_modules()
        self._clear_gateway_modules()
        importlib.invalidate_caches()

        try:
            import app.main as gateway_main
        except Exception as exc:
            self.error(f"LMS Gateway konnte nicht geladen werden: {type(exc).__name__}: {exc}")
            raise

        self.gateway = gateway_main
        self._install_feature_guard()
        self.listen_event(self._event_command, "lms_gateway_command")
        self._register_http_endpoint()
        self._register_admin_endpoints()
        self.log(f"LMS Gateway AppDaemon-Port geladen ({APP_REVISION}).")

    def _clear_gateway_modules(self) -> None:
        for module_name in list(sys.modules):
            if module_name == "app" or module_name.startswith("app."):
                del sys.modules[module_name]

    def _install_feature_guard(self) -> None:
        if self.gateway is None:
            return
        if getattr(self.gateway, "_appdaemon_feature_guarded", False):
            return

        original_execute = self.gateway.execute_parsed_command
        owner = self

        def guarded_execute(command: Any, parsed: dict[str, Any]) -> Any:
            action = str(parsed.get("action") or "")
            feature_id = ACTION_TO_FEATURE.get(action)
            if feature_id and not owner._feature_enabled(feature_id):
                feature_label = FEATURES[feature_id]["label"]
                return owner.gateway.CommandResponse(
                    status="error",
                    message=f"Diese LMS-Funktion ist momentan deaktiviert: {feature_label}.",
                    action=action,
                    room=owner._clean_optional(parsed.get("room")) or owner._clean_optional(command.room),
                )
            return original_execute(command, parsed)

        self.gateway.execute_parsed_command = guarded_execute
        self.gateway._appdaemon_feature_guarded = True

    def _register_http_endpoint(self) -> None:
        try:
            self.endpoint_handle = self.register_endpoint(self._http_command, "lms_gateway_command")
            self.log("HTTP-Endpunkt registriert: /api/appdaemon/lms_gateway_command")
        except Exception as exc:
            self.warning(f"HTTP-Endpunkt konnte nicht registriert werden: {type(exc).__name__}: {exc}")

    def _register_admin_endpoints(self) -> None:
        for route_name in ("lms_gateway_admin", "lms_gateway_admin_current"):
            try:
                handle = self.register_route(self._admin_page, route_name)
                self.admin_route_handles.append(handle)
                if route_name == "lms_gateway_admin":
                    self.admin_route_handle = handle
            except Exception as exc:
                self.warning(f"Admin-Webseite {route_name} konnte nicht registriert werden: {type(exc).__name__}: {exc}")

        endpoints = {
            "lms_gateway_admin_status": self._admin_status,
            "lms_gateway_admin_commands": self._admin_commands,
            "lms_gateway_admin_config": self._admin_config,
            "lms_gateway_admin_genre_api": self._admin_genre_api,
            "lms_gateway_admin_players": self._admin_players,
            "lms_gateway_admin_alarms": self._admin_alarms,
            "lms_gateway_admin_logs": self._admin_logs,
            "lms_gateway_admin_features": self._admin_features,
        }
        for name, callback in endpoints.items():
            try:
                handle = self.register_endpoint(callback, name)
                self.admin_endpoint_handles.append(handle)
            except Exception as exc:
                self.warning(f"Admin-Endpunkt {name} konnte nicht registriert werden: {type(exc).__name__}: {exc}")
        self.log("Admin-Seite registriert: /app/lms_gateway_admin und /app/lms_gateway_admin_current")

    def _event_command(self, event_name: str, data: dict[str, Any], kwargs: dict[str, Any]) -> None:
        response = self._run_command(data or {})
        self.fire_event("lms_gateway_response", **response)

    def _http_command(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        data = args or {}
        if not isinstance(data, dict):
            data = {}
        response = self._run_command(data)
        return response, 200

    def _run_command(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self.gateway is None:
            return {"status": "error", "message": "LMS Gateway ist nicht geladen."}

        text = str(payload.get("text") or "").strip()
        if not text:
            return {"status": "error", "message": "Es wurde kein Befehlstext uebergeben."}

        command = self.gateway.CommandRequest(
            text=text,
            room=self._clean_optional(payload.get("room")),
            device=self._clean_optional(payload.get("device")),
            user=self._clean_optional(payload.get("user")),
            source=self._clean_optional(payload.get("source")),
            dry_run=bool(payload.get("dry_run", False)),
        )

        started = time.perf_counter()
        try:
            parsed = self._parse_command(command) or {}
        except Exception:
            parsed = {}

        try:
            disabled_response = self._disabled_feature_response(command)
            if disabled_response:
                self.log(f"LMS Gateway: {text!r} -> {disabled_response}")
                result = disabled_response
            else:
                response = self.gateway.lms_command(command)
                result = response_to_dict(response)
                self.log(f"LMS Gateway: {text!r} -> {result}")
        except Exception as exc:
            self.error(f"LMS Gateway Fehler: {type(exc).__name__}: {exc}")
            result = {
                "status": "error",
                "message": f"Unerwarteter Gateway-Fehler: {type(exc).__name__}: {exc}",
            }
        command_payload = self._last_command_payload(
            command,
            parsed,
            result,
            elapsed_ms=round((time.perf_counter() - started) * 1000, 1),
        )
        self.last_command = command_payload
        self.command_history = ([command_payload] + self.command_history)[:3]
        if result.get("status") == "ok" and not command.dry_run:
            self.last_successful_command = dict(command_payload)
        return result

    def _last_command_payload(
        self,
        command: Any,
        parsed: dict[str, Any],
        result: dict[str, Any],
        *,
        elapsed_ms: float,
    ) -> dict[str, Any]:
        room = self._clean_optional(result.get("room")) or self._clean_optional(parsed.get("room")) or self._clean_optional(command.room)
        player_config = (self._current_config().get("players") or {}).get(room or "", {})
        if not isinstance(player_config, dict):
            player_config = {}
        target_name = player_config.get("name") or player_config.get("lms_name") or room
        parameters = {
            key: value
            for key, value in parsed.items()
            if key not in {"action", "room"} and value not in (None, "", [], {})
        }
        for key in ("selection_source", "fallback_reason", "track_count", "genre"):
            value = result.get(key)
            if value not in (None, "", [], {}):
                parameters[key] = value
        return {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "text": command.text,
            "action": result.get("action") or parsed.get("action") or "unknown",
            "parameters": parameters,
            "room": room,
            "target_name": target_name,
            "target_player_id": player_config.get("id"),
            "input_device": self._clean_optional(command.device),
            "source": self._clean_optional(command.source),
            "dry_run": bool(command.dry_run),
            "status": result.get("status"),
            "message": result.get("message"),
            "elapsed_ms": elapsed_ms,
        }

    def _disabled_feature_response(self, command: Any) -> dict[str, Any] | None:
        try:
            parsed = self._parse_command(command)
        except Exception:
            return None

        action = str(parsed.get("action") or "")
        if not action:
            return None

        feature_id = ACTION_TO_FEATURE.get(action)
        if not feature_id:
            return None

        if self._feature_enabled(feature_id):
            return None

        feature_label = FEATURES[feature_id]["label"]
        return {
            "status": "error",
            "message": f"Diese LMS-Funktion ist momentan deaktiviert: {feature_label}.",
            "action": action,
            "feature": feature_id,
            "room": self._clean_optional(parsed.get("room")) or self._clean_optional(command.room),
        }

    def _parse_command(self, command: Any) -> dict[str, Any]:
        if self.gateway is None:
            return {}
        known_rooms: list[str] = []
        player_resolver = getattr(self.gateway, "players", None)
        if player_resolver is not None and hasattr(player_resolver, "known_names"):
            known_rooms = list(player_resolver.known_names())
        return self.gateway.parse_command(command.text, self._clean_optional(command.room), known_rooms) or {}

    def _feature_enabled(self, feature_id: str) -> bool:
        config = self._current_config()
        features = config.get("features") or {}
        value = features.get(feature_id, True)
        return bool(value)

    def _current_config(self) -> dict[str, Any]:
        if self.gateway is not None and hasattr(self.gateway, "config"):
            config = getattr(self.gateway, "config")
            if isinstance(config, dict):
                return config
        return self._load_config_file()

    def _load_config_file(self) -> dict[str, Any]:
        if self.gateway is not None and hasattr(self.gateway, "load_config"):
            return self.gateway.load_config()
        try:
            import yaml

            with CONFIG_PATH.open("r", encoding="utf-8") as file:
                return yaml.safe_load(file) or {}
        except Exception:
            return {}

    def _reload_gateway_config(self) -> None:
        if self.gateway is None:
            return
        new_config = self.gateway.load_config()
        if hasattr(self.gateway, "apply_config"):
            self.gateway.apply_config(new_config, save=False)

    async def _admin_page(self, request: Any, kwargs: dict[str, Any]) -> Any:
        from aiohttp import web

        return web.Response(text=APPDAEMON_ADMIN_HTML, content_type="text/html")

    def _admin_status(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        config = self._current_config()
        lms_status: dict[str, Any]
        players: list[dict[str, Any]] = []
        try:
            players = self.gateway.lms.players() if self.gateway is not None else []
            lms_status = {"status": "ok", "players": players}
        except Exception as exc:
            lms_status = {"status": "error", "message": str(exc), "players": []}

        genre_api_status = self._genre_api_status()

        return {
            "status": "ok",
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "config_path": str(CONFIG_PATH),
            "log_path": str(GATEWAY_LOG),
            "lms": lms_status,
            "lms_config": config.get("lms") or {},
            "genre_metadata_api": genre_api_status,
            "player_count": len(players),
            "rooms": sorted((config.get("players") or {}).keys()),
            "features": self._feature_payload(config),
            "last_command": self.last_command,
            "command_history": self.command_history,
        }, 200

    def _admin_commands(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        return {
            "status": "ok",
            "commands": self.command_history,
        }, 200

    def _genre_api_status(self) -> dict[str, Any]:
        config = self._current_config().get("genre_metadata_api") or {}
        public = {
            "enabled": bool(config.get("enabled", False)),
            "base_url": str(config.get("base_url") or ""),
        }
        if not public["enabled"]:
            return {**public, "status": "disabled", "message": "Genre-Scanner-API ist deaktiviert."}
        if self.gateway is None or not hasattr(self.gateway, "genre_metadata"):
            return {**public, "status": "error", "message": "API-Client ist nicht geladen."}
        try:
            health = self.gateway.genre_metadata.health()
            return {**public, "status": str(health.get("status") or "ok"), "health": health}
        except Exception as exc:
            return {**public, "status": "error", "message": str(exc)}

    def _admin_genre_api(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        if self.gateway is None or not hasattr(self.gateway, "genre_metadata"):
            return {"status": "error", "message": "Genre-Scanner-API-Client ist nicht geladen."}, 503
        try:
            result = self.gateway.genre_metadata.connection_test()
        except Exception as exc:
            return {"status": "error", "message": str(exc)}, 502
        if result.get("status") == "disabled":
            return result, 200
        features = (result.get("schema") or {}).get("features") or {}
        available = sorted(
            name for name, details in features.items()
            if isinstance(details, dict) and details.get("available", False)
        )
        return {
            "status": "ok",
            "message": f"Genre-Scanner-API erreichbar, {len(available)} Merkmale verfuegbar.",
            "base_url": result.get("base_url"),
            "health": result.get("health"),
            "schema": result.get("schema"),
            "available_features": available,
        }, 200

    def _admin_config(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        data = args or {}
        if "config_text" not in data and "config" not in data:
            config = self._load_config_file()
            return {
                "status": "ok",
                "path": str(CONFIG_PATH),
                "config": config,
                "config_text": CONFIG_PATH.read_text(encoding="utf-8"),
            }, 200

        try:
            import yaml

            if "config" in data:
                parsed = data.get("config") or {}
                if not isinstance(parsed, dict):
                    raise ValueError("Die Konfiguration muss ein Mapping/Objekt sein.")
                parsed.pop("gateway", None)
                parsed.pop("security", None)
                config_text = yaml.safe_dump(parsed, allow_unicode=True, sort_keys=False)
            else:
                config_text = str(data.get("config_text") or "")
                parsed = yaml.safe_load(config_text) or {}
            if not isinstance(parsed, dict):
                raise ValueError("Die YAML-Konfiguration muss ein Mapping/Objekt sein.")
            CONFIG_PATH.write_text(config_text, encoding="utf-8")
            self._reload_gateway_config()
        except Exception as exc:
            return {"status": "error", "message": f"Konfiguration konnte nicht gespeichert werden: {exc}"}, 400

        return {"status": "ok", "message": "Konfiguration gespeichert und neu geladen."}, 200

    def _admin_players(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        try:
            players = self.gateway.lms.players() if self.gateway is not None else []
        except Exception as exc:
            return {"status": "error", "message": f"LMS-Player konnten nicht gelesen werden: {exc}"}, 502
        return {
            "status": "ok",
            "message": f"LMS erreichbar, {len(players)} Player gefunden.",
            "players": players,
        }, 200

    def _admin_alarms(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        if self.gateway is None:
            return {"status": "error", "message": "LMS Gateway ist nicht geladen."}, 503
        data = args or {}
        if data.get("operation") == "save_defaults":
            try:
                import yaml

                volume = max(0, min(100, int(data.get("volume", 50))))
                url = str(data.get("url") or "CURRENT_PLAYLIST").strip()
                sound_name = str(data.get("sound_name") or "Aktuelle Playlist").strip()
                config = self._current_config()
                config["alarms"] = {
                    "volume": volume,
                    "url": url,
                    "sound_name": sound_name,
                    "shuffle": bool(data.get("shuffle", False)),
                }
                with CONFIG_PATH.open("w", encoding="utf-8") as file:
                    yaml.safe_dump(config, file, allow_unicode=True, sort_keys=False)
                self._reload_gateway_config()
            except Exception as exc:
                return {"status": "error", "message": f"Wecker-Standards konnten nicht gespeichert werden: {exc}"}, 400
            return {"status": "ok", "message": "Wecker-Standards gespeichert."}, 200

        if data.get("operation") == "delete":
            player_id = str(data.get("player_id") or "").strip()
            alarm_id = str(data.get("alarm_id") or "").strip()
            configured = self._current_config().get("players") or {}
            configured_ids = {
                str(player.get("id") or "").strip()
                for player in configured.values()
                if isinstance(player, dict)
            }
            if not player_id or player_id not in configured_ids or not alarm_id:
                return {"status": "error", "message": "Der Wecker konnte nicht eindeutig zugeordnet werden."}, 400
            try:
                alarms = self.gateway.lms.alarms(player_id)
                alarm_rows = alarms.get("alarms_loop") or alarms.get("alarm_loop") or []
                if not any(str(alarm.get("id") or "") == alarm_id for alarm in alarm_rows if isinstance(alarm, dict)):
                    return {"status": "error", "message": "Der Wecker ist nicht mehr vorhanden."}, 404
                self.gateway.lms.delete_alarm(player_id, alarm_id)
            except Exception as exc:
                return {"status": "error", "message": f"Wecker konnte nicht geloescht werden: {exc}"}, 502
            return {"status": "ok", "message": "Wecker geloescht."}, 200

        rows: list[dict[str, Any]] = []
        errors: list[str] = []
        current_config = self._current_config()
        configured = current_config.get("players") or {}
        defaults = current_config.get("alarms") or {}
        sounds: list[dict[str, Any]] = []
        first_player_id = ""
        for room, player_config in configured.items():
            if not isinstance(player_config, dict):
                continue
            player_id = str(player_config.get("id") or "").strip()
            if not player_id:
                continue
            if not first_player_id:
                first_player_id = player_id
            try:
                result = self.gateway.lms.alarms(player_id)
                alarms = result.get("alarms_loop") or result.get("alarm_loop") or []
                for alarm in alarms if isinstance(alarms, list) else []:
                    rows.append({
                        **alarm,
                        "room": room,
                        "player_id": player_id,
                        "player_name": player_config.get("name") or player_config.get("lms_name") or room,
                    })
            except Exception as exc:
                errors.append(f"{room}: {exc}")
        if first_player_id:
            try:
                sounds = self.gateway.lms.alarm_sounds(first_player_id)
            except Exception as exc:
                errors.append(f"Wecktoene: {exc}")
        return {
            "status": "ok" if not errors else "partial",
            "alarms": rows,
            "count": len(rows),
            "errors": errors,
            "defaults": {
                "volume": max(0, min(100, int(defaults.get("volume", 50)))),
                "url": str(defaults.get("url") or "CURRENT_PLAYLIST"),
                "sound_name": str(defaults.get("sound_name") or "Aktuelle Playlist"),
                "shuffle": bool(defaults.get("shuffle", False)),
            },
            "sounds": sounds,
            "message": f"{len(rows)} Wecker aus LMS gelesen.",
        }, 200

    def _admin_features(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        data = args or {}
        if "features" not in data:
            return {"status": "ok", "features": self._feature_payload(self._current_config())}, 200

        try:
            import yaml

            config = self._current_config()
            current_features = dict(config.get("features") or {})
            next_features = data.get("features") or {}
            if not isinstance(next_features, dict):
                raise ValueError("features muss ein Objekt sein.")
            for feature_id in FEATURES:
                current_features[feature_id] = bool(next_features.get(feature_id, True))
            config["features"] = current_features
            with CONFIG_PATH.open("w", encoding="utf-8") as file:
                yaml.safe_dump(config, file, allow_unicode=True, sort_keys=False)
            self._reload_gateway_config()
        except Exception as exc:
            return {"status": "error", "message": f"Features konnten nicht gespeichert werden: {exc}"}, 400

        return {
            "status": "ok",
            "message": "Funktionsschalter gespeichert und neu geladen.",
            "features": self._feature_payload(self._current_config()),
        }, 200

    def _admin_logs(self, args: dict[str, Any], request_args: dict[str, Any]) -> tuple[dict[str, Any], int]:
        operation = str(args.get("operation") or "read").strip().casefold() if isinstance(args, dict) else "read"
        if operation == "clear":
            try:
                GATEWAY_LOG.parent.mkdir(parents=True, exist_ok=True)
                GATEWAY_LOG.write_text("", encoding="utf-8")
            except OSError as exc:
                return {"status": "error", "message": f"Protokoll konnte nicht geloescht werden: {exc}"}, 500
            return {
                "status": "ok",
                "message": "LMS-Gateway-Protokoll wurde geloescht.",
                "path": str(GATEWAY_LOG),
                "logs": "",
            }, 200

        lines = 200
        try:
            if isinstance(args, dict) and args.get("lines"):
                lines = max(20, min(1000, int(args.get("lines"))))
        except (TypeError, ValueError):
            lines = 200
        return {
            "status": "ok",
            "path": str(GATEWAY_LOG),
            "logs": self._tail_log(lines),
        }, 200

    def _tail_log(self, lines: int) -> str:
        if not GATEWAY_LOG.exists():
            return ""
        try:
            visible_lines = [
                line
                for line in GATEWAY_LOG.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
                if any(marker in line for marker in LMS_LOG_MARKERS)
                and not any(marker in line for marker in HIDDEN_LOG_MARKERS)
            ]
            return "".join(visible_lines[-lines:])
        except OSError as exc:
            return f"Log konnte nicht gelesen werden: {exc}"

    def _feature_payload(self, config: dict[str, Any]) -> list[dict[str, Any]]:
        values = config.get("features") or {}
        return [
            {
                "id": feature_id,
                "label": data["label"],
                "enabled": bool(values.get(feature_id, True)),
                "actions": sorted(data["actions"]),
            }
            for feature_id, data in FEATURES.items()
        ]

    @staticmethod
    def _clean_optional(value: Any) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


ADMIN_HTML = r"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LMS Gateway Admin</title>
  <style>
    :root { color-scheme: light dark; font-family: Segoe UI, Arial, sans-serif; }
    body { margin: 0; background: #f4f6f8; color: #18202a; }
    main { max-width: 1200px; margin: 0 auto; padding: 24px; }
    h1 { font-size: 28px; margin: 0 0 18px; }
    h2 { font-size: 18px; margin: 0 0 12px; }
    section { background: #fff; border: 1px solid #d9e0e7; border-radius: 8px; padding: 18px; margin-bottom: 16px; }
    .tabs { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; }
    .tabs button { background: #e8eef5; color: #1e2a36; }
    .tabs button.active { background: #1f6feb; color: #fff; }
    .panel { display: none; }
    .panel.active { display: block; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; }
    label { display: grid; gap: 6px; font-size: 13px; color: #445160; }
    input, textarea { border: 1px solid #b8c2cc; border-radius: 6px; padding: 9px 10px; font: inherit; background: #fff; color: #18202a; }
    textarea { width: 100%; box-sizing: border-box; min-height: 520px; font-family: Consolas, monospace; font-size: 13px; resize: vertical; }
    button { border: 0; border-radius: 6px; background: #1f6feb; color: white; padding: 10px 14px; font: inherit; cursor: pointer; }
    button.secondary { background: #4f5b66; }
    button.danger { background: #b42318; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    .status { padding: 10px 12px; border-radius: 6px; background: #eef4ff; border: 1px solid #c8dcff; margin-bottom: 12px; }
    .error { background: #fff0f0; border-color: #ffc8c8; }
    .feature { display: grid; grid-template-columns: auto 1fr; gap: 10px; align-items: start; border: 1px solid #d9e0e7; border-radius: 8px; padding: 12px; }
    .feature input { width: 20px; height: 20px; margin-top: 2px; }
    .feature strong { display: block; margin-bottom: 4px; }
    .feature small { color: #627184; word-break: break-word; }
    pre { white-space: pre-wrap; word-break: break-word; background: #f7f9fb; border: 1px solid #d9e0e7; border-radius: 6px; padding: 12px; overflow: auto; }
    .log-window { background: #0f1720; color: #d7e2ed; min-height: 520px; max-height: 680px; font-family: Consolas, monospace; font-size: 13px; }
    .test-result { min-height: 120px; }
    @media (prefers-color-scheme: dark) {
      body { background: #101418; color: #e8edf2; }
      section, input, textarea { background: #171d23; color: #e8edf2; border-color: #34414d; }
      label { color: #b9c4cf; }
      pre { background: #11171d; border-color: #34414d; }
      .status { background: #14243d; border-color: #275187; }
      .error { background: #3a1717; border-color: #733333; }
      .tabs button { background: #26313c; color: #e8edf2; }
      .feature { border-color: #34414d; }
      .feature small { color: #a8b5c4; }
    }
  </style>
</head>
<body>
<main>
  <h1>LMS Gateway Admin</h1>
  <div id="message" class="status">Lade...</div>
  <div class="tabs">
    <button class="active" data-tab="status">Status</button>
    <button data-tab="features">Funktionen</button>
    <button data-tab="config">YAML</button>
    <button data-tab="test">Test</button>
    <button data-tab="logs">Live-Log</button>
  </div>

  <section id="status" class="panel active">
    <h2>Status</h2>
    <div id="statusText" class="status">Lade Status...</div>
    <pre id="players">Noch keine Daten.</pre>
  </section>

  <section id="features" class="panel">
    <div class="actions">
      <h2 style="margin-right:auto">Sprachfunktionen</h2>
      <button onclick="saveFeatures()">Speichern</button>
      <button class="secondary" onclick="loadFeatures()">Neu laden</button>
    </div>
    <div id="featureGrid" class="grid"></div>
  </section>

  <section id="config" class="panel">
    <div class="actions">
      <h2 style="margin-right:auto">YAML-Konfiguration</h2>
      <button onclick="saveConfig()">Speichern und neu laden</button>
      <button class="secondary" onclick="loadConfig()">Neu laden</button>
    </div>
    <textarea id="configText" spellcheck="false"></textarea>
  </section>

  <section id="test" class="panel">
    <h2>Testbefehl</h2>
    <div class="grid">
      <label>Befehl<input id="testText" value="musik aus im wohnzimmer"></label>
      <label>Raum<input id="testRoom" value="wohnzimmer"></label>
      <label>Geraet<input id="testDevice" value="admin_test"></label>
      <label>Dry-Run<input id="testDryRun" type="checkbox" checked></label>
    </div>
    <div class="actions" style="margin-top: 14px">
      <button onclick="runTest()">Ausfuehren</button>
      <button class="secondary" onclick="loadLogs()">Log aktualisieren</button>
    </div>
    <pre id="testResult" class="test-result">Noch kein Test ausgefuehrt.</pre>
  </section>

  <section id="logs" class="panel">
    <div class="actions">
      <h2 style="margin-right:auto">Live-Log</h2>
      <label style="display:flex;align-items:center;gap:8px"><input id="autoLog" type="checkbox" checked> Auto-Refresh</label>
      <button class="secondary" onclick="loadLogs()">Aktualisieren</button>
    </div>
    <pre id="logText" class="log-window">Noch keine Logdaten.</pre>
  </section>
</main>

<script>
const api = (name) => `/api/appdaemon/${name}`;
let logTimer = null;

document.querySelectorAll('.tabs button').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.tabs button').forEach((item) => item.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((item) => item.classList.remove('active'));
    button.classList.add('active');
    document.getElementById(button.dataset.tab).classList.add('active');
  });
});

function setMessage(text, isError=false) {
  const message = document.getElementById('message');
  message.textContent = text;
  message.className = isError ? 'status error' : 'status';
}

async function postJson(endpoint, body={}) {
  const response = await fetch(api(endpoint), {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body),
  });
  const text = await response.text();
  let data = {};
  try { data = JSON.parse(text); } catch { data = {status: response.ok ? 'ok' : 'error', message: text}; }
  if (!response.ok || data.status === 'error') {
    throw new Error(data.message || `HTTP ${response.status}`);
  }
  return data;
}

async function loadStatus() {
  try {
    const data = await postJson('lms_gateway_admin_status');
    const lms = data.lms || {};
    const statusText = document.getElementById('statusText');
    statusText.className = lms.status === 'ok' ? 'status' : 'status error';
    statusText.textContent = lms.status === 'ok'
      ? `LMS erreichbar. Stand: ${data.time}. Konfiguration: ${data.config_path}`
      : `LMS nicht erreichbar: ${lms.message || 'unbekannter Fehler'}`;
    document.getElementById('players').textContent = JSON.stringify(lms.players || [], null, 2);
  } catch (error) {
    setMessage(error.message, true);
  }
}

async function loadFeatures() {
  try {
    const data = await postJson('lms_gateway_admin_features');
    const grid = document.getElementById('featureGrid');
    grid.innerHTML = '';
    (data.features || []).forEach((feature) => {
      const item = document.createElement('label');
      item.className = 'feature';
      item.innerHTML = `
        <input type="checkbox" data-feature="${feature.id}" ${feature.enabled ? 'checked' : ''}>
        <span><strong>${feature.label}</strong><small>${feature.id}: ${(feature.actions || []).join(', ')}</small></span>
      `;
      grid.appendChild(item);
    });
  } catch (error) {
    setMessage(error.message, true);
  }
}

async function saveFeatures() {
  const features = {};
  document.querySelectorAll('[data-feature]').forEach((input) => {
    features[input.dataset.feature] = input.checked;
  });
  try {
    const data = await postJson('lms_gateway_admin_features', {features});
    setMessage(data.message || 'Gespeichert.');
    await loadFeatures();
  } catch (error) {
    setMessage(error.message, true);
  }
}

async function loadConfig() {
  try {
    const data = await postJson('lms_gateway_admin_config');
    document.getElementById('configText').value = data.config_text || '';
  } catch (error) {
    setMessage(error.message, true);
  }
}

async function saveConfig() {
  try {
    const data = await postJson('lms_gateway_admin_config', {config_text: document.getElementById('configText').value});
    setMessage(data.message || 'Gespeichert.');
    await loadFeatures();
    await loadStatus();
  } catch (error) {
    setMessage(error.message, true);
  }
}

async function runTest() {
  const body = {
    text: document.getElementById('testText').value,
    room: document.getElementById('testRoom').value,
    device: document.getElementById('testDevice').value,
    dry_run: document.getElementById('testDryRun').checked,
    source: 'admin',
  };
  try {
    const response = await fetch(api('lms_gateway_command'), {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body),
    });
    const data = await response.json();
    document.getElementById('testResult').textContent = JSON.stringify(data, null, 2);
    await loadLogs();
  } catch (error) {
    document.getElementById('testResult').textContent = error.message;
  }
}

async function loadLogs() {
  try {
    const data = await postJson('lms_gateway_admin_logs', {lines: 300});
    const logText = document.getElementById('logText');
    logText.textContent = data.logs || '';
    logText.scrollTop = logText.scrollHeight;
  } catch (error) {
    setMessage(error.message, true);
  }
}

function startLogTimer() {
  if (logTimer) clearInterval(logTimer);
  logTimer = setInterval(() => {
    if (document.getElementById('autoLog').checked) loadLogs();
  }, 2000);
}

async function loadAll() {
  await loadStatus();
  await loadFeatures();
  await loadConfig();
  await loadLogs();
  setMessage('Bereit.');
  startLogTimer();
}

loadAll();
</script>
</body>
</html>"""
