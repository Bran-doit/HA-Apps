ADMIN_HTML = r"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LMS Gateway</title>
  <style>
    :root { color-scheme: light dark; font-family: Segoe UI, system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; background: #f5f7f9; color: #1f2933; }
    main { max-width: 1220px; margin: 0 auto; padding: 20px; }
    h1 { font-size: 27px; margin: 0 0 16px; display: flex; gap: 10px; align-items: center; }
    h2 { font-size: 18px; margin: 0; }
    section { background: #fff; border: 1px solid #d8e0e8; border-radius: 8px; padding: 16px; margin-bottom: 14px; }
    .badge { font-size: 12px; font-weight: 600; color: #52606d; background: #e8eef5; border-radius: 999px; padding: 4px 8px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 12px; }
    .tile { border: 1px solid #d8e0e8; border-radius: 6px; padding: 12px; background: #f9fbfd; min-width: 0; }
    .label, label { color: #596673; font-size: 12px; }
    .value { font-size: 15px; font-weight: 600; word-break: break-word; margin-top: 4px; }
    .banner { padding: 12px; border-radius: 6px; border: 1px solid #fed7aa; background: #fff7ed; margin: 12px 0; }
    .banner.ok { border-color: #bbf7d0; background: #ecfdf5; }
    .banner.error { border-color: #fecaca; background: #fef2f2; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    .tabs { margin: 0; border-bottom: 1px solid #d8e0e8; background: #fff; }
    .tabs-inner { display: flex; flex-wrap: nowrap; gap: 0; width: 100%; max-width: 1220px; margin: 0 auto; padding: 0 20px; }
    body.embedded .tabs { display: none; }
    .tab-button { display: grid; place-items: center; width: 62px; height: 48px; padding: 0; margin-bottom: -1px; border-radius: 0; border-bottom: 2px solid transparent; background: transparent; color: #3d4650; }
    .tab-button:hover { background: #f3f5f7; }
    .tab-button.active { background: transparent; color: #111827; border-bottom-color: #111827; }
    .tab-button svg { width: 24px; height: 24px; fill: none; stroke: currentColor; stroke-width: 2.2; stroke-linecap: round; stroke-linejoin: round; }
    .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }
    .tab-panel { display: none; }
    .tab-panel.active { display: block; }
    .section-title { margin-right: auto; }
    .subhead { font-size: 15px; font-weight: 700; margin: 18px 0 10px; }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; }
    .field { min-width: 0; }
    .field label { display: block; margin-bottom: 5px; }
    .selection-layout { display: grid; grid-template-columns: minmax(230px, .8fr) 1px minmax(0, 3fr); gap: 22px; align-items: stretch; }
    .selection-divider { background: #d8e0e8; width: 1px; }
    .selection-group { min-width: 0; }
    .group-heading { display: flex; align-items: center; gap: 7px; font-size: 14px; font-weight: 700; margin: 0 0 12px; }
    .field-label { display: flex; align-items: center; gap: 5px; margin-bottom: 5px; }
    .field-label label { margin: 0; }
    .info-button { display: inline-grid; place-items: center; width: 19px; height: 19px; min-width: 19px; padding: 0; border-radius: 50%; background: #e8eef5; color: #334155; font-size: 12px; font-weight: 700; line-height: 1; }
    .info-button:hover { background: #d8e3ef; }
    dialog.help-dialog { width: min(520px, calc(100vw - 32px)); border: 1px solid #cbd5e1; border-radius: 8px; padding: 0; background: #fff; color: #1f2933; box-shadow: 0 18px 48px rgba(15, 23, 42, .24); }
    dialog.help-dialog::backdrop { background: rgba(15, 23, 42, .42); }
    .help-dialog-body { padding: 18px; }
    .help-dialog-body h3 { margin: 0 0 10px; font-size: 18px; }
    .help-dialog-body p { margin: 0 0 12px; line-height: 1.5; }
    .help-dialog-body .actions { justify-content: flex-end; }
    input, textarea, select { width: 100%; border: 1px solid #b8c4d0; border-radius: 6px; padding: 8px 9px; font: inherit; background: #fff; color: #1f2933; }
    textarea { min-height: 380px; font: 13px Consolas, monospace; resize: vertical; }
    button { border: 0; border-radius: 6px; background: #2563eb; color: white; padding: 9px 13px; font: inherit; cursor: pointer; }
    button.secondary { background: #52606d; }
    button.danger { background: #b42318; }
    button:disabled { opacity: .55; cursor: wait; }
    .rows { display: grid; gap: 10px; }
    .row-card { border: 1px solid #d8e0e8; border-radius: 6px; padding: 12px; background: #f9fbfd; }
    .player-grid { display: grid; grid-template-columns: 1fr 1.35fr 1.2fr 1.35fr 1.5fr auto; gap: 8px; align-items: end; }
    .device-grid { display: grid; grid-template-columns: 1.5fr 1.3fr auto; gap: 8px; align-items: end; }
    .command-grid { display: grid; grid-template-columns: minmax(280px, 2fr) minmax(150px, 1fr) minmax(160px, 1fr) auto auto; gap: 10px; align-items: end; }
    .checkline { display: flex; align-items: center; gap: 8px; margin-bottom: 9px; white-space: nowrap; }
    .checkline input { width: auto; }
    .feature-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 10px; }
    .feature { display: grid; grid-template-columns: auto 1fr; gap: 9px; align-items: center; border: 1px solid #d8e0e8; border-radius: 6px; padding: 10px; }
    .feature input { width: 20px; height: 20px; }
    .guide-intro { margin: 0 0 14px; color: #52606d; }
    .guide-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(330px, 1fr)); gap: 12px; }
    .guide-group { border: 1px solid #d8e0e8; border-radius: 6px; padding: 14px; background: #f9fbfd; }
    .guide-group h3 { font-size: 16px; margin: 0 0 8px; }
    .guide-group p { margin: 6px 0 9px; }
    .guide-group ul { margin: 0; padding-left: 20px; }
    .guide-group li { margin: 6px 0; }
    .guide-group code { white-space: normal; color: #1d4ed8; }
    .guide-note { border-left: 4px solid #2563eb; padding: 10px 12px; margin: 12px 0; background: #eff6ff; }
    .alarm-table { width: 100%; border-collapse: collapse; margin-top: 12px; }
    .alarm-table th, .alarm-table td { padding: 10px; text-align: left; border-bottom: 1px solid #d8e0e8; vertical-align: top; }
    .alarm-table th { color: #596673; font-size: 12px; }
    .state-pill { display: inline-block; padding: 3px 8px; border-radius: 999px; background: #e8eef5; font-size: 12px; font-weight: 600; }
    .state-pill.active { background: #dcfce7; color: #166534; }
    .command-history { display: grid; gap: 8px; }
    .command-history-empty { color: #596673; padding: 12px 0; }
    .command-history-item { display: grid; grid-template-columns: 14px minmax(0, 1fr); gap: 10px; border: 1px solid #d8e0e8; border-radius: 6px; padding: 11px 12px; background: #f9fbfd; }
    .command-state { width: 11px; height: 11px; margin-top: 4px; border-radius: 50%; background: #dc2626; box-shadow: 0 0 0 3px #fee2e2; }
    .command-state.ok { background: #16a34a; box-shadow: 0 0 0 3px #dcfce7; }
    .command-history-title { font-weight: 700; word-break: break-word; }
    .command-history-meta { color: #596673; font-size: 12px; margin-top: 4px; line-height: 1.45; word-break: break-word; }
    pre { white-space: pre-wrap; word-break: break-word; background: #f8fafc; border: 1px solid #d8e0e8; border-radius: 6px; padding: 12px; max-height: 420px; overflow: auto; }
    #message { min-height: 22px; margin: 12px 0 0; }
    details { margin-top: 18px; }
    summary { cursor: pointer; font-weight: 700; }
    @media (max-width: 900px) {
      .player-grid, .device-grid, .command-grid { grid-template-columns: 1fr; }
      .guide-grid { grid-template-columns: 1fr; }
      .selection-layout { grid-template-columns: 1fr; gap: 16px; }
      .selection-divider { width: 100%; height: 1px; }
    }
    @media (prefers-color-scheme: dark) {
      body { background: #11161c; color: #e6edf3; }
      section, input, textarea, select { background: #171d24; color: #e6edf3; border-color: #344250; }
      .tile, .row-card, pre { background: #111820; border-color: #344250; }
      .label, label { color: #aab6c2; }
      .badge { background: #273444; color: #d6e0ea; }
      .banner { background: #332414; border-color: #7a4b18; }
      .banner.ok { background: #133226; border-color: #246b4a; }
      .banner.error { background: #371818; border-color: #7a3030; }
      .feature { border-color: #344250; }
      .selection-divider { background: #344250; }
      .info-button { background: #273444; color: #e6edf3; }
      .info-button:hover { background: #34475c; }
      dialog.help-dialog { background: #171d24; color: #e6edf3; border-color: #344250; }
      .guide-intro { color: #aab6c2; }
      .guide-group { background: #111820; border-color: #344250; }
      .guide-group code { color: #93c5fd; }
      .guide-note { background: #15253b; }
      .tabs { background: #171d24; border-color: #344250; }
      .tab-button { color: #aab6c2; }
      .tab-button:hover { background: #263441; }
      .tab-button.active { color: #fff; border-bottom-color: #fff; }
    }
  </style>
</head>
<body>
  <nav class="tabs" aria-label="Bereiche">
   <div class="tabs-inner">
    <button class="tab-button active" data-tab="standard" onclick="showTab('standard')" aria-label="Status" title="Status">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
      <span class="sr-only">Status</span>
    </button>
    <button class="tab-button" data-tab="alarms" onclick="showTab('alarms')" aria-label="Wecker" title="Wecker">
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M5 3 2 6m17-3 3 3M6 21l1.5-2M18 21l-1.5-2"/></svg>
      <span class="sr-only">Wecker</span>
    </button>
    <button class="tab-button" data-tab="configuration" onclick="showTab('configuration')" aria-label="Konfiguration" title="Konfiguration">
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.74v.5a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
      <span class="sr-only">Konfiguration</span>
    </button>
    <button class="tab-button" data-tab="guide" onclick="showTab('guide')" aria-label="Bedienungsanleitung" title="Bedienungsanleitung">
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 1 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>
      <span class="sr-only">Bedienungsanleitung</span>
    </button>
   </div>
  </nav>

<main>
  <h1>LMS Gateway <span class="badge">AppDaemon</span></h1>

  <section>
    <div class="grid">
      <div class="tile"><div class="label">Ausfuehrung</div><div class="value">Intern in AppDaemon</div></div>
      <div class="tile"><div class="label">Schnittstelle</div><div class="value">Home Assistant / AppDaemon</div></div>
      <div class="tile"><div class="label">Konfiguration</div><div class="value" id="headerConfig">-</div></div>
    </div>
  </section>

  <div id="tab-standard" class="tab-panel active">
  <section>
    <div class="actions">
      <h2 class="section-title">Status</h2>
      <button onclick="loadAll()">Aktualisieren</button>
      <button class="secondary" onclick="testConnection()">Verbindung testen</button>
    </div>
    <p id="message"></p>
    <div id="statusBanner" class="banner">Status noch nicht geladen.</div>
    <div class="grid">
      <div class="tile"><div class="label">LMS</div><div class="value" id="tileLms">-</div></div>
      <div class="tile"><div class="label">Genre-Metadaten</div><div class="value" id="tileGenreApi">-</div></div>
      <div class="tile"><div class="label">Gefundene Player</div><div class="value" id="tilePlayers">-</div></div>
      <div class="tile"><div class="label">Konfigurierte Raeume</div><div class="value" id="tileRooms">-</div></div>
    </div>
    <div class="subhead">Interpretation der letzten Befehle</div>
    <div id="commandHistory" class="command-history"><div class="command-history-empty">Noch kein Befehl verarbeitet.</div></div>
  </section>

  <section>
    <div class="actions">
      <h2 class="section-title">Sprachbefehl testen</h2>
    </div>
    <div class="command-grid" style="margin-top:12px">
      <div class="field"><label for="commandText">Steuersatz</label><input id="commandText" placeholder="z.B. spiele das zweite Album im Schlafzimmer"></div>
      <div class="field"><label for="commandRoom">Raum optional</label><input id="commandRoom"></div>
      <div class="field"><label for="commandDevice">Dialogkennung</label><input id="commandDevice" value="admin_test"></div>
      <label class="checkline"><input id="commandDryRun" type="checkbox" checked>Nur pruefen</label>
      <button onclick="testCommand()">Testen</button>
    </div>
    <pre id="commandResult">Noch kein Test ausgefuehrt.</pre>
  </section>

  <section>
    <div class="actions">
      <h2 class="section-title">Protokoll</h2>
      <button class="secondary" onclick="loadLogs()">Aktualisieren</button>
      <button class="danger" onclick="clearLogs()">Protokoll loeschen</button>
    </div>
    <pre id="logText">Noch keine Logdaten.</pre>
  </section>

  </div>

  <div id="tab-alarms" class="tab-panel">
  <section>
    <div class="actions">
      <h2 class="section-title">LMS-Wecker</h2>
      <button onclick="loadAlarms()">Aktualisieren</button>
    </div>
    <div class="subhead">Standards fuer neue Wecker</div>
    <div class="form-grid">
      <div class="field"><label for="alarmDefaultVolume">Lautstaerke in Prozent</label><input id="alarmDefaultVolume" type="number" min="0" max="100" step="1"></div>
      <div class="field"><label for="alarmDefaultSound">Weckton</label><select id="alarmDefaultSound"></select></div>
      <label class="checkline"><input id="alarmDefaultShuffle" type="checkbox">Zufallswiedergabe</label>
      <div class="field"><label>&nbsp;</label><button type="button" onclick="saveAlarmDefaults()">Standards speichern</button></div>
    </div>
    <div id="alarmBanner" class="banner">Wecker noch nicht geladen.</div>
    <div style="overflow-x:auto">
      <table class="alarm-table">
        <thead><tr><th>Raum / Player</th><th>Zeit</th><th>Tage</th><th>Status</th><th>Typ</th><th>Lautstaerke</th><th>Quelle</th><th>Aktion</th></tr></thead>
        <tbody id="alarmRows"><tr><td colspan="8">Keine Daten.</td></tr></tbody>
      </table>
    </div>
  </section>
  </div>

  <div id="tab-configuration" class="tab-panel">
  <section>
    <div class="actions">
      <h2 class="section-title">Konfiguration</h2>
      <button class="secondary" onclick="loadConfig()">Einlesen</button>
      <button onclick="saveConfig()">Speichern</button>
    </div>

    <div class="subhead">LMS-Verbindung</div>
    <div class="form-grid">
      <div class="field"><label for="lmsHost">LMS IP oder Host</label><input id="lmsHost"></div>
      <div class="field"><label for="lmsHttpPort">LMS Web-Port</label><input id="lmsHttpPort" type="number" min="1" max="65535"></div>
      <div class="field"><label for="lmsCliPort">LMS CLI-Port</label><input id="lmsCliPort" type="number" min="1" max="65535"></div>
      <div class="field"><label for="lmsTimeout">Timeout Sekunden</label><input id="lmsTimeout" type="number" min="1" max="300"></div>
    </div>

    <div class="subhead">Dialog und Suche</div>
    <div class="form-grid">
      <div class="field"><label for="dialogTtl">Dialog-Zeitfenster Sekunden</label><input id="dialogTtl" type="number" min="30" max="3600"></div>
      <div class="field"><label for="controlFollowupSeconds">Folgefenster fuer Steuerbefehle</label><input id="controlFollowupSeconds" type="number" min="0" max="60"></div>
      <div class="field"><label for="matchMinScore">Mindesttreffer Suche</label><input id="matchMinScore" type="number" min="0" max="1" step="0.01"></div>
      <div class="field"><label for="artistLimit">Kuenstler-Suchlimit</label><input id="artistLimit" type="number" min="1" max="500"></div>
      <div class="field"><label for="albumLimit">Album-Suchlimit</label><input id="albumLimit" type="number" min="1" max="500"></div>
    </div>

    <div class="actions" style="margin-top:18px">
      <div class="subhead section-title" style="margin-top:0">Genre-Scanner-API</div>
      <button class="secondary" type="button" onclick="testGenreApi()">Verbindung testen</button>
    </div>
    <label class="checkline"><input id="genreApiEnabled" type="checkbox">Genre-Scanner-API verwenden</label>
    <div class="form-grid">
      <div class="field"><label for="genreApiBaseUrl">Basis-URL</label><input id="genreApiBaseUrl" placeholder="http://genre-scanner:8090"></div>
      <div class="field"><label for="genreApiTimeout">Verbindungstest-Timeout Sekunden</label><input id="genreApiTimeout" type="number" min="1" max="300"></div>
      <div class="field"><label for="genreApiSearchTimeout">Sprachsuche-Timeout Sekunden</label><input id="genreApiSearchTimeout" type="number" min="1" max="120"></div>
      <div class="field"><label for="genreApiRetryAttempts">Verbindungsversuche</label><input id="genreApiRetryAttempts" type="number" min="1" max="10"></div>
      <div class="field"><label for="genreApiRetryDelay">Pause zwischen Versuchen</label><input id="genreApiRetryDelay" type="number" min="0" max="30" step="0.5"></div>
      <div class="field"><label for="genreApiLimit">Standardanzahl Titel</label><input id="genreApiLimit" type="number" min="1" max="500"></div>
      <div class="field"><label for="genreApiToken">API-Token optional</label><input id="genreApiToken" type="password" autocomplete="new-password"></div>
      <div class="field"><label for="genreApiPathFrom">Scanner-Pfadpraefix</label><input id="genreApiPathFrom" placeholder="L:\\Musik\\"></div>
      <div class="field"><label for="genreApiPathTo">LMS-Pfadpraefix</label><input id="genreApiPathTo" placeholder="\\\\server\\Musik\\"></div>
    </div>
    <label class="checkline" style="margin-top:10px"><input id="genreApiVerifyTls" type="checkbox">TLS-Zertifikat pruefen</label>
    <div id="genreApiBanner" class="banner">API ist noch nicht geprueft.</div>

    <div class="subhead">Musikauswahl</div>
    <div class="selection-layout">
      <div class="selection-group">
        <div class="group-heading">Genre-Quelle <button class="info-button" type="button" aria-label="Genre-Quelle erklaeren" title="Genre-Quelle erklaeren" onclick="openSettingHelp('genreSource')">i</button></div>
        <div class="field"><label for="genreSelectionSource">Quelle fuer reine Genre-Befehle</label><select id="genreSelectionSource"><option value="scanner_with_lms_fallback">Genre-Scanner, danach LMS</option><option value="lms">Nur LMS</option></select></div>
      </div>
      <div class="selection-divider" aria-hidden="true"></div>
      <div class="selection-group">
        <div class="group-heading">Mood-Gewichtung <button class="info-button" type="button" aria-label="Mood-Gewichtung erklaeren" title="Mood-Gewichtung erklaeren" onclick="openSettingHelp('moods')">i</button></div>
        <div class="form-grid">
          <div class="field"><div class="field-label"><label for="profileRelaxedMin">Entspannt ab</label><button class="info-button" type="button" aria-label="Entspannt-Grenzwert erklaeren" title="Entspannt-Grenzwert erklaeren" onclick="openSettingHelp('relaxed')">i</button></div><input id="profileRelaxedMin" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileStimulatingMax">Anregend: entspannt maximal</label><button class="info-button" type="button" aria-label="Anregend-Grenzwert erklaeren" title="Anregend-Grenzwert erklaeren" onclick="openSettingHelp('stimulating')">i</button></div><input id="profileStimulatingMax" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileHappyMin">Froehlich ab</label><button class="info-button" type="button" aria-label="Froehlich-Grenzwert erklaeren" title="Froehlich-Grenzwert erklaeren" onclick="openSettingHelp('happy')">i</button></div><input id="profileHappyMin" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileMelancholicMax">Melancholisch: froehlich maximal</label><button class="info-button" type="button" aria-label="Melancholisch-Grenzwert erklaeren" title="Melancholisch-Grenzwert erklaeren" onclick="openSettingHelp('melancholic')">i</button></div><input id="profileMelancholicMax" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileDanceableMin">Tanzbar ab</label><button class="info-button" type="button" aria-label="Tanzbar-Grenzwert erklaeren" title="Tanzbar-Grenzwert erklaeren" onclick="openSettingHelp('danceable')">i</button></div><input id="profileDanceableMin" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileInstrumentalMin">Instrumental ab</label><button class="info-button" type="button" aria-label="Instrumental-Grenzwert erklaeren" title="Instrumental-Grenzwert erklaeren" onclick="openSettingHelp('instrumental')">i</button></div><input id="profileInstrumentalMin" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileBackgroundRelaxedMin">Hintergrund: entspannt ab</label><button class="info-button" type="button" aria-label="Hintergrund-Entspanntheit erklaeren" title="Hintergrund-Entspanntheit erklaeren" onclick="openSettingHelp('backgroundRelaxed')">i</button></div><input id="profileBackgroundRelaxedMin" type="number" min="0" max="1" step="0.05"></div>
          <div class="field"><div class="field-label"><label for="profileBackgroundLraMax">Hintergrund: LRA maximal</label><button class="info-button" type="button" aria-label="Hintergrund-LRA erklaeren" title="Hintergrund-LRA erklaeren" onclick="openSettingHelp('backgroundLra')">i</button></div><input id="profileBackgroundLraMax" type="number" min="0" max="100" step="0.5"></div>
        </div>
      </div>
    </div>

    <div class="actions" style="margin-top:18px">
      <div class="subhead section-title" style="margin-top:0">Player und Raeume</div>
      <button class="secondary" onclick="scanLmsPlayers()">LMS auslesen</button>
    </div>
    <div id="playersRows" class="rows"></div>

    <div class="actions" style="margin-top:18px">
      <div class="subhead section-title" style="margin-top:0">Eingabegeraete und Standardraeume</div>
      <button class="secondary" onclick="addDeviceRow()">Geraet hinzufuegen</button>
    </div>
    <div id="devicesRows" class="rows"></div>

    <details>
      <summary>Erweiterte YAML-Konfiguration</summary>
      <div class="actions" style="margin:12px 0">
        <button class="secondary" onclick="applyYaml()">YAML neu einlesen</button>
      </div>
      <textarea id="configText" spellcheck="false"></textarea>
    </details>
  </section>

  <section>
    <div class="actions">
      <h2 class="section-title">Sprachfunktionen</h2>
      <button onclick="saveFeatures()">Speichern</button>
    </div>
    <div id="featureGrid" class="feature-grid" style="margin-top:12px"></div>
  </section>
  </div>

  <div id="tab-guide" class="tab-panel">
  <section>
    <h2>Bedienungsanleitung</h2>
    <p class="guide-intro">Beispiele f&uuml;r Sprachbefehle an das LMS Gateway. Begriffe in spitzen Klammern werden durch den gew&uuml;nschten Namen, Raum oder Wert ersetzt. H&ouml;flichkeits- und F&uuml;llw&ouml;rter wie &bdquo;bitte&ldquo;, &bdquo;mir&ldquo;, &bdquo;mal&ldquo; oder &bdquo;etwas&ldquo; sind in vielen Formulierungen erlaubt.</p>

    <div class="guide-note"><strong>Zielangabe:</strong> Ein Ziel kann ein Raum, Playername oder Alias sein, zum Beispiel <code>im Wohnzimmer</code> oder <code>auf dem wei&szlig;en Radio</code>. Fehlt das Ziel, wird nachgefragt. F&uuml;r dieselbe Eingabequelle merkt sich das Gateway den zuletzt verwendeten Player.</div>

    <div class="guide-grid">
      <article class="guide-group">
        <h3>Musik eines K&uuml;nstlers</h3>
        <p>Erstellt eine gemischte Playlist mit Musik des K&uuml;nstlers, Album-Interpreten oder Komponisten.</p>
        <ul>
          <li><code>Spiele Musik von &lt;K&uuml;nstler&gt; im &lt;Ziel&gt;</code></li>
          <li><code>Spiele etwas von &lt;K&uuml;nstler&gt;</code></li>
          <li><code>Gib Tracks von &lt;K&uuml;nstler&gt; wieder</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Einzelner Titel</h3>
        <p>Sucht einen Song mit toleranter Titel- und K&uuml;nstlersuche.</p>
        <ul>
          <li><code>Spiele von &lt;K&uuml;nstler&gt; den Titel &lt;Titel&gt; im &lt;Ziel&gt;</code></li>
          <li><code>Spiele den Song &lt;Titel&gt; von &lt;K&uuml;nstler&gt;</code></li>
          <li><code>Spiele &lt;Titel&gt; von &lt;K&uuml;nstler&gt;</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Alben suchen und spielen</h3>
        <p>Ein konkretes Album wird direkt gesucht. Bei einer K&uuml;nstlersuche wird eine nummerierte Auswahl angeboten.</p>
        <ul>
          <li><code>Spiele das Album &lt;Album&gt; im &lt;Ziel&gt;</code></li>
          <li><code>Spiele ein Album von &lt;K&uuml;nstler&gt;</code></li>
          <li><code>Welche Alben habe ich von &lt;K&uuml;nstler&gt;?</code></li>
          <li><code>Welche Musik habe ich von &lt;K&uuml;nstler&gt;?</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Albumauswahl bedienen</h3>
        <p>Eine offene oder zuletzt gespeicherte Albumliste kann per Nummer, Namen oder Richtung bedient werden.</p>
        <ul>
          <li><code>Spiele das zweite Album im &lt;Ziel&gt;</code></li>
          <li><code>Nummer &lt;Zahl&gt;</code> oder <code>Spiele &lt;Albumname&gt;</code></li>
          <li><code>N&auml;chstes Album</code></li>
          <li><code>Vorheriges Album</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Radio</h3>
        <p>Sender werden in den LMS-Favoriten gesucht. Ohne Namen startet der zuletzt gespielte Sender des Ziels; falls keiner bekannt ist, folgt eine Auswahl.</p>
        <ul>
          <li><code>Spiele Radio &lt;Sender&gt; im &lt;Ziel&gt;</code></li>
          <li><code>Spiele Internetradio &lt;Sender&gt;</code></li>
          <li><code>Spiele Radio im &lt;Ziel&gt;</code></li>
          <li><code>Spiele Radio</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Genre und &auml;hnliche Musik</h3>
        <p>Die Quelle reiner Genre-Wiedergaben ist konfigurierbar. Im Modus &bdquo;Genre-Scanner, danach LMS&ldquo; erstellt zuerst der Scanner die begrenzte Zufallsplaylist. Ist er nicht erreichbar oder liefert keine abspielbaren Treffer, f&auml;llt das Gateway auf die LMS-Genresuche zur&uuml;ck. Die tats&auml;chlich verwendete Quelle und ein m&ouml;glicher R&uuml;ckfallgrund stehen in der Befehlsinterpretation.</p>
        <ul>
          <li><code>Spiele &lt;Genre&gt; im &lt;Ziel&gt;</code></li>
          <li><code>Spiele etwas &lt;Genre&gt;</code></li>
          <li><code>Kannst du ein bisschen &lt;Genre&gt; im &lt;Ziel&gt; spielen?</code></li>
          <li><code>Spiele &auml;hnliche Musik</code></li>
          <li><code>Mehr davon</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Moods, Genres und Zeitr&auml;ume</h3>
        <p>Sobald ein Mood genannt wird, kombiniert das Gateway die Eigenschaften mit optionalen Genres und Zeitr&auml;umen &uuml;ber die Genre-Scanner-API. Mehrere Genres gelten als Alternativen. Reihenfolge und typische F&uuml;llw&ouml;rter sind variabel.</p>
        <ul>
          <li><code>Spiele ruhigen Jazz im &lt;Ziel&gt;</code></li>
          <li><code>Spiele Jazz zum Entspannen</code></li>
          <li><code>Spiele fr&ouml;hliche tanzbare Musik aus Pop oder Soul</code></li>
          <li><code>Spiele Rockmusik</code> beziehungsweise <code>Spiele Popmusik</code> &ndash; entspricht Rock beziehungsweise Pop.</li>
          <li><code>Spiele Folkmusik</code>, <code>Reggae-Musik</code>, <code>lateinamerikanische Musik</code> oder <code>Schlagermusik</code> &ndash; entspricht Folk, Reggae, Latin beziehungsweise Schlager.</li>
          <li><code>Spiele ruhige instrumentale Filmmusik</code></li>
          <li><code>Spiele tanzbare Musik aus den Achtzigern</code></li>
          <li><code>Spiele entspannten Jazz von 1990 bis 1999</code></li>
          <li><code>Spiele Hintergrundmusik aus Jazz</code></li>
        </ul>
        <p>Verf&uuml;gbare Moods: entspannt/ruhig/chillig, anregend/energiegeladen/aufregend/wild, fr&ouml;hlich/heiter/lustig, melancholisch/traurig, tanzbar, instrumental und Hintergrundmusik. Anregend verwendet einen niedrigen RELAXED-Wert, melancholisch einen niedrigen HAPPY-Wert. Hintergrundmusik kombiniert Entspanntheit mit begrenzter Lautheitsspanne.</p>
      </article>

      <article class="guide-group">
        <h3>H&ouml;rb&uuml;cher, H&ouml;rspiele und Comedy</h3>
        <p>Sucht tolerant in den Musikordnern f&uuml;r H&ouml;rb&uuml;cher beziehungsweise Humor. Bei mehreren Treffern folgt eine nummerierte Auswahl ohne Zufallswiedergabe.</p>
        <ul>
          <li><code>Spiele das H&ouml;rbuch &lt;Name&gt; im &lt;Ziel&gt;</code></li>
          <li><code>Spiele H&ouml;rb&uuml;cher von &lt;Name&gt;</code></li>
          <li><code>Spiele Comedy von &lt;Name&gt;</code></li>
          <li><code>Spiele Kabarett von &lt;Name&gt;</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Album zum laufenden Titel</h3>
        <p>Ermittelt das Album der aktuellen Wiedergabe und startet es vom ersten Titel.</p>
        <ul>
          <li><code>Spiele das Album zur laufenden Musik</code></li>
          <li><code>Zum laufenden Track das entsprechende Album</code></li>
          <li><code>Spiele das ganze Album dazu</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Lautst&auml;rke</h3>
        <p>Ohne Zahlenwert wird die Lautst&auml;rke in Schritten von f&uuml;nf Prozent ver&auml;ndert.</p>
        <ul>
          <li><code>Setze die Lautst&auml;rke auf &lt;Wert&gt;</code></li>
          <li><code>Erh&ouml;he die Lautst&auml;rke um &lt;Wert&gt;</code></li>
          <li><code>Verringere die Lautst&auml;rke um &lt;Wert&gt;</code></li>
          <li><code>Lauter</code>, <code>Noch lauter</code>, <code>Leiser</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Wiedergabesteuerung</h3>
        <ul>
          <li><code>Musik aus</code>, <code>Stille</code>, <code>Pause</code></li>
          <li><code>Schalt das Radio aus</code> oder <code>Schalt das Radio im &lt;Ziel&gt; aus</code></li>
          <li><code>Musik an</code> oder <code>Weiterspielen</code></li>
          <li><code>N&auml;chster Titel</code> oder <code>Vorheriger Titel</code></li>
          <li><code>Springe &lt;Zahl&gt; Tracks vor</code></li>
          <li><code>&lt;Zahl&gt; Titel zur&uuml;ck</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Wecker</h3>
        <p>Wecker werden direkt im LMS auf dem Player des genannten Raums gespeichert. Ist das Mikrofon in der Konfiguration einem Raum zugeordnet, kann die Raumangabe entfallen. Andernfalls verwendet das Gateway den letzten Raum dieses Eingabegeraets oder fragt nach.</p>
        <ul>
          <li><code>Weck mich morgen um 6:15 Uhr im Schlafzimmer</code></li>
          <li><code>Stell den Wecker morgen um 7 Uhr im Schlafzimmer</code></li>
          <li><code>Weck mich werktags um 6:30 Uhr im Schlafzimmer</code></li>
          <li><code>Weck mich unter der Woche um 6:30 Uhr im Schlafzimmer</code></li>
          <li><code>Weck mich jeden Morgen um 7 Uhr</code></li>
          <li><code>Weck mich immer um 7 Uhr im Schlafzimmer</code></li>
          <li><code>Weck mich in 30 Minuten</code></li>
          <li><code>Welche Wecker sind im Schlafzimmer gestellt?</code></li>
          <li><code>Lass mich noch schlafen</code>, <code>Lass mich noch ein bisschen schlafen</code> oder <code>Schlummere noch zehn Minuten</code></li>
          <li><code>Schalte den Wecker im Schlafzimmer ab</code> beendet den klingelnden Wecker.</li>
          <li><code>Deaktiviere alle Wecker im Schlafzimmer</code></li>
          <li><code>Aktiviere alle Wecker im Schlafzimmer wieder</code></li>
          <li><code>Loesche den naechsten Wecker im Schlafzimmer</code></li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Player synchronisieren</h3>
        <ul>
          <li><code>Synchronisiere &lt;Raum&gt; mit &lt;Ziel&gt;</code></li>
          <li><code>L&ouml;se die Synchronisation zwischen &lt;Raum&gt; und &lt;Ziel&gt;</code></li>
          <li><code>Synchronisierung abbrechen</code> l&ouml;st alle Gruppen.</li>
        </ul>
      </article>

      <article class="guide-group">
        <h3>Wiedergabe &uuml;bertragen</h3>
        <p>Kopiert die aktuelle Playlist und setzt sie am gleichen Punkt auf einem anderen Player fort.</p>
        <ul>
          <li><code>Setze die Wiedergabe in &lt;Ziel&gt; fort</code></li>
          <li><code>Setze die Wiedergabe von &lt;Quelle&gt; in &lt;Ziel&gt; fort</code></li>
          <li><code>Spiele die Playlist weiter in &lt;Ziel&gt;</code></li>
        </ul>
      </article>
    </div>

    <div class="guide-note"><strong>Dialoge:</strong> Antworten sind per Nummer, Position oder eindeutigem Namen m&ouml;glich. Ein Dialog kann mit <code>Abbruch</code>, <code>Vergiss es</code>, <code>Es hat sich erledigt</code>, <code>Doch nicht</code> oder <code>Lass es</code> beendet werden.</div>
  </section>
  </div>
</main>
<dialog id="settingHelpDialog" class="help-dialog" aria-labelledby="settingHelpTitle">
  <div class="help-dialog-body">
    <h3 id="settingHelpTitle">Einstellung</h3>
    <p id="settingHelpText"></p>
    <div class="actions"><button type="button" onclick="closeSettingHelp()">Schliessen</button></div>
  </div>
</dialog>
<script>
const api = (name) => `/api/appdaemon/${name}`;
let currentConfig = {};

const settingHelp = {
  genreSource: {
    title: 'Genre-Quelle',
    text: 'Diese Auswahl betrifft nur reine Genre-Befehle wie "Spiele Jazz". "Genre-Scanner, danach LMS" fragt zuerst den Scanner ab und verwendet LMS nur bei einem Fehler oder ohne abspielbare Treffer. "Nur LMS" nutzt ausschliesslich die Genre-Daten der LMS-Bibliothek. Mood-Befehle sind davon nicht betroffen.'
  },
  moods: {
    title: 'Mood-Gewichtung',
    text: 'Die Modellwerte reichen von 0 bis 1. Ein Mindestwert von 0,7 bedeutet: Nur Titel mit einem Scanner-Wert von mindestens 0,7 werden ausgewahlt. Hoehere Werte sind strenger und liefern meist weniger Treffer; niedrigere Werte sind toleranter.'
  },
  relaxed: {
    title: 'Entspannt ab',
    text: 'Mindestwert fuer RELAXED bei Befehlen wie "Spiele ruhige oder entspannte Musik". 0,7 steht fuer deutlich entspannt wirkende Titel. Ein hoher Wert garantiert weder geringe Lautheit noch das Fehlen einzelner kraeftiger Passagen.'
  },
  stimulating: {
    title: 'Anregend: entspannt maximal',
    text: 'Hoechstwert fuer RELAXED bei "anregend", "energiegeladen", "aufregend" oder "wild". Ein Wert von 0,35 laesst nur Titel mit hoechstens 0,35 Entspanntheit zu. Dies ist ein Gegenprofil zu entspannter Musik, aber keine direkte Messung von Tempo oder Lautheit.'
  },
  happy: {
    title: 'Froehlich ab',
    text: 'Mindestwert fuer HAPPY bei "froehlich", "heiter", "lustig" oder "gute Laune". Bewertet wird der musikalische Ausdruck; der Liedtext muss deshalb nicht ebenfalls froehlich sein.'
  },
  melancholic: {
    title: 'Melancholisch: froehlich maximal',
    text: 'Hoechstwert fuer HAPPY bei "melancholisch", "traurig" oder "schwermuetig". Ein Wert von 0,35 waehlt Titel mit hoechstens 0,35 musikalischer Froehlichkeit. Der Scanner bewertet den musikalischen Ausdruck und nicht zwingend den Liedtext.'
  },
  danceable: {
    title: 'Tanzbar ab',
    text: 'Mindestwert fuer DANCEABLE bei tanzbarer Musik. Tanzbarkeit ist nicht dasselbe wie hohes Tempo: Auch langsamere Titel koennen rhythmisch gut tanzbar sein.'
  },
  instrumental: {
    title: 'Instrumental ab',
    text: 'Mindestwert fuer INSTRUMENTAL. Hohe Werte sprechen fuer Musik ohne Gesang oder mit ueberwiegend instrumentalem Charakter, garantieren aber keine vollstaendige Stimmfreiheit.'
  },
  backgroundRelaxed: {
    title: 'Hintergrund: entspannt ab',
    text: 'Erste Bedingung des Profils "Hintergrundmusik". Der Titel muss mindestens diesen RELAXED-Wert erreichen. Das Profil kombiniert diesen Wert zusaetzlich mit der maximalen Lautheitsspanne.'
  },
  backgroundLra: {
    title: 'Hintergrund: LRA maximal',
    text: 'Maximale Loudness Range in LU fuer Hintergrundmusik. Kleine Werte bedeuten gleichmaessigere Lautheit, grosse Werte staerkere Unterschiede zwischen leisen und lauten Passagen. Bei 10 werden nur Titel mit LRA bis 10 LU verwendet.'
  }
};

function openSettingHelp(key) {
  const help = settingHelp[key];
  if (!help) return;
  document.getElementById('settingHelpTitle').textContent = help.title;
  document.getElementById('settingHelpText').textContent = help.text;
  document.getElementById('settingHelpDialog').showModal();
}
function closeSettingHelp() { document.getElementById('settingHelpDialog').close(); }

function showTab(name) {
  document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.toggle('active', panel.id === `tab-${name}`));
  document.querySelectorAll('.tab-button').forEach(button => button.classList.toggle('active', button.dataset.tab === name));
  sessionStorage.setItem('lms_gateway_admin_tab', name);
}

function value(id) { return document.getElementById(id).value.trim(); }
function setValue(id, nextValue) { document.getElementById(id).value = nextValue ?? ''; }
function numberValue(id, fallback) {
  const parsed = Number(value(id));
  return value(id) !== '' && Number.isFinite(parsed) ? parsed : fallback;
}
function setMessage(text, isError=false) {
  const message = document.getElementById('message');
  message.textContent = text || '';
  message.style.color = isError ? '#b42318' : '';
}
async function postJson(endpoint, body={}) {
  const response = await fetch(api(endpoint), {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body),
  });
  const text = await response.text();
  let data = {};
  try { data = JSON.parse(text); } catch { data = {status: 'error', message: text}; }
  if (!response.ok || data.status === 'error') throw new Error(data.message || `HTTP ${response.status}`);
  return data;
}
async function loadStatus() {
  const data = await postJson('lms_gateway_admin_status');
  const lms = data.lms || {};
  const lmsConfig = data.lms_config || {};
  const banner = document.getElementById('statusBanner');
  banner.className = lms.status === 'ok' ? 'banner ok' : 'banner error';
  banner.textContent = lms.status === 'ok' ? 'LMS Gateway ist bereit.' : `LMS nicht erreichbar: ${lms.message || 'unbekannter Fehler'}`;
  document.getElementById('tileLms').textContent = `${lms.status || '-'} ${lmsConfig.host || ''}:${lmsConfig.http_port || 9000}`;
  const genreApi = data.genre_metadata_api || {};
  document.getElementById('tileGenreApi').textContent = genreApi.status === 'disabled'
    ? 'deaktiviert'
    : `${genreApi.status || '-'} ${genreApi.base_url || ''}`;
  renderGenreApiStatus(genreApi);
  document.getElementById('tilePlayers').textContent = String(data.player_count ?? '-');
  document.getElementById('tileRooms').textContent = (data.rooms || []).join(', ') || '-';
  document.getElementById('headerConfig').textContent = data.config_path || '-';
  renderCommandHistory(data.command_history || (data.last_command ? [data.last_command] : []));
  return data;
}
function renderGenreApiStatus(status) {
  const banner = document.getElementById('genreApiBanner');
  if (!banner) return;
  const state = status.status || 'unknown';
  banner.className = state === 'ok' ? 'banner ok' : state === 'disabled' ? 'banner' : 'banner error';
  banner.textContent = state === 'ok'
    ? `Genre-Scanner-API ist erreichbar. Datenbank: ${(status.health || {}).database_available === false ? 'nicht verfuegbar' : 'verfuegbar'}.`
    : status.message || `Status: ${state}`;
}
function renderCommandHistory(commands) {
  const output = document.getElementById('commandHistory');
  output.innerHTML = '';
  if (!(commands || []).length) {
    output.innerHTML = '<div class="command-history-empty">Noch kein Befehl verarbeitet.</div>';
    return;
  }
  (commands || []).slice(0, 3).forEach((command) => {
    const item = document.createElement('div');
    item.className = 'command-history-item';
    const state = document.createElement('span');
    state.className = `command-state${command.status === 'ok' ? ' ok' : ''}`;
    state.title = command.status === 'ok' ? 'Erfolgreich' : 'Nicht erfolgreich';
    const content = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'command-history-title';
    title.textContent = command.text || '-';
    const target = command.target_name || command.room || '-';
    const parameters = Object.entries(command.parameters || {}).map(([key, value]) => `${key}=${Array.isArray(value) ? value.join(', ') : value}`).join(', ') || '-';
    const meta = document.createElement('div');
    meta.className = 'command-history-meta';
    meta.textContent = `${command.timestamp || '-'} | ${command.action || '-'} | ${parameters} | Ziel: ${target} | ${Number(command.elapsed_ms || 0).toLocaleString('de-DE')} ms | ${command.message || command.status || '-'}`;
    content.append(title, meta); item.append(state, content); output.appendChild(item);
  });
}
async function loadCommandHistory() {
  try {
    const data = await postJson('lms_gateway_admin_commands');
    renderCommandHistory(data.commands || []);
  } catch (error) {
    // Der normale Statusabruf zeigt weiterhin den letzten bekannten Stand.
  }
}
async function testConnection() {
  try { const data = await loadStatus(); setMessage(data.lms.status === 'ok' ? `Verbindung erfolgreich, ${data.player_count} Player gefunden.` : data.lms.message, data.lms.status !== 'ok'); }
  catch (error) { setMessage(error.message, true); }
}
async function loadConfig() {
  try {
    const data = await postJson('lms_gateway_admin_config');
    currentConfig = data.config || {};
    document.getElementById('configText').value = data.config_text || '';
    renderConfigForm();
    setMessage('Konfiguration eingelesen.');
  } catch (error) { setMessage(error.message, true); }
}
function renderConfigForm() {
  const lms = currentConfig.lms || {};
  const dialog = currentConfig.dialog || {};
  const matching = currentConfig.matching || {};
  const genreApi = currentConfig.genre_metadata_api || {};
  const profiles = (currentConfig.metadata_selection || {}).profiles || {};
  setValue('genreSelectionSource', (currentConfig.metadata_selection || {}).genre_source || 'lms');
  setValue('lmsHost', lms.host || '');
  setValue('lmsHttpPort', lms.http_port ?? 9000);
  setValue('lmsCliPort', lms.cli_port ?? 9090);
  setValue('lmsTimeout', lms.timeout_seconds ?? 8);
  setValue('dialogTtl', dialog.session_ttl_seconds ?? 180);
  setValue('controlFollowupSeconds', dialog.control_followup_seconds ?? 5);
  setValue('matchMinScore', matching.min_score ?? 0.55);
  setValue('artistLimit', matching.artist_limit ?? 100);
  setValue('albumLimit', matching.album_limit ?? 100);
  document.getElementById('genreApiEnabled').checked = Boolean(genreApi.enabled ?? false);
  setValue('genreApiBaseUrl', genreApi.base_url || 'http://genre-scanner:8090');
  setValue('genreApiTimeout', genreApi.timeout_seconds ?? 30);
  setValue('genreApiSearchTimeout', genreApi.search_timeout_seconds ?? 12);
  setValue('genreApiRetryAttempts', genreApi.retry_attempts ?? 3);
  setValue('genreApiRetryDelay', genreApi.retry_delay_seconds ?? 1.5);
  setValue('genreApiLimit', genreApi.default_result_limit ?? 100);
  setValue('genreApiToken', genreApi.api_token || '');
  const firstPathMapping = (genreApi.path_mappings || [])[0] || {};
  setValue('genreApiPathFrom', firstPathMapping.from || '');
  setValue('genreApiPathTo', firstPathMapping.to || '');
  document.getElementById('genreApiVerifyTls').checked = Boolean(genreApi.verify_tls ?? true);
  setValue('profileRelaxedMin', (profiles.relaxed || {}).relaxed_min ?? 0.7);
  setValue('profileStimulatingMax', (profiles.stimulating || {}).relaxed_max ?? 0.35);
  setValue('profileHappyMin', (profiles.happy || {}).happy_min ?? 0.7);
  setValue('profileMelancholicMax', (profiles.melancholic || {}).happy_max ?? 0.35);
  setValue('profileDanceableMin', (profiles.danceable || {}).danceability_min ?? 0.7);
  setValue('profileInstrumentalMin', (profiles.instrumental || {}).instrumental_min ?? 0.75);
  setValue('profileBackgroundRelaxedMin', (profiles.background || {}).relaxed_min ?? 0.7);
  setValue('profileBackgroundLraMax', (profiles.background || {}).loudness_range_lu_max ?? 10);
  renderPlayers(currentConfig.players || {});
  renderDevices(currentConfig.devices || {});
}
function collectConfigForm() {
  const cfg = structuredClone(currentConfig || {});
  cfg.lms = cfg.lms || {};
  cfg.dialog = cfg.dialog || {};
  cfg.matching = cfg.matching || {};
  cfg.genre_metadata_api = cfg.genre_metadata_api || {};
  cfg.metadata_selection = cfg.metadata_selection || {};
  cfg.metadata_selection.profiles = cfg.metadata_selection.profiles || {};
  delete cfg.gateway;
  delete cfg.security;
  cfg.lms.host = value('lmsHost');
  cfg.lms.http_port = numberValue('lmsHttpPort', 9000);
  cfg.lms.cli_port = numberValue('lmsCliPort', 9090);
  cfg.lms.timeout_seconds = numberValue('lmsTimeout', 8);
  cfg.dialog.session_ttl_seconds = numberValue('dialogTtl', 180);
  cfg.dialog.control_followup_seconds = numberValue('controlFollowupSeconds', 5);
  cfg.matching.min_score = numberValue('matchMinScore', 0.55);
  cfg.matching.artist_limit = numberValue('artistLimit', 100);
  cfg.matching.album_limit = numberValue('albumLimit', 100);
  cfg.genre_metadata_api.enabled = document.getElementById('genreApiEnabled').checked;
  cfg.genre_metadata_api.base_url = value('genreApiBaseUrl').replace(/\/+$/, '');
  cfg.genre_metadata_api.timeout_seconds = numberValue('genreApiTimeout', 30);
  cfg.genre_metadata_api.search_timeout_seconds = numberValue('genreApiSearchTimeout', 12);
  cfg.genre_metadata_api.retry_attempts = numberValue('genreApiRetryAttempts', 3);
  cfg.genre_metadata_api.retry_delay_seconds = numberValue('genreApiRetryDelay', 1.5);
  cfg.genre_metadata_api.default_result_limit = numberValue('genreApiLimit', 100);
  cfg.genre_metadata_api.api_token = value('genreApiToken');
  const pathFrom = value('genreApiPathFrom');
  const pathTo = value('genreApiPathTo');
  cfg.genre_metadata_api.path_mappings = pathFrom && pathTo ? [{from: pathFrom, to: pathTo}] : [];
  cfg.genre_metadata_api.verify_tls = document.getElementById('genreApiVerifyTls').checked;
  cfg.metadata_selection.genre_source = value('genreSelectionSource') || 'lms';
  cfg.metadata_selection.profiles.relaxed = {relaxed_min: numberValue('profileRelaxedMin', 0.7)};
  cfg.metadata_selection.profiles.stimulating = {relaxed_max: numberValue('profileStimulatingMax', 0.35)};
  cfg.metadata_selection.profiles.happy = {happy_min: numberValue('profileHappyMin', 0.7)};
  cfg.metadata_selection.profiles.melancholic = {happy_max: numberValue('profileMelancholicMax', 0.35)};
  cfg.metadata_selection.profiles.danceable = {danceability_min: numberValue('profileDanceableMin', 0.7)};
  cfg.metadata_selection.profiles.instrumental = {instrumental_min: numberValue('profileInstrumentalMin', 0.75)};
  cfg.metadata_selection.profiles.background = {
    relaxed_min: numberValue('profileBackgroundRelaxedMin', 0.7),
    loudness_range_lu_max: numberValue('profileBackgroundLraMax', 10),
  };
  cfg.players = collectPlayers();
  cfg.devices = collectDevices();
  return cfg;
}
async function testGenreApi() {
  try {
    const data = await postJson('lms_gateway_admin_genre_api');
    const features = (data.available_features || []).join(', ') || 'keine';
    renderGenreApiStatus({status: data.status, health: data.health, message: data.message});
    setMessage(`${data.message || 'API-Verbindung erfolgreich.'} Merkmale: ${features}`);
  } catch (error) {
    renderGenreApiStatus({status: 'error', message: error.message});
    setMessage(error.message, true);
  }
}
async function saveConfig() {
  try {
    const data = await postJson('lms_gateway_admin_config', {config: collectConfigForm()});
    setMessage(data.message || 'Konfiguration gespeichert.');
    await loadConfig();
    await loadStatus();
  } catch (error) { setMessage(error.message, true); }
}
async function applyYaml() {
  try {
    const data = await postJson('lms_gateway_admin_config', {config_text: document.getElementById('configText').value});
    setMessage(data.message || 'YAML gespeichert.');
    await loadConfig();
    await loadStatus();
  } catch (error) { setMessage(error.message, true); }
}
function renderPlayers(players) {
  const container = document.getElementById('playersRows');
  container.innerHTML = '';
  Object.entries(players).forEach(([room, player]) => addPlayerRow(room, player));
}
function addPlayerRow(room='', player={}) {
  const row = document.createElement('div');
  row.className = 'row-card player-grid';
  row.innerHTML = '<div class="field"><label>Raum</label><input data-p="room"></div><div class="field"><label>LMS Player-ID</label><input data-p="id"></div><div class="field"><label>Anzeigename</label><input data-p="name"></div><div class="field"><label>LMS Name</label><input data-p="lms_name"></div><div class="field"><label>Aliasse kommagetrennt</label><input data-p="aliases"></div><button class="danger" type="button">Entfernen</button>';
  row.querySelector('[data-p="room"]').value = room;
  row.querySelector('[data-p="id"]').value = player.id || '';
  row.querySelector('[data-p="name"]').value = player.name || '';
  row.querySelector('[data-p="lms_name"]').value = player.lms_name || '';
  row.querySelector('[data-p="aliases"]').value = (player.aliases || []).join(', ');
  row.querySelector('button').onclick = () => row.remove();
  document.getElementById('playersRows').appendChild(row);
}
function collectPlayers() {
  const players = {};
  document.querySelectorAll('#playersRows .row-card').forEach((row) => {
    const room = row.querySelector('[data-p="room"]').value.trim();
    if (!room) return;
    const player = {id: row.querySelector('[data-p="id"]').value.trim()};
    const name = row.querySelector('[data-p="name"]').value.trim();
    const lmsName = row.querySelector('[data-p="lms_name"]').value.trim();
    const aliases = row.querySelector('[data-p="aliases"]').value.split(',').map(v => v.trim()).filter(Boolean);
    if (name) player.name = name;
    if (lmsName) player.lms_name = lmsName;
    if (aliases.length) player.aliases = aliases;
    players[room] = player;
  });
  return players;
}
function normalizeRoomName(text) {
  return String(text || '').toLowerCase().replace(/ae/g, 'a').replace(/oe/g, 'o').replace(/ue/g, 'u').replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ');
}
function findRoom(players, playerId, lmsName) {
  for (const [room, player] of Object.entries(players)) {
    if (playerId && String(player.id || '').toLowerCase() === playerId.toLowerCase()) return room;
    if (lmsName && normalizeRoomName(player.lms_name || player.name || room) === normalizeRoomName(lmsName)) return room;
  }
  return '';
}
async function scanLmsPlayers() {
  try {
    const data = await postJson('lms_gateway_admin_players');
    const existing = collectPlayers();
    for (const item of data.players || []) {
      const id = String(item.playerid || item.id || '').trim();
      const lmsName = String(item.name || item.player_name || item.playername || '').trim();
      if (!id && !lmsName) continue;
      const room = findRoom(existing, id, lmsName) || normalizeRoomName(lmsName || id);
      const old = existing[room] || {};
      existing[room] = {...old, id: id || old.id || '', name: old.name || lmsName || room, lms_name: lmsName || old.lms_name || ''};
    }
    currentConfig.players = existing;
    renderPlayers(existing);
    setMessage(`${data.message} Zum dauerhaften Uebernehmen bitte speichern.`);
    await loadStatus();
  } catch (error) { setMessage(error.message, true); }
}
function renderDevices(devices) {
  const container = document.getElementById('devicesRows');
  container.innerHTML = '';
  Object.entries(devices).forEach(([device, config]) => addDeviceRow(device, config));
}
function addDeviceRow(device='', config={}) {
  const row = document.createElement('div');
  row.className = 'row-card device-grid';
  row.innerHTML = '<div class="field"><label>Geraet oder Quellenkennung</label><input data-d="device"></div><div class="field"><label>Standardraum</label><input data-d="room"></div><button class="danger" type="button">Entfernen</button>';
  row.querySelector('[data-d="device"]').value = device;
  row.querySelector('[data-d="room"]').value = config.default_room || '';
  row.querySelector('button').onclick = () => row.remove();
  document.getElementById('devicesRows').appendChild(row);
}
function collectDevices() {
  const devices = {};
  document.querySelectorAll('#devicesRows .row-card').forEach((row) => {
    const device = row.querySelector('[data-d="device"]').value.trim();
    if (!device) return;
    const room = row.querySelector('[data-d="room"]').value.trim();
    devices[device] = room ? {default_room: room} : {};
  });
  return devices;
}
async function loadFeatures() {
  try {
    const data = await postJson('lms_gateway_admin_features');
    const grid = document.getElementById('featureGrid');
    grid.innerHTML = '';
    (data.features || []).forEach((feature) => {
      const label = document.createElement('label');
      label.className = 'feature';
      const input = document.createElement('input');
      input.type = 'checkbox'; input.dataset.feature = feature.id; input.checked = feature.enabled;
      const text = document.createElement('span'); text.textContent = feature.label;
      label.append(input, text); grid.appendChild(label);
    });
  } catch (error) { setMessage(error.message, true); }
}
async function saveFeatures() {
  const features = {};
  document.querySelectorAll('[data-feature]').forEach(input => features[input.dataset.feature] = input.checked);
  try { const data = await postJson('lms_gateway_admin_features', {features}); setMessage(data.message); await loadFeatures(); }
  catch (error) { setMessage(error.message, true); }
}
async function testCommand() {
  const text = value('commandText');
  if (!text) { setMessage('Bitte zuerst einen Steuersatz eingeben.', true); return; }
  try {
    const data = await postJson('lms_gateway_command', {text, room: value('commandRoom') || null, device: value('commandDevice') || 'admin_test', source: 'admin', dry_run: document.getElementById('commandDryRun').checked});
    document.getElementById('commandResult').textContent = JSON.stringify(data, null, 2);
    setMessage(data.message || 'Befehl getestet.');
    await loadStatus();
  } catch (error) { document.getElementById('commandResult').textContent = error.message; setMessage(error.message, true); }
}
async function loadLogs() {
  try { const data = await postJson('lms_gateway_admin_logs', {lines: 300}); document.getElementById('logText').textContent = data.logs || ''; }
  catch (error) { setMessage(error.message, true); }
}
async function clearLogs() {
  if (!window.confirm('Das LMS-Gateway-Protokoll wirklich loeschen?')) return;
  try {
    const data = await postJson('lms_gateway_admin_logs', {operation: 'clear'});
    document.getElementById('logText').textContent = '';
    setMessage(data.message || 'Protokoll geloescht.');
    await loadLogs();
  } catch (error) { setMessage(error.message, true); }
}
function lmsAlarmDays(value) {
  const names = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
  const days = String(value ?? '').split(',').map(Number).filter(day => day >= 0 && day <= 6);
  if (days.length === 7) return 'taeglich';
  if (days.join(',') === '1,2,3,4,5') return 'werktags';
  return days.map(day => names[day]).join(', ') || '-';
}
function lmsAlarmTime(value) {
  const seconds = Number(value || 0);
  return `${String(Math.floor(seconds / 3600)).padStart(2, '0')}:${String(Math.floor((seconds % 3600) / 60)).padStart(2, '0')} Uhr`;
}
async function loadAlarms() {
  const banner = document.getElementById('alarmBanner');
  const rows = document.getElementById('alarmRows');
  try {
    const data = await postJson('lms_gateway_admin_alarms');
    banner.className = data.errors?.length ? 'banner' : 'banner ok';
    banner.textContent = data.errors?.length ? `${data.message} Fehler: ${data.errors.join('; ')}` : data.message;
    renderAlarmDefaults(data.defaults || {}, data.sounds || []);
    rows.innerHTML = '';
    if (!(data.alarms || []).length) {
      rows.innerHTML = '<tr><td colspan="8">Keine Wecker in LMS gespeichert.</td></tr>';
      return;
    }
    (data.alarms || []).sort((a, b) => String(a.room).localeCompare(String(b.room)) || Number(a.time || 0) - Number(b.time || 0)).forEach(alarm => {
      const row = document.createElement('tr');
      const active = Number(alarm.enabled || 0) === 1;
      row.innerHTML = `<td><strong>${alarm.room || '-'}</strong><br><span class="label">${alarm.player_name || alarm.player_id || '-'}</span></td><td>${lmsAlarmTime(alarm.time)}</td><td>${lmsAlarmDays(alarm.dow)}</td><td><span class="state-pill ${active ? 'active' : ''}">${active ? 'aktiv' : 'deaktiviert'}</span></td><td>${Number(alarm.repeat || 0) ? 'wiederkehrend' : 'einmalig'}</td><td>${alarm.volume ?? 'Standard'}</td><td>${alarm.url || 'Aktuelle Playlist'}</td><td><button class="danger" type="button">Loeschen</button></td>`;
      row.querySelector('button').addEventListener('click', () => deleteAlarm(alarm));
      rows.appendChild(row);
    });
  } catch (error) {
    banner.className = 'banner error'; banner.textContent = error.message;
    rows.innerHTML = '<tr><td colspan="8">Wecker konnten nicht geladen werden.</td></tr>';
  }
}
function renderAlarmDefaults(defaults, sounds) {
  document.getElementById('alarmDefaultVolume').value = defaults.volume ?? 50;
  document.getElementById('alarmDefaultShuffle').checked = Boolean(defaults.shuffle);
  const select = document.getElementById('alarmDefaultSound');
  const choices = [{url: 'CURRENT_PLAYLIST', title: 'Aktuelle Playlist'}, ...sounds.map(sound => ({
    url: String(sound.url || sound.id || ''),
    title: String(sound.title || sound.name || sound.url || sound.id || 'Weckton')
  })).filter(sound => sound.url)];
  if (defaults.url && !choices.some(choice => choice.url === defaults.url)) {
    choices.push({url: defaults.url, title: defaults.sound_name || defaults.url});
  }
  select.replaceChildren(...choices.map(choice => {
    const option = document.createElement('option');
    option.value = choice.url;
    option.textContent = choice.title;
    option.selected = choice.url === (defaults.url || 'CURRENT_PLAYLIST');
    return option;
  }));
}
async function saveAlarmDefaults() {
  const sound = document.getElementById('alarmDefaultSound');
  try {
    const data = await postJson('lms_gateway_admin_alarms', {
      operation: 'save_defaults',
      volume: Number(document.getElementById('alarmDefaultVolume').value),
      url: sound.value || 'CURRENT_PLAYLIST',
      sound_name: sound.options[sound.selectedIndex]?.text || 'Aktuelle Playlist',
      shuffle: document.getElementById('alarmDefaultShuffle').checked
    });
    setMessage(data.message || 'Wecker-Standards gespeichert.');
    await loadAlarms();
  } catch (error) { setMessage(error.message, true); }
}
async function deleteAlarm(alarm) {
  const description = `${alarm.room || 'Player'} um ${lmsAlarmTime(alarm.time)}`;
  if (!window.confirm(`Wecker ${description} wirklich loeschen?`)) return;
  try {
    const data = await postJson('lms_gateway_admin_alarms', {operation: 'delete', player_id: alarm.player_id, alarm_id: alarm.id});
    setMessage(data.message || 'Wecker geloescht.');
    await loadAlarms();
  } catch (error) { setMessage(error.message, true); }
}
async function loadAll() {
  try { await Promise.all([loadStatus(), loadFeatures(), loadConfig(), loadLogs(), loadAlarms()]); setMessage('Bereit.'); }
  catch (error) { setMessage(error.message, true); }
}
const allowedTabs = ['standard', 'alarms', 'configuration', 'guide'];
const pageParams = new URLSearchParams(window.location.search);
const requestedTab = pageParams.get('tab');
if (pageParams.get('embedded') === '1') document.body.classList.add('embedded');
const savedTab = sessionStorage.getItem('lms_gateway_admin_tab');
showTab(allowedTabs.includes(requestedTab) ? requestedTab : (allowedTabs.includes(savedTab) ? savedTab : 'standard'));
loadAll();
setInterval(loadCommandHistory, 2000);
</script>
</body>
</html>"""
