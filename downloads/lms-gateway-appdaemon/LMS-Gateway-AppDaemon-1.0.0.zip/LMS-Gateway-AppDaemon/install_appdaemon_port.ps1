[CmdletBinding()]
param(
    [string]$AppDaemonRoot,
    [string]$HomeAssistantConfig,
    [switch]$CheckOnly,
    [switch]$SkipHomeAssistantPackage
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ScriptRoot = $PSScriptRoot
$GatewaySource = Join-Path $ScriptRoot "gateway\app"
$WrapperSource = Join-Path $ScriptRoot "lms_gateway_app.py"
$AdminUiSource = Join-Path $ScriptRoot "lms_gateway_admin_ui.py"
$DefaultConfigSource = Join-Path $ScriptRoot "config.default.yaml"
$SavedConfigSource = Join-Path $ScriptRoot "config.saved.yaml"
$PackageSource = Join-Path $ScriptRoot "home_assistant_package_lms_gateway_complete.yaml"
$BlueprintSource = Join-Path $ScriptRoot "home_assistant\blueprints\automation\pom"
$RequiredGatewayFiles = @(
    "__init__.py", "config_loader.py", "context.py", "dialogs.py",
    "genre_metadata_client.py", "intent.py", "library.py", "lms_client.py", "logging_setup.py",
    "main.py", "matcher.py", "players.py", "sessions.py"
)
$Warnings = [System.Collections.Generic.List[string]]::new()
$Actions = [System.Collections.Generic.List[string]]::new()
$Installed = [System.Collections.Generic.List[string]]::new()
$BackupStamp = Get-Date -Format "yyyyMMdd-HHmmss"

function Write-Stage([string]$Message) {
    Write-Host "`n== $Message ==" -ForegroundColor Cyan
}

function Add-Warning([string]$Message) {
    $script:Warnings.Add($Message)
    Write-Warning $Message
}

function Add-Action([string]$Message) {
    $script:Actions.Add($Message)
    Write-Host "ERFORDERLICH: $Message" -ForegroundColor Yellow
}

function Resolve-ExistingDirectory {
    param([string]$ExplicitPath, [string[]]$Candidates, [string]$Description)
    if ($ExplicitPath) {
        if (Test-Path -LiteralPath $ExplicitPath -PathType Container) {
            return (Resolve-Path -LiteralPath $ExplicitPath).ProviderPath
        }
        throw "$Description nicht gefunden: $ExplicitPath"
    }
    foreach ($Candidate in $Candidates) {
        try {
            if (Test-Path -LiteralPath $Candidate -PathType Container) {
                return (Resolve-Path -LiteralPath $Candidate).ProviderPath
            }
        }
        catch {
            # Nicht erreichbare Netzwerkpfade werden spaeter konkret gemeldet.
        }
    }
    return $null
}

function Find-AppDaemonRoot {
    param([string]$ExplicitPath)
    $Found = Resolve-ExistingDirectory -ExplicitPath $ExplicitPath -Candidates @(
        "\\homeassistant\addon_configs\a0d7b954_appdaemon",
        "\\homeassistant.local\addon_configs\a0d7b954_appdaemon",
        "\\homeassistant\config\appdaemon",
        "\\homeassistant.local\config\appdaemon"
    ) -Description "AppDaemon-Verzeichnis"
    if ($Found) { return $Found }

    foreach ($ShareRoot in @("\\homeassistant\addon_configs", "\\homeassistant.local\addon_configs")) {
        try {
            if (-not (Test-Path -LiteralPath $ShareRoot -PathType Container)) { continue }
            $Match = Get-ChildItem -LiteralPath $ShareRoot -Directory -ErrorAction Stop |
                Where-Object { $_.Name -match "appdaemon" } | Select-Object -First 1
            if ($Match) { return $Match.FullName }
        }
        catch {
            # Die Freigabe kann ohne passende Anmeldedaten nicht lesbar sein.
        }
    }
    return $null
}

function Find-HomeAssistantConfig {
    param([string]$ExplicitPath)
    return Resolve-ExistingDirectory -ExplicitPath $ExplicitPath -Candidates @(
        "\\homeassistant\config",
        "\\homeassistant.local\config"
    ) -Description "Home-Assistant-Konfigurationsverzeichnis"
}

function Backup-File {
    param([string]$Path, [string]$BackupRoot)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
    Copy-Item -LiteralPath $Path -Destination (Join-Path $BackupRoot (Split-Path $Path -Leaf)) -Force
}

function Copy-VerifiedFile {
    param([string]$Source, [string]$Destination, [string]$BackupRoot)
    Backup-File -Path $Destination -BackupRoot $BackupRoot
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    $SourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Source).Hash
    $DestinationHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Destination).Hash
    if ($SourceHash -ne $DestinationHash) {
        throw "Kopierpruefung fehlgeschlagen: $Destination"
    }
    $script:Installed.Add($Destination)
}

function Ensure-AppsYamlEntry {
    param([string]$AppsYaml, [string]$BackupRoot)
    $Entry = @"

lms_gateway:
  module: lms_gateway.lms_gateway_app
  class: LmsGatewayApp
"@
    if (-not (Test-Path -LiteralPath $AppsYaml -PathType Leaf)) {
        Set-Content -LiteralPath $AppsYaml -Value $Entry.TrimStart() -Encoding utf8
        $script:Installed.Add($AppsYaml)
        return
    }
    $Content = Get-Content -LiteralPath $AppsYaml -Raw
    if ($Content -match "(?m)^lms_gateway\s*:") { return }
    Backup-File -Path $AppsYaml -BackupRoot $BackupRoot
    Add-Content -LiteralPath $AppsYaml -Value $Entry -Encoding utf8
    $script:Installed.Add($AppsYaml)
}

function Ensure-FeatureDefaults {
    param([string]$ConfigPath, [string]$BackupRoot)
    $FeatureBlock = @"

features:
  play_artist_playlist: true
  play_album_dialog: true
  play_album_title: true
  play_title: true
  play_radio: true
  play_radio_dialog: true
  play_genre: true
  play_music_folder: true
  play_current_album: true
  play_similar: true
  sync_players: true
  unsync_all: true
  unsync_players: true
  continue_playback: true
  transport: true
  volume: true
  shuffle: true
"@
    $Content = Get-Content -LiteralPath $ConfigPath -Raw
    if ($Content -notmatch "(?m)^features\s*:") {
        Backup-File -Path $ConfigPath -BackupRoot $BackupRoot
        Add-Content -LiteralPath $ConfigPath -Value $FeatureBlock -Encoding utf8
        Add-Warning "Die vorhandene Konfiguration hatte keinen Bereich 'features'; Standardwerte wurden ergaenzt."
    }
}

function Test-HomeAssistantPackagesEnabled {
    param([string]$ConfigRoot)
    $ConfigurationYaml = Join-Path $ConfigRoot "configuration.yaml"
    if (-not (Test-Path -LiteralPath $ConfigurationYaml -PathType Leaf)) {
        Add-Action "In Home Assistant 'configuration.yaml' bereitstellen oder -HomeAssistantConfig mit dem richtigen Pfad angeben."
        return $false
    }
    $Content = Get-Content -LiteralPath $ConfigurationYaml -Raw
    if ($Content -notmatch "(?m)^\s*packages\s*:\s*!include_dir_named\s+packages\s*$") {
        Add-Action "In configuration.yaml unter 'homeassistant:' die Zeile 'packages: !include_dir_named packages' eintragen und Home Assistant neu starten."
        return $false
    }
    return $true
}

Write-Stage "Installationspaket pruefen"
if (-not (Test-Path -LiteralPath $WrapperSource -PathType Leaf)) {
    throw "AppDaemon-Startmodul fehlt: $WrapperSource"
}
if (-not (Test-Path -LiteralPath $AdminUiSource -PathType Leaf)) {
    throw "AppDaemon-Konfigurationsseite fehlt: $AdminUiSource"
}
if (-not (Test-Path -LiteralPath $DefaultConfigSource -PathType Leaf)) {
    throw "Standardkonfiguration fehlt: $DefaultConfigSource"
}
if (-not $SkipHomeAssistantPackage -and -not (Test-Path -LiteralPath $PackageSource -PathType Leaf)) {
    throw "Vollstaendiges Home-Assistant-Paket fehlt: $PackageSource"
}
foreach ($FileName in $RequiredGatewayFiles) {
    $SourcePath = Join-Path $GatewaySource $FileName
    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
        throw "Erforderliche Gateway-Datei fehlt: $SourcePath"
    }
}
Write-Host "Installationspaket ist vollstaendig."

Write-Stage "Home Assistant und AppDaemon erkennen"
$ResolvedAppDaemonRoot = Find-AppDaemonRoot -ExplicitPath $AppDaemonRoot
$ResolvedHomeAssistantConfig = Find-HomeAssistantConfig -ExplicitPath $HomeAssistantConfig
if (-not $ResolvedAppDaemonRoot) {
    Add-Action "Das AppDaemon-Add-on in Home Assistant installieren und starten. Danach die Netzwerkfreigabe 'addon_configs' aktivieren oder den Installer mit -AppDaemonRoot '<Pfad>' erneut ausfuehren."
}
else { Write-Host "AppDaemon: $ResolvedAppDaemonRoot" }
if (-not $ResolvedHomeAssistantConfig) {
    Add-Action "Die Home-Assistant-Konfigurationsfreigabe bereitstellen oder den Installer mit -HomeAssistantConfig '<Pfad>' erneut ausfuehren."
}
else { Write-Host "Home Assistant: $ResolvedHomeAssistantConfig" }
if (-not $ResolvedAppDaemonRoot) {
    Write-Host "`nInstallation kann ohne erreichbares AppDaemon-Verzeichnis nicht fortgesetzt werden." -ForegroundColor Red
    exit 2
}

$TargetAppsDir = Join-Path $ResolvedAppDaemonRoot "apps"
$TargetDir = Join-Path $TargetAppsDir "lms_gateway"
$TargetGatewayApp = Join-Path $TargetDir "gateway\app"
$BackupRoot = Join-Path $TargetDir ".install-backups\$BackupStamp"
$AppsYaml = Join-Path $TargetAppsDir "apps.yaml"
$TargetConfig = Join-Path $TargetDir "config.yaml"
$NewConfigCreated = $false

Write-Stage "Voraussetzungen pruefen"
if (-not (Test-Path -LiteralPath $TargetAppsDir -PathType Container)) {
    Add-Action "AppDaemon mindestens einmal starten, damit der Ordner 'apps' angelegt wird."
    if (-not $CheckOnly) {
        New-Item -ItemType Directory -Force -Path $TargetAppsDir | Out-Null
        Add-Warning "Der fehlende AppDaemon-Apps-Ordner wurde angelegt. Falls AppDaemon einen anderen App-Pfad nutzt, -AppDaemonRoot explizit angeben."
    }
}
$AppDaemonConfig = @(
    (Join-Path $ResolvedAppDaemonRoot "appdaemon.yaml"),
    (Join-Path $ResolvedAppDaemonRoot "appdaemon.yml")
) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $AppDaemonConfig) {
    Add-Warning "Keine appdaemon.yaml im erkannten Stamm gefunden. Das ist bei manchen Add-on-Versionen normal; bitte nach der Installation das AppDaemon-Protokoll kontrollieren."
}
Write-Host "Python-Zusatzpakete: keine. Die AppDaemon-Fassung verwendet Standardmodule und das von AppDaemon bereitgestellte PyYAML."
$HomeAssistantPackagesReady = $false
if (-not $SkipHomeAssistantPackage -and $ResolvedHomeAssistantConfig) {
    $HomeAssistantPackagesReady = Test-HomeAssistantPackagesEnabled -ConfigRoot $ResolvedHomeAssistantConfig
}

if ($CheckOnly) {
    Write-Host "`nPruefung abgeschlossen; wegen -CheckOnly wurden keine Dateien geaendert." -ForegroundColor Green
    if ($Actions.Count -gt 0) {
        Write-Host "Offene Schritte:" -ForegroundColor Yellow
        $Actions | ForEach-Object { Write-Host "- $_" }
        exit 2
    }
    exit 0
}

Write-Stage "AppDaemon-App installieren"
New-Item -ItemType Directory -Force -Path $TargetGatewayApp | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $TargetDir "logs") | Out-Null
Copy-VerifiedFile -Source $WrapperSource -Destination (Join-Path $TargetDir "lms_gateway_app.py") -BackupRoot $BackupRoot
Copy-VerifiedFile -Source $AdminUiSource -Destination (Join-Path $TargetDir "lms_gateway_admin_ui.py") -BackupRoot $BackupRoot
foreach ($FileName in $RequiredGatewayFiles) {
    Copy-VerifiedFile -Source (Join-Path $GatewaySource $FileName) -Destination (Join-Path $TargetGatewayApp $FileName) -BackupRoot $BackupRoot
}
if (-not (Test-Path -LiteralPath $TargetConfig -PathType Leaf)) {
    $InitialConfigSource = if (Test-Path -LiteralPath $SavedConfigSource -PathType Leaf) { $SavedConfigSource } else { $DefaultConfigSource }
    Copy-VerifiedFile -Source $InitialConfigSource -Destination $TargetConfig -BackupRoot $BackupRoot
    $NewConfigCreated = $true
    Write-Host "Neue Ausgangskonfiguration angelegt: $TargetConfig"
}
else { Write-Host "Vorhandene Benutzerkonfiguration bleibt erhalten: $TargetConfig" }
Ensure-FeatureDefaults -ConfigPath $TargetConfig -BackupRoot $BackupRoot
Ensure-AppsYamlEntry -AppsYaml $AppsYaml -BackupRoot $BackupRoot

if (-not $SkipHomeAssistantPackage) {
    Write-Stage "Home-Assistant-Anbindung installieren"
    if ($ResolvedHomeAssistantConfig -and $HomeAssistantPackagesReady) {
        $PackagesDir = Join-Path $ResolvedHomeAssistantConfig "packages"
        New-Item -ItemType Directory -Force -Path $PackagesDir | Out-Null
        Copy-VerifiedFile -Source $PackageSource -Destination (Join-Path $PackagesDir "lms_gateway_complete.yaml") -BackupRoot $BackupRoot
        if (Test-Path -LiteralPath $BlueprintSource -PathType Container) {
            $TargetBlueprintDir = Join-Path $ResolvedHomeAssistantConfig "blueprints\automation\pom"
            New-Item -ItemType Directory -Force -Path $TargetBlueprintDir | Out-Null
            foreach ($BlueprintName in @("assist_audio_absenkung.yaml", "assist_audio_absenkung_automatisch.yaml")) {
                $SourceBlueprint = Join-Path $BlueprintSource $BlueprintName
                if (Test-Path -LiteralPath $SourceBlueprint -PathType Leaf) {
                    Copy-VerifiedFile -Source $SourceBlueprint -Destination (Join-Path $TargetBlueprintDir $BlueprintName) -BackupRoot $BackupRoot
                }
                else {
                    Add-Warning "Audio-Blueprint fehlt im Installationspaket: $BlueprintName"
                }
            }
        }
        else {
            Add-Warning "Der Blueprint-Ordner fehlt; die automatische Audio-Absenkung kann nicht eingerichtet werden."
        }
    }
    elseif (-not $ResolvedHomeAssistantConfig) {
        Add-Warning "Die AppDaemon-App wurde installiert, die Home-Assistant-Anbindung jedoch nicht."
    }
}

Write-Stage "Abschlusspruefung"
$ValidationErrors = [System.Collections.Generic.List[string]]::new()
foreach ($FileName in $RequiredGatewayFiles) {
    $SourcePath = Join-Path $GatewaySource $FileName
    $TargetPath = Join-Path $TargetGatewayApp $FileName
    if (-not (Test-Path -LiteralPath $TargetPath -PathType Leaf)) {
        $ValidationErrors.Add("Fehlt: $TargetPath")
        continue
    }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $SourcePath).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $TargetPath).Hash) {
        $ValidationErrors.Add("Abweichende Datei: $TargetPath")
    }
}
if ($ValidationErrors.Count -gt 0) {
    $ValidationErrors | ForEach-Object { Write-Error $_ }
    exit 3
}

Add-Action "AppDaemon in Home Assistant neu starten und dort das Protokoll auf 'LMS Gateway AppDaemon-Port geladen.' pruefen."
if ($ResolvedHomeAssistantConfig -and -not $SkipHomeAssistantPackage) {
    Add-Action "Home Assistant neu starten oder die YAML-Konfiguration neu laden, damit das Paket aktiv wird."
}
if ($NewConfigCreated) {
    Add-Action "Auf der LMS-Gateway-Konfigurationsseite die LMS-Adresse eintragen und danach 'LMS auslesen' verwenden, um Player und Raeume zu uebernehmen."
}

$ReportPath = Join-Path $TargetDir "installation-report.txt"
$Report = @(
    "LMS Gateway AppDaemon Installation",
    "Zeit: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss K')",
    "AppDaemon: $ResolvedAppDaemonRoot",
    "Home Assistant: $ResolvedHomeAssistantConfig",
    "Installierte oder aktualisierte Dateien: $($Installed.Count)",
    "Warnungen: $($Warnings.Count)",
    "Offene Schritte: $($Actions.Count)", "", "Warnungen:",
    ($Warnings | ForEach-Object { "- $_" }), "", "Offene Schritte:",
    ($Actions | ForEach-Object { "- $_" })
)
Set-Content -LiteralPath $ReportPath -Value $Report -Encoding utf8
Write-Host "Installation und Dateipruefung erfolgreich." -ForegroundColor Green
Write-Host "Bericht: $ReportPath"
Write-Host "Sicherung ersetzter Dateien: $BackupRoot"
Write-Host "`nNoch auszufuehren:" -ForegroundColor Yellow
$Actions | ForEach-Object { Write-Host "- $_" }
