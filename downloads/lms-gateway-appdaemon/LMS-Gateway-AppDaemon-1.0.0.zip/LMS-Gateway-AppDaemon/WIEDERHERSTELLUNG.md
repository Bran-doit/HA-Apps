# LMS Gateway AppDaemon wiederherstellen

## Voraussetzungen

- Home Assistant mit Supervisor und gestartetem AppDaemon-Add-on.
- AppDaemon-HTTP-Schnittstelle auf Port 5050 und erreichbarer Lyrion Music Server.
- Schreibzugriff vom Windows-Installationsrechner auf die Freigaben `config`
  und `addon_configs`. PowerShell 7 wird empfohlen.
- Die Home-Assistant-Konfiguration bindet Pakete ein. Unter dem vorhandenen
  Abschnitt `homeassistant:` bei Bedarf `packages: !include_dir_named packages`
  ergaenzen. Einen vorhandenen Abschnitt beibehalten.

## Installation

Das ZIP entpacken. Im entpackten Ordner zuerst die Vorpruefung ausfuehren:

```powershell
.\install_appdaemon_port.ps1 -CheckOnly
.\install_appdaemon_port.ps1
```

Bei anderen Freigaben `-AppDaemonRoot` und `-HomeAssistantConfig` angeben.
Der Installer richtet die App, das Sprachpaket und die Audio-Blueprints ein
und sichert ersetzte Dateien. Vorhandene LMS-Einstellungen werden uebernommen.

Fuer eine Wiederherstellung mit bisherigen Playern und Raumen die separat
gesicherte LMS-`config.yaml` vor der Erstinstallation als
`config.saved.yaml` neben den Installer legen. Diese Datei gehoert wegen
lokaler Adressen und moeglicher Zugangsdaten in ein privates Backup.
Ohne diese Datei die LMS-Adresse, Player und Eingabegeraete anschliessend
in der Gateway-Konfiguration eintragen.

AppDaemon und Home Assistant nach den Hinweisen des Installers neu laden
oder neu starten. Verbindung und Sprachrouting mit einem Testbefehl pruefen.
Bei abweichender AppDaemon-Adresse die REST-URL im HA-Paket anpassen.
Die Dashboard-Vorlage unter `home_assistant/dashboards` kann als YAML-Dashboard
registriert werden. Fuer Browserzugriff darin die erreichbare AppDaemon-Adresse
eintragen. Neu vergebene Geraete- und Entity-IDs nach einer Migration pruefen.
